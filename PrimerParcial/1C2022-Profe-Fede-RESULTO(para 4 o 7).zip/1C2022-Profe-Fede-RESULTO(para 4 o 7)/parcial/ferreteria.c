#include<ferreteria.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>
#include<../include/cola_dinamica.h>


int procesar_pedidos(const char * path_prods, const char * path_pedidos)
{
    FILE* fpProductos = fopen(path_prods, "r+b");
    FILE* fpPedidos = fopen(path_pedidos, "rt");
    FILE* fpPedidosRealizados = fopen("pedidos_realizados.txt", "wt");
    FILE* fpPedidosFaltantes = fopen("pedidos_faltantes.txt", "wt");

    if(!fpPedidos || !fpProductos || !fpPedidosRealizados || !fpPedidosFaltantes)
    {
        printf("ERROR AL ABRIR LOS ARCHIVOS.\n");
        return ERR_ARCH;
    }

    t_producto_stock producto;
    t_pedido pedido;
    t_pedido pedidoCola;
    tCola colaPedidos;
    crear_cola_res(&colaPedidos);
    int pedidoProcesado = 1;
    float precioTotal = 0;
    int lectura = leer_pedido_res(&pedido, fpPedidos);
    int cod_ped = pedido.cod_ped;

    while(lectura)
    {

        while(lectura && pedido.cod_ped == cod_ped)
        {
            /// Leemos el producto que esta buscando
            fseek(fpProductos, (long)(sizeof(t_producto_stock) * (pedido.cod_prod - 1)), SEEK_SET);
            fread(&producto, sizeof(t_producto_stock), 1, fpProductos);

            if (producto.stock < pedido.cant)
            {
                pedidoProcesado = 0;
            }

            poner_en_cola(&colaPedidos, &pedido, sizeof(t_pedido));
            lectura = leer_pedido_res(&pedido, fpPedidos);
        }

        if(pedidoProcesado)
        {
            fprintf(fpPedidosRealizados, "Pedido %d procesado:\n", cod_ped);
        }
        else
        {
            fprintf(fpPedidosFaltantes, "Pedido %d con faltantes:\n", cod_ped);
        }


        /// Si salimos del while es pq termino de leer el archivo o pq encontro un producto con otro cod_ped
        cod_ped = pedido.cod_ped;


        /// Sacamos de la cola y Procesamos el pedido...
        while(sacar_de_cola_res(&colaPedidos, &pedidoCola, sizeof(t_pedido)))
        {
             /// Leemos el producto que esta buscando
             fseek(fpProductos, (long)(sizeof(t_producto_stock) * (pedidoCola.cod_prod - 1)), SEEK_SET);
             fread(&producto, sizeof(t_producto_stock), 1, fpProductos);

            if(pedidoProcesado)
            {
                precioTotal += producto.precio * pedidoCola.cant;
                producto.stock -= pedidoCola.cant;

                /// Escribir el archivo de texto pedidos_realizados.txt
                fprintf(fpPedidosRealizados, FORMATEO_REALIZADOS,
                        pedidoCola.cod_prod, producto.descripcion, pedidoCola.cant,
                        producto.precio, pedidoCola.cant * producto.precio);

                /// Sobreescribimos el producto en el archivo binario
                fseek(fpProductos, (long)(sizeof(t_producto_stock) * (pedidoCola.cod_prod - 1)), SEEK_SET);
                fwrite(&producto, sizeof(t_producto_stock), 1, fpProductos);
            }
            else
            {
                /// Escribir el archivo de texto pedidos_pendientes.txt
                fprintf(fpPedidosFaltantes, FORMATEO_PENDIENTES,
                        pedidoCola.cod_prod, producto.descripcion, producto.stock,
                        pedidoCola.cant, FALTANTE(producto.stock,pedidoCola.cant));
            }




         }

        if(pedidoProcesado)
        {
            fprintf(fpPedidosRealizados, "%40s $%7.2f\n", "TOTAL:", precioTotal);
        }

        /// Terminamos de procesar el pedido y volvemos a poner las variables en su lugar
        pedidoProcesado = 1;
        precioTotal = 0;

    }

    fclose(fpPedidos);
    fclose(fpProductos);
    fclose(fpPedidosRealizados);
    fclose(fpPedidosFaltantes);

    return 1;

}
