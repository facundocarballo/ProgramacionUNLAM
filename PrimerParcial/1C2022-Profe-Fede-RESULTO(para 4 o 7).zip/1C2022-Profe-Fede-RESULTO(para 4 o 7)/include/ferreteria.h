#ifndef BANCO_H_INCLUDED
#define BANCO_H_INCLUDED

#define ERR_ARCH -1

#define FALTANTE(x,y)(x<y?'F':' ')

typedef struct{
    char descripcion[20];
    unsigned stock;
    float precio;
}t_producto_stock;

typedef struct{
    unsigned cod_ped;
    unsigned cod_prod;
    unsigned cant;
}t_pedido;

int procesar_pedidos(const char * path_prods, const char * path_pedidos);
int procesar_pedidos_res(const char * path_prods, const char * path_pedidos);

#endif // BANCO_H_INCLUDED
