#include<../include/cola_dinamica.h>
#include<stdlib.h>
#include"string.h"

int poner_en_cola(tCola * pc, const void * pd, unsigned tam)
{
    /// Reservamos memoria para el nuevo nodo
    tNodo* nueNodo = (tNodo*)malloc(sizeof(tNodo));
    if(!nueNodo) return -2;
    nueNodo->info = malloc(tam);

    /// Armamos el nodo
    memcpy(nueNodo->info, pd, tam);
    nueNodo->tamInfo = tam;
    nueNodo->sig = pc->ult->sig;

    /// Enganchamos el nuevo nodo con la pila
    pc->ult->sig = nueNodo;
    pc->ult = nueNodo;

    return 1;
}

void vaciar_cola(tCola* pc)
{
    if (pc->pri == NULL) return;

    while(pc->pri != NULL)
    {
        free(pc->pri->info);
        free(pc->pri);

        pc->pri = pc->pri->sig;
    }

    return;
}
