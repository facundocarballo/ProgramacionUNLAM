#include "complejo.h"

 /// Constructores
Complejo::Complejo(int r, int i)
{
    real = r;
    imaginario = i;
}
/// Destructor
Complejo::~Complejo(){}
/// Metodos

/// Operadores
Complejo& Complejo::operator=(const Complejo& comp)
{
    imaginario = comp.imaginario;
    real = comp.real;

    return *this;
}
Complejo Complejo::operator*(const Complejo& comp)
{
    Complejo nueComp;

    nueComp.real = ((real*comp.real)-(imaginario*comp.imaginario));
    nueComp.imaginario = ((real*comp.imaginario)+(imaginario*comp.real));

    return nueComp;
}

Complejo Complejo::operator+(const Complejo& comp)
{
    Complejo nueComp;

    nueComp.real = real + comp.real;
    nueComp.imaginario = imaginario + comp.imaginario;

    return nueComp;
}

/// Friends
Complejo operator*(const int num, const Complejo& comp)
{
     Complejo nueComp;

     nueComp.real = num * comp.real;
     nueComp.imaginario = num * comp.imaginario;

     return nueComp;
}
ostream& operator<<(ostream& sal, const Complejo& comp)
{
    sal << "( " << comp.real << ", " << comp.imaginario << " )";

    return sal;
}
