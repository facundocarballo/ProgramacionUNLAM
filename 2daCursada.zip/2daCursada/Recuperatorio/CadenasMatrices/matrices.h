#ifndef MATRICES_H_INCLUDED
#define MATRICES_H_INCLUDED

#include <stdio.h>

#define TAM_MATRIZ 3

/// Auxiliares
void mostrar_matriz(int matriz[][TAM_MATRIZ]);

/// Cant. Apariciones (4)
void trasponer_matriz_in_situ(int matriz[][TAM_MATRIZ]);

/// Cant. Apariciones (2)
void mostrar_submatriz_mas_grande_a_partir_de_un_punto(int matriz[][TAM_MATRIZ], int x, int y); // Ese punto que se recibe sera el vertice

/// Cant. Apariciones (1)
int suma_numeros_sobre_y_debajo_diagonal_principal(int matriz[][TAM_MATRIZ]);

/// Cant. Apariciones (1)
void producto_matrices(int m1[][TAM_MATRIZ], int m2[][TAM_MATRIZ]);


#endif // MATRICES_H_INCLUDED
