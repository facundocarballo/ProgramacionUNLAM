#include "cadenas.h"

const char* ultimoCaracter(const char* pCad)
{
    while(*(pCad + 1)) pCad++;

    return pCad;
}

/// ANIta lAva lA tINa
int es_palindromo(const char* pCad)
{
    const char* pFinCad = ultimoCaracter(pCad);
    int esPalindromo = 1;

    while(*pCad && esPalindromo)
    {
        /// Sacamos los espacios en blanco de pCad
        while(*pCad && !ES_LETRA(*pCad)) pCad++;
        /// Sacamos los espacios en blanco de pFinCad
        while(*pFinCad && !ES_LETRA(*pFinCad)) pFinCad--;

        /// Evaluamos que sean palindromo
        while(ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pFinCad)))
        {
            pCad++;
            pFinCad--;
        }

        if (ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pFinCad)))
            esPalindromo = 0;
    }

    return esPalindromo;
}

const char* strstr_alu(const char* pCad, const char* pSubCad)
{
    const char* pIniSubCad = pSubCad;
    const char* pIni = NULL;
    int encontrada = 0;
    while(*pCad && !encontrada)
    {
        /// Buscamos la primer letra de la subcadena en la cadena
        while(*pCad && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pSubCad)))
            pCad++;

        if (*pCad) pIni = pCad;

        /// Verificamos que sea la subcadena correspondiente
        while(*pCad && *pSubCad && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pSubCad)))
        {
            pCad++;
            pSubCad++;
        }

        if (!*pSubCad)
        {
            /// Encontramos la subcadena
            encontrada = 1;
        }
        else
        {
            /// No encontramos la subcadena
            pSubCad = pIniSubCad;
            pIni = NULL;
        }

    }

    return pIni;
}
