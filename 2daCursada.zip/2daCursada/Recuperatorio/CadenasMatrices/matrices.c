#include "matrices.h"

void mostrar_matriz(int matriz[][TAM_MATRIZ])
{
    int fila, columna;

    for(fila = 0; fila < TAM_MATRIZ; fila++)
    {
        for(columna = 0; columna < TAM_MATRIZ; columna++)
        {
            printf("%*d", 5, matriz[fila][columna]);
        }
        printf("\n");
    }
}

void trasponer_matriz_in_situ(int matriz[][TAM_MATRIZ])
{
    int fila, columna, aux;

    for(fila = 0; fila <= (TAM_MATRIZ/2); fila++)
    {
        for (columna = fila + 1; columna < TAM_MATRIZ; columna++ )
        {
            aux = matriz[fila][columna];
            matriz[fila][columna] = matriz[columna][fila];
            matriz[columna][fila] = aux;
        }
    }
}

void producto_matrices(int m1[][TAM_MATRIZ], int m2[][TAM_MATRIZ])
{
    int fila, columna;

    for (fila = 0; fila < TAM_MATRIZ; fila++)
    {
        for (columna = 0; columna < TAM_MATRIZ; columna++)
        {
            m1[fila][columna] *= m2[fila][columna];
        }
    }
}


int suma_numeros_sobre_y_debajo_diagonal_principal(int matriz[][TAM_MATRIZ])
{
    int fila, columna, r = 0;

    /// Sumamos los numeros por encima de la diagonal principal
    for(fila = 0; fila < (TAM_MATRIZ/2); fila++)
    {
        for (columna = fila+1; columna < TAM_MATRIZ; columna++)
        {
            r += matriz[fila][columna];
        }
    }

    /// Sumamos los numeros por debajo de la diagonal principal
    for (fila = 1; fila < TAM_MATRIZ; fila++)
    {
        for (columna = 0; columna < fila; columna++)
        {
            r += matriz[fila][columna];
        }
    }

    return r;
}
