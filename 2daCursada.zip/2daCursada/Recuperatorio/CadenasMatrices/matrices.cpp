#include "matrices.h"

void mostrar_matriz(matriz[][TAM_MATRIZ])
{
    int fila, columna;

    for(fila = 0; fila < TAM_MATRIZ; fila++)
    {
        for(columna = 0; columna < TAM_MATRIZ; columna++)
        {
            printf("%*d", columna*5, matriz[fila][columna]);
        }
        printf("\n");
    }
}

void trasponer_matriz_in_situ(int matriz[][TAM_MATRIZ])
{
    int fila, columna, aux;

    for(fila = 0; fila < columna; fila++)
    {
        for (columna = 1; columna < TAM_MATRIZ; columna++ )
        {
            aux = matriz[fila][columna];
            matriz[fila][columna] = matriz[columna][fila];
            matriz[columna][fila] = aux;
        }
    }
}
