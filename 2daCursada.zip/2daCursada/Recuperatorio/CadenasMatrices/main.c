#include <stdio.h>
#include <stdlib.h>

#include "cadenas.h"
#include "matrices.h"

void mostrar_si_es_palindromo(const char* cad)
{
    if (es_palindromo(cad))
    {
        printf("\"%s\" es palindromo\n", cad);
    }
    else
    {
        printf("\"%s\" NO es palindromo\n", cad);
    }
}

int main()
{
    char palindromo[] = {"ANIta lAva lA tINa"};
    char cadena[] = {"Esta es una cadena normal"};

    int matriz[][TAM_MATRIZ] = {
        {1,2,3},
        {4,5,6},
        {7,8,9},
    };
    int matriz2[][TAM_MATRIZ] = {
        {3,2,3},
        {9,3,1},
        {1,7,4},
    };

    mostrar_si_es_palindromo(palindromo);
    mostrar_si_es_palindromo(cadena);

    puts("Encontrar subcadena");

    const char* s = strstr_alu(palindromo, "tina");

    printf("%s (%p)\n", s, s);

    mostrar_matriz(matriz);
    trasponer_matriz_in_situ(matriz);
    printf("\n");
    mostrar_matriz(matriz);

    printf("\n");

    producto_matrices(matriz, matriz2);
    mostrar_matriz(matriz);

    printf("\n");

    int r = suma_numeros_sobre_y_debajo_diagonal_principal(matriz2);

    printf("Resultado: %d\n", r);

    return 0;
}
