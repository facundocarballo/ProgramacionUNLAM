#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cadenas.h"

int main()
{
    char palindromo[] = {"Anita lava la TinA"};
    char cadena[] = {"Esta es una cadena normal"};
    char cadenaDestino[50];
    char cad1[50] = {"Mundo!"};
    char cad2[] = {"Hola "};
    char cadenaAcomprimir[] = {"PPPPPAAGGGGABBBBBBBB"};


    puts("FUNCION DE PALINDROMO");

    if (es_palindromo(palindromo))
    {
        puts("ES PALINDROMO");
    }

    if (es_palindromo(cadena))
    {
        puts("ES PALINDROMO");
    }


    puts("FUNCION DE STRSTR_ALU");
    const char* str = strstr_alu(palindromo, "anita");
    printf("%s (0x%p)\n", str, str);


    puts("FUNCION DE BUSCAR_CADENA_REMP");
    char* cad = buscar_subcadena_y_reemplazar(cadena, "esta", "this");
    printf("%s (0x%p)\n", cad, cad);

    puts("FUNCION DE OBTENER SUB_CADENA");
    obtener_subcadena(cadena, cadenaDestino, 0, 2);
    printf("%s (0x%p)\n", cadenaDestino, cadenaDestino);


    puts("STRCAT PRIMER PARCIAL");
    strcat_primer_parcial(cad1, cad2);
    printf("%s (0x%p)\n", cad1, cad1);

    puts("Comprimir cadena");
    comprimir_cadena(cadenaAcomprimir);
    printf("%s (0x%p)\n", cadenaAcomprimir, &cadenaAcomprimir);

    return 0;
}
