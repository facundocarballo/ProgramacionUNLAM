#ifndef CADENAS_H_INCLUDED
#define CADENAS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define ES_MAYUSCULA(x)(x >= 'A' && x <= 'Z')
#define ES_MINUSCULA(x)(x >= 'a' && x <= 'z')
#define ES_LETRA(x)(ES_MAYUSCULA(x) || ES_MINUSCULA(x))
#define A_MINUSCULA(x)(ES_MAYUSCULA(x) ? x+('a'-'A') : x)


/// Auxiliares
const char* ultimoCaracter(const char* pCad);

/// Cant. Apariciones (1)
int es_palindromo(const char* pCad);

/// Cant. Apariciones (2)
const char* strstr_alu(const char* pCad, const char* pSubCad);

/// Cant. Apariciones (2)
char* buscar_subcadena_y_reemplazar(char* pCad, const char* pSubCad, const char* pSubCadReemp);

/// Cant. Apariciones (1)
char* obtener_subcadena(const char* pCad, char* pCadDest, int ini, int fin);

/// Cant. Apariciones (2)
char* strcat_primer_parcial(char* pCad1, const char* pCad2);

/// Cant. Apariciones (1)
void comprimir_cadena(char* pCad); // Ej.: PPPPPAAGGGGABBBBBBBB -> P5A2G4A1B8

#endif // CADENAS_H_INCLUDED
