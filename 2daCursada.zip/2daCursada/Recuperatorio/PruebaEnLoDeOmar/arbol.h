#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED

typedef struct sNodo
{
    void* info;
    unsigned tamInfo;
    struct sNodo *izq, *der;
} tNodoA;

typedef tNodoA* tArbolBinBusq;


/// Funciones
/// ARBOL.H


/// Cant. Apariciones (5)
int op_alta();

/// Cant. Apariciones (3)
int op_baja();

/// Cant. Apariciones (1)
int op_bajas_masivas(); // utilizando una cola y pidiendo confirmacion por parte del usuario

/// Cant. Apariciones (3)
void op_listar_indice();

/// Cant. Apariciones (3)
void validar_arbol(); // Decir si es un arbol completo, balancead, AVL o ninguno de ellos

/// Cant. Apariciones (1)
tNodoA** buscar_nodo_arbol_bin_busq();

/// Cant. Apariciones (3)
tNodoA** op_obtener_alumno_mejor_promedio(); // buscar_mayor_nodo_no_clave()

/// Cant. Apariciones (4)
int cargar_arbol_archivo_ordenado();

/// Cant. Apariciones (1)
int cargar_arbol_archivo_preorden();

/// Cant. Apariciones (1)
int grabar_arbol_en_archivo_indice_preorden();

/// Cant. Apariciones (1)
void generar_archivo_indices();

/// Cant. Apariciones (2)
int compactar_y_reindexar();

/// Cant. Apariciones (4)
void op_listar_arch_alumnos();

#endif // ARBOL_H_INCLUDED
