#include "cadenas.h"


/// Auxiliares
const char* ultimoCaracter(const char* pCad)
{
    while (*(pCad+1)) pCad++;

    return pCad;
}

int strlen_alu(const char* pCad)
{
    int len = 0;
    while(*pCad)
    {
        len++;
        pCad++;
    }

    return len;
}

/// Cant. Apariciones (1)
int es_palindromo(const char* pCad)
{
    /// AnitA LavA lA TInA

    const char* pFinCad = ultimoCaracter(pCad);
    int esPalindromo = 1;

    while(*pCad && esPalindromo)
    {
        /// Quitamos de pCad todo lo que no sea una letra
        while(*pCad && !ES_LETRA(*pCad)) pCad++;

        /// Quitamos de pFinCad lo que no sea una letra
        while(*pFinCad && !ES_LETRA(*pFinCad)) pFinCad--;

        /// Analizamos si son palindromo
        while(ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pFinCad)))
        {
            pCad++;
            pFinCad--;
        }

        if (ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pFinCad)))
        {
            esPalindromo = 0;
        }
    }

    return esPalindromo;
}

/// Cant. Apariciones (2)
const char* strstr_alu(const char* pCad, const char* pSubCad)
{
    /// Encontrar una subcadena dentro de una cadena

    const char* pIniSubCad = pSubCad;
    const char* pRet = NULL;

    while(*pCad && *pSubCad && !pRet)
    {
        /// Encontramos la primer letra que coincide
        while(*pCad && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pSubCad)) ) pCad++;

        if (*pCad) pRet = pCad;

        /// Comprobamos que sean la misma cadena
        while(*pCad && *pSubCad && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pSubCad)))
        {
            pCad++;
            pSubCad++;
        }

        /// Si *pSubCad != '\0' no se encontro la subcadena
        if (*pSubCad)
        {
            pRet = NULL;
            pSubCad = pIniSubCad;
        }

    }

    return pRet;

}

/// Cant. Apariciones (2)
char* buscar_subcadena_y_reemplazar(char* pCad, const char* pSubCad, const char* pSubCadReemp)
{
    const char* pIniSubCad = pSubCad;
    char* pRet = NULL;
    char* aux = NULL;

    while(*pCad && *pSubCad && !pRet)
    {
        /// Encontramos la primer letra que coincide
        while(*pCad && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pSubCad))) pCad++;

        if (*pCad) pRet = pCad;

        /// Nos fijamos que coincida toda la subcadena
        while(*pCad && *pSubCad && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pSubCad)))
        {
            pCad++;
            pSubCad++;
        }

        if (*pSubCad)
        {
            pRet = NULL;
            pSubCad = pIniSubCad;
        }
        else
        {
            aux = pRet;
            /// Encontramos la subcadena, hay que reemplazarla
            while(pRet != pCad)
            {
                *pRet = *pSubCadReemp;
                pRet++;
                pSubCadReemp++;
            }

            pRet = aux;
        }
    }

    return pRet;
}

/// Cant. Apariciones (1)
char* obtener_subcadena(const char* pCad, char* pCadDest, int ini, int fin)
{
    char* pIniCadDest = pCadDest;
    const char* pIniSubCad = pCad+ini;
    const char* pFinSubCad = pCad+fin;

    /// Copiamos el contenido dentro de esta nueva cadena
    while(pIniSubCad <= pFinSubCad)
    {
        *pCadDest = *pIniSubCad;
        pCadDest++;
        pIniSubCad++;
    }

    *pCadDest = '\0';

    return pIniCadDest;
}

/// Cant. Apariciones (2)
char* strcat_primer_parcial(char* pCad1, const char* pCad2)
{
    /// Cad1 = "Mundo!"
    /// Cad2 = "Hola "


    /// "Hola Mundo!"
    /// Resultado Final = "Hola Mundo!"

    int lenCad1 = strlen_alu(pCad1), lenCad2 = strlen_alu(pCad2);
    char* pCadFinal = pCad1 + lenCad1 + lenCad2;
    char* lector = pCad1 + lenCad1 - 1;

    /// Marcamos que ahi sera el final de nuestra nueva cadena
    pCadFinal = '\0';
    pCadFinal--;

    puts("173");

    while(lector >= pCad1)
    {
        puts("Entro");
        *pCadFinal = *lector;
        lector--;
        pCadFinal--;
    }
    /// Queda asi... "MundoMundo!"

    puts("185");

    lector = pCad1;

    while(*pCad2)
    {
        *lector = *pCad2;
        lector++;
        pCad2++;
    }

    puts("196");
    /// Queda asi... "Hola Mundo!"


    return pCad1;
}

/// Cant. Apariciones (1)
void comprimir_cadena(char* pCad)
{
    // Ej.: PPPPPAAGGGGABBBBBBBB -> P5A2G4A1B8
    char letra;
    char* escribir = pCad;
    int cant = 1;


    while(*pCad)
    {
        letra = *pCad;

        while(*pCad && (*pCad == *(pCad+1)))
        {
            pCad++;
            cant++;
        }

        /// Escribimos la letra y la cantidad de apariciones
        *escribir = letra;
        escribir++;

        *escribir = 48 + cant; /// 48 es el '0' en ASCII y le suma la cantidad de Apariciciones (MAX 9)
        escribir++;

        /// Volvemos a poner el cant en 1
        cant = 1;


        pCad++;
    }

    *escribir = '\0';

}
