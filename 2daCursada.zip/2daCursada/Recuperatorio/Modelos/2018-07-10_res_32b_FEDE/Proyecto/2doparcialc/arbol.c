#include <Tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <Arbol.h>
#include <math.h>

int eliminar_de_arbol(t_arbol* pa, t_info* pd, t_cmp cmp)
{
    return TODO_OK;
}

void recorrer_arbol_en(const t_arbol* pa, void (*accion)(t_info* pinfo, void* datos_accion), void* datos_accion)
{

}
