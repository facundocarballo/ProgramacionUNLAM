#include <stdio.h>
#include <stdlib.h>
#define FIL 4
#define COL 4

void mostrar_matriz(int m[][COL],int f,int c);
void transponer_matriz_sobreSimisma(int m[][COL],int f,int c)
int main()
{
    int mat[FIL][COL]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
    int f=FIL;
    int c=COL;
    mostrar_matriz(mat,f,c);
    printf("\n");
    transponer_matriz(mat,f,c);
    printf("\n");
    mostrar_matriz(mat,f,c);
    return 0;
}

void mostrar_matriz(int m[][COL],int f,int c)
{
    int i,j;
    for(i=0;i<f;i++)
    {
        for(j=0;j<c;j++)
            printf("%d\t",m[i][j]);
        printf("\n");
    }
}

void transponer_matriz_sobreSimisma(int m[][COL],int f,int c)
{
    int i,j,aux;
    for(i=0;i<f;i++)
    {
        for(j=0;j<c/2;j++)
        {
            aux=m[i][j];
            m[i][j]=m[i][c-1-j];
            m[i][c-1-j]=aux;
        }
    }
}
