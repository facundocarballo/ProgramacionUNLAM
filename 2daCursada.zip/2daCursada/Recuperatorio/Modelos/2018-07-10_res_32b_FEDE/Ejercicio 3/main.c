#include "funciones.h"

int main()
{
    char cadena[]={"Desarrolle una  funciones que realice, dentro de una cadena, el reemplazo de todas las ocurrencias de una subcadena por otra cadena"};
//    char cadena[]={"anana jejeje anajode an"};
    char reemplazo[]={"string"};
    char buscar[]={"cadena"};
    printf("%s",reemplazarUnacadena(cadena,reemplazo,buscar));
    return 0;
}
