#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

char* reemplazarUnacadena(char* cad,char*reemplazo,char*buscar);

#endif // FUNCIONES_H_INCLUDED
