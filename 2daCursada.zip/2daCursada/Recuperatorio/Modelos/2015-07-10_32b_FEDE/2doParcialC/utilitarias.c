#include<utilitarias.h>

int alta (t_alumno * alu, FILE * arch, t_arbol* pa)
{
    ///Escriba aqui el codigo...
    return TODO_OK;
}

int baja (t_alumno * alu, FILE * arch, t_arbol* pa)
{
    ///Escriba aqui el codigo...
    return TODO_OK;
}
