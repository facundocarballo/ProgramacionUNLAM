#include<arbol.h>
int insertar_en_arbol_bin_busq(t_arbol* pa, const t_info* pd, t_cmp cmp) ///Retorna TODO_OK o DUPLICADO
{
    ///Escriba aqui el codigo...
    return TODO_OK;
}

int buscar_en_arbol_bin_busq(const t_arbol* pa, t_info* pd, t_cmp cmp) ///Retorna VERDADERO o FALSO
{
    ///Escriba aqui el codigo...
    return VERDADERO;
}

int eliminar_de_arbol(t_arbol* pa, t_info* pd, t_cmp cmp) ///Retorna TODO_OK o NO_EXISTE
{
    ///OPCIONAL: Debe elegir entre esta funcion y cargar_arbol_de_archivo_ordenado
    return TODO_OK;
}

int cargar_arbol_de_archivo_ordenado(t_arbol* pa, const char* path) ///Retorna TODO_OK, ERROR_ARCHIVO o SIN_MEM
{
    ///OPCIONAL: Debe elegir entre esta funcion y eliminar_de_arbol
    return TODO_OK;
}
