#include<utilitarias.h>
#include<string.h>
#include<varias.h>
#include<ctype.h>

void mayor_promedio(const t_arbol *pa);
int comparar_promedios(const t_alumno * i1, const t_alumno * i2);
float calcula_promedio_alumno(const t_alumno *alu);
void mostrar_alumno(t_info * alu);

void validar_arbol(const t_arbol *pa)
{
    if(es_arbol_completo_res(pa))
    {
        printf("El arbol es completo");
        return;
    }
    if(es_arbol_balanceado(pa))
    {
        printf("El arbol es balanceado");
        return;
    }
    if(es_arbol_avl_res(pa))
    {
        printf("El arbol es avl");
        return;
    }
    printf("No es ninguno");
    return;

}

void mayor_promedio(const t_arbol *pa)
{
    t_alumno mayor;
    mayor_info_arbol(pa,&mayor,comparar_promedios);
    mostrar_alumno(&mayor);
}

int comparar_promedios(const t_alumno * i1, const t_alumno * i2)
{
    return calcula_promedio_alumno(i1) - calcula_promedio_alumno(i2);
}

float calcula_promedio_alumno(const t_alumno *alu)
{
    int i;
    float prom = 0;
    for(i = 0; i< alu->cant_materias;i++)
    {
        prom+= alu->notas[i];
    }
    prom/= alu->cant_materias;

    return prom;

}

void mostrar_alumno(t_info * alu)
{
    int i;
    printf("DNI: %d\nApellido y Nombre: %s\nNotas: ",alu->dni,alu->apyn);
    for(i=0; i< alu->cant_materias;i++)
    {
        printf("-%d ",alu->notas[i]);
    }
    printf("\nPromedio: %0.2f",calcula_promedio_alumno(alu));
}
