#include <Tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <Arbol.h>
#include <math.h>
#define MAYOR(X,Y) ((X)>(Y)?X:Y)

int completo_hasta_nv(const t_arbol *pa, int n);
int contar_nodos(const t_arbol *pa);

int es_arbol_completo(const t_arbol* pa)
{
    return  pow(2,altura_arbol(pa))-1==contar_nodos(pa);

}

int es_arbol_balanceado(const t_arbol* pa)
{
    return completo_hasta_nv(pa,(altura_arbol(pa))-2);
}

int completo_hasta_nv(const t_arbol *pa, int n)
{
    if(n<0)
        return 1;
    if(!*pa)
        return 0;
    return completo_hasta_nv(&(*pa)->pizq,n-1) && completo_hasta_nv(&(*pa)->pder,n-1);
}

int es_arbol_avl(const t_arbol* pa)
{
    int hi,hd;
    if(!*pa)
        return 1;
    hi=altura_arbol(&(*pa)->pizq);
    hd=altura_arbol(&(*pa)->pder);
    if(abs(hi-hd)>1)
        return 0;
    return es_arbol_avl(&(*pa)->pizq) && es_arbol_avl(&(*pa)->pder);
}

int altura_arbol(const t_arbol *pa)
{
    int hi,hd;
    if(!*pa)
        return 0;
    if(!(*pa)->pizq && !(*pa)->pder)
        return 1;
    hi=altura_arbol(&(*pa)->pizq);
    hd=altura_arbol(&(*pa)->pder);
    return MAYOR(hi,hd)+1;
}

void mayor_info_arbol_ini(const t_arbol* pa, t_info* pd,int (*cmp)(const t_info*, const t_info*),t_info *mayor)
{
    if(!*pa)
            return;
    mayor_info_arbol_ini(&(*pa)->pizq,pd,cmp,mayor);

    if(cmp(&(*pa)->info,mayor) > 0)
    {
        *mayor = (*pa)->info;
    }

    mayor_info_arbol_ini(&(*pa)->pder,pd,cmp,mayor);
}

void mayor_info_arbol(const t_arbol* pa, t_info* pd,int (*cmp)(const t_info*, const t_info*))
{
    t_info mayor;
    if(!*pa)
        return;
    mayor = (*pa)->info;
    mayor_info_arbol_ini(pa,pd,cmp,&mayor);
    *pd = mayor;
}

int contar_nodos(const t_arbol *pa)
{
    if(!pa)
        return 0;
    if(!(*pa)->pizq&&!(*pa)->pder)
        return 1;
    return contar_nodos(&(*pa)->pizq)+contar_nodos(&(*pa)->pder)+1;
}
