#ifndef HORADELDIA_H
#define HORADELDIA_H
#include <iostream>
#include <windows.h>

using namespace std

class HoraDelDia
{
    public:
        HoraDelDia(int h=0,int m=0,int s=0);
        friend ostream& operator<<(ostream& salida,const HoraDelDia &obj);
        bool operator>=(const HoraDelDia &obj)const;
        HoraDelDia operator++();
        HoraDelDia operator+(const HoraDelDia &obj)const;
        ~HoraDelDia();


    private:
        int seg;
        int minu;
        int horas;
};

#endif // HORADELDIA_H
