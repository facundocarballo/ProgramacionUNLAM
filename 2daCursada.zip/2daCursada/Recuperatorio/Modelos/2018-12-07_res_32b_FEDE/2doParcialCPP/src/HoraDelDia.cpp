#include "HoraDelDia.h"

HoraDelDia::HoraDelDia(int h=0,int m=0,int s=0)
{
    this->horas=h;
    this->minu=m;
    this->seg=s;
}
HoraDelDia HoraDelDia::operator>=(const HoraDelDia &obj)cons
{
    if(this->horas>=obj.horas)
        return this;
    if(this->minu>=obj.minu)
        return this;
    if(this->seg>=obj.seg)
        return this;
    return &obj;
}
HoraDelDia::~HoraDelDia()
{
    delete(this);
}
