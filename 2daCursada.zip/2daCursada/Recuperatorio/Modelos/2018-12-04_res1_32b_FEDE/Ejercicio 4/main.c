#include "funciones.h"

int main()
{
    char cad1[TAM]="esta completamente solita";
    char cad2[TAM]="Anita la huerfanita ";
    printf("STRCAT REVERSO: %s",mi_strcat_reverso(cad1,cad2));
    return 0;
}
