#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#define TAM 100

char *mi_strcat_reverso(char*, const char *);
size_t my_strlen(const char* s);

#endif // FUNCIONES_H_INCLUDED
