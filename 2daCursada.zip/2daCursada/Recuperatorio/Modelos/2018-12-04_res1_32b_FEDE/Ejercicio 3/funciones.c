#include "funciones.h"



void mayor_matriz_cuadrada(int mat[][COL], int fil, int col)
{
    int i, j;
    int fila, columna;
    printf("Ingrese la fila y columna vertice: ");
    scanf("%d %d",&fila,&columna);
    fila--;
    columna--;
    for(j=((columna==)?))
    {
        for(i=((fila==fil-1)?0:1);i<;i++)
        {
            printf("[%d]",mat[i][j]);
        }
    }
}
