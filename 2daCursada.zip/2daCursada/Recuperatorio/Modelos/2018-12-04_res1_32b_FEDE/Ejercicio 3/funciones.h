#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#define FIL 100
#define COL 100

void mayor_matriz_cuadrada(int mat[][COL], int fil, int col);


#endif // FUNCIONES_H_INCLUDED
