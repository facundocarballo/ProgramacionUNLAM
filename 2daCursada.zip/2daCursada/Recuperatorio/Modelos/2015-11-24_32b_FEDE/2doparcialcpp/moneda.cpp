#include <iostream>
#include "moneda.h"

using namespace std;

void Moneda :: setValorMoneda( Moneda::moneda, double valorMoneda )
{
    Moneda::moneda = valorMoneda;
}
