#ifndef MONEDA_H_INCLUDED
#define MONEDA_H_INCLUDED

class Moneda
{
private:
    double pesosArg;
    static double tipoMoneda;
public:
    static const double usd;
    static const double rs;
    static const double uyu;
    static void setValorMoneda( Moneda::moneda , double valorMoneda );
};


#endif // MONEDA_H_INCLUDED
