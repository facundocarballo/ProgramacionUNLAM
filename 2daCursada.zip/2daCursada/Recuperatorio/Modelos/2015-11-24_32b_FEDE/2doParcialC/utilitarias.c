#include<utilitarias.h>

void validar_arbol(const t_arbol *pa)
{
   ///Inserte codigo ac�...
}

void imprimir_info(t_info* pinfo, void* datos_accion)
{
    ///Inserte codigo ac�...
}

void imprimir_listado(const t_arbol *pa)
{
    ///Puede Utilizar las funciones de recorrida de arbol provistas o desarrollar las suyas

}
