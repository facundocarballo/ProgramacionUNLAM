#include<arbol.h>
#include<math.h>
#include <stdio.h>
#include <stdlib.h>

int insertar_en_arbol_bin_busq(t_arbol* pa, const t_info* pd, t_cmp cmp)
{
    ///Inserte codigo ac�...
    return TODO_OK;
}

int es_arbol_avl(const t_arbol* pa)
{
    ///Inserte codigo ac�...
    return 1;
}
int es_arbol_balanceado(const t_arbol* pa)
{
    ///Inserte codigo ac�...

    return 1;
}
int es_arbol_completo(const t_arbol* pa)
{
    ///Inserte codigo ac�...
    return 1;
}

int cargar_arbol_de_archivo_ordenado(t_arbol* pa, const char* path)
{
    ///Inserte codigo ac�...
    return TODO_OK;
}
