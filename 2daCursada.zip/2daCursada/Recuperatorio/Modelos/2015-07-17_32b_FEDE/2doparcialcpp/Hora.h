#ifndef HORA_H_INCLUDED
#define HORA_H_INCLUDED

using namespace std;

class Hora
{
private:
    int segundos;
public:

    ///CONSTRUCTORES///

    Hora() : segundos(0){}
    Hora( int hora, int minutos, int segundos );
//    Hora( const Hora& obj ) : segundos(obj.segundos){}

    ///METODOS///

    Hora&operator = ( const Hora& );
//    int convertir_hora_a_segundos( const Hora& horaRelativa );
//    Hora convertir_seg_a_hora( int segundos );
    Hora operator + ( const Hora& )const;
    Hora operator - ( const Hora& )const;
//    Hora operator * ( const Hora& )const;
//    Hora operator / ( const Hora& )const;
//    Hora&operator += ( const Hora& );
//    Hora&operator -= ( const Hora& );
//    Hora&operator *= ( const Hora& );
//    Hora&operator /= ( const Hora& );
    bool operator >= ( const Hora& obj )const;
    bool operator < ( const Hora& obj )const;
    int operator + ( const Hora& obj );
    Hora&operator = (int segundos);
    Hora&operator += (int segundos);
//    Hora& operator ++ ();
    Hora operator ++ (int);
    friend ostream & operator << (ostream & salida, const Hora& obj);
    friend istream & operator >> (istream & entrada, Hora& obj);
//    Hora& operator -- ();
//    Hora operator -- (int);
//    void mostrar();
};


#endif // HORA_H_INCLUDED

