#include <iostream>
#include "Hora.h"

using namespace std;

Hora :: Hora( int hora, int minutos, int segundos )
{
    this->segundos = segundos + minutos * 60 + hora * 3600;
}

Hora& Hora :: operator = ( const Hora& obj )
{
    this->segundos = obj.segundos;

    return *this;
}

Hora Hora :: operator + ( const Hora& obj)const
{
    int horaObj, minutosObj, segundosObj;
    int horaThis, minutosThis, segundosThis;

    segundosObj = obj.segundos % 60;
    minutosObj = (obj.segundos / 60) % 60;
    horaObj = (obj.segundos / 60) / 60;

    segundosThis = this->segundos % 60;
    minutosThis = (this->segundos / 60) % 60;
    horaThis = (this->segundos / 60) / 60;
    return Hora( horaThis + horaObj, minutosThis + minutosObj, segundosThis + segundosObj );
}

Hora Hora :: operator - ( const Hora& obj)const
{
    int horaObj, minutosObj, segundosObj;
    int horaThis, minutosThis, segundosThis;

    segundosObj = obj.segundos % 60;
    minutosObj = (obj.segundos / 60) % 60;
    horaObj = (obj.segundos / 60) / 60;

    segundosThis = this->segundos % 60;
    minutosThis = (this->segundos / 60) % 60;
    horaThis = (this->segundos / 60) / 60;

    return Hora ( horaThis - horaObj, minutosThis - minutosObj, segundosThis - segundosObj );
}

//Hora& Hora :: operator += ( const Hora& obj )
//{
//    this->segundos += obj.segundos;
//
//    return *this;
//}
//
//Hora& Hora :: operator -= ( const Hora& obj )
//{
//    this->segundos -= obj.segundos;
//
//    return *this;
//}

bool Hora :: operator >= ( const Hora& obj )const
{
    return ( segundos >= obj.segundos );
}

bool Hora :: operator < ( const Hora& obj )const
{
    return ( segundos < obj.segundos );
}

//Hora& Hora :: operator ++ ()///PREINCREMENTO
//{
//    segundos++;
//    return *this;
//}

int Hora :: operator + (const Hora& obj)
{
    return obj.segundos;
}

Hora& Hora :: operator = (int segundos)
{
    this->segundos = segundos;
    return *this;
}

Hora& Hora :: operator += (int segundos)
{
    this->segundos += segundos;
    return *this;
}

Hora Hora :: operator ++ (int)///POSTINCREMENTO
{
    Hora aux(*this);
    segundos++;
    return aux;
    ///return Complejo (this->x++,this->y++);
}

ostream& operator << (ostream& salida, const Hora& obj)
{
    int horaObj, minutosObj, segundosObj;
    segundosObj = obj.segundos % 60;
    minutosObj = (obj.segundos / 60) % 60;
    horaObj = ((obj.segundos / 60) / 60) % 24;
    salida << horaObj << ":" << minutosObj << ":" << segundosObj << endl;
    return salida;
}

istream& operator >> (istream& entrada, Hora& obj)
{
    int hora, minutos, segundos;
    cout << "Ingrese la hora: ";
    entrada >> hora;
    cout << "Ingrese los minutos: ";
    entrada >> minutos;
    cout << "Ingrese los segundos: ";
    entrada >> segundos;
    obj.segundos = segundos + minutos * 60 + hora * 3600;
    return entrada;
}

//Hora& Hora :: operator -- ()///PREINCREMENTO
//{
//    segundos--;
//    return *this;
//}
//
//Hora Hora :: operator -- (int)///POSTINCREMENTO
//{
//    Hora aux(*this);
//    segundos--;
//    return aux;
//    ///return Complejo (this->x++,this->y++);
//}

//void Hora :: mostrar()
//{
//    int horaObj, minutosObj, segundosObj;
//    segundosObj = segundos % 60;
//    minutosObj = (segundos / 60) % 60;
//    horaObj = ((segundos / 60) / 60) % 24;
//    cout<< horaObj << ":" << minutosObj << ":" << segundosObj <<endl;
//}
