#include<arbol.h>
int es_arbol_avl(const t_arbol* pa)
{
    ///Escriba aqui el codigo
    return 0;
}
int es_arbol_balanceado(const t_arbol* pa)
{
    ///Escriba aqui el codigo
    return 0;
}
int es_arbol_completo(const t_arbol* pa)
{
    ///Escriba aqui el codigo
    return 0;
}

