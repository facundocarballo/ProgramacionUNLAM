#include<utilitarias.h>

void validar_arbol(const t_arbol *pa)
{
    ///Escriba aqui el c�digo.
}

void imprimir_listado(const t_arbol *pa)
{
    ///Escriba aqui el c�digo.
    ///Puede Utilizar las funciones de recorrida de arbol provistas o desarrollar las suyas
}
