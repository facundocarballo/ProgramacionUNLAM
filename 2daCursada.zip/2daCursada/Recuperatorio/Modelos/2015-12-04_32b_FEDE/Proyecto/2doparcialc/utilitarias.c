#include<utilitarias.h>
#include<varias.h>


int alta (int dni, t_arbol* pa)
{
    ///Inserte codigo ac�...
    return TODO_OK;
}

int baja (int dni, t_arbol* pa)
{
    ///Inserte codigo ac�...
    return TODO_OK;
}
