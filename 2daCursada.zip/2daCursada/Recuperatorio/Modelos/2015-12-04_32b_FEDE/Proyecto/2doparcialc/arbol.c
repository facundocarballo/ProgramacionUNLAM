#include<arbol.h>

int insertar_en_arbol_bin_busq(t_arbol* pa, const t_info* pd, t_cmp cmp) ///Retorna TODO_OK, DUPLICADO O SIN_MEM
{
    ///Inserte codigo ac�...
    return TODO_OK;
}

int buscar_en_arbol_bin_busq(const t_arbol* pa, t_info* pd, t_cmp cmp) ///Retorna VERDADERO o FALSO
{
    ///Inserte codigo ac�...
    return VERDADERO;
}

int eliminar_de_arbol(t_arbol* pa, t_info* pd, t_cmp cmp) ///Retorna TODO_OK o NO_EXISTE
{
   ///Inserte codigo ac�...
    return TODO_OK;
}


void arbol_grafico(const t_arbol* pa, t_mostrar_clave fn_muestra)
{
   ///Inserte codigo ac�...
}

int cargar_arbol_de_archivo_ordenado(t_arbol *pa,const char *path)
{
    return TODO_OK;
}
