#include "FVector.h"

FVector::FVector()
{
    this->vec=NULL;
    this->cant=0;
}

FVector::FVector(const FVector &obj)
{
    this->vec=new float[obj.cant];
    if(this->vec==NULL)
        throw bad_alloc();
    this->cant=obj.cant;
}

FVector::~FVector()
{
    delete[]this->vec;
}

FVector::FVector(const float* vec,const int cant)
{
    this->vec=new float[cant];
    if(this->vec==NULL)
        throw bad_alloc();
    this->cant=cant;
    int i;
    for(i=0;i<cant;i++)
    {
        this->vec[i]=*vec;
        vec++;
    }
}

bool FVector::operator==(const FVector &obj) const
{
    if(this->cant!=obj.cant)
        return false;
    int i;
    for(i=0;i<this->cant;i++)
    {
        if(this->vec[i]!=obj.vec[i])
            return false;
    }
    return true;
}

FVector& FVector::operator+=(const float num)
{
    int i;
    for(i=0;i<this->cant;i++)
    {
        this->vec[i]+=num;
    }
    return (*this);
}

ostream& operator<<(ostream& salida,const FVector &obj)
{
    int i=0;
    salida<<'{';
    salida<<obj.vec[i];
    for(i=1;i<obj.cant;i++)
    {
        salida<<',';
        salida<<obj.vec[i];
    }
    salida<<'}';
    return salida;
}

FVector FVector::operator--(int)
{
    FVector res;
    res.vec=new float[this->cant];
    if(res.vec==NULL)
        throw bad_alloc();
    res.cant=this->cant;
    int i;
    for(i=0;i<this->cant;i++)
    {
        res.vec[i]=this->vec[i];
        this->vec[i]--;
    }
    return res;
}

FVector FVector::operator/(const FVector &obj) const
{
    if(this->cant!=obj.cant)
        throw exception();
    FVector res;
    res.vec=new float[this->cant];
    if(res.vec==NULL)
        throw bad_alloc();
    res.cant=this->cant;
    int i;
    for(i=0;i<this->cant;i++)
    {
        res.vec[i]=this->vec[i]/obj.vec[i];
    }
    return res;
}
