#ifndef FVECTOR_H
#define FVECTOR_H

#include <iostream>
using namespace std;

class FVector
{
    public:
        virtual ~FVector();
        FVector(const float* vec,const int cant);
        bool operator==(const FVector &obj) const;
        FVector& operator+=(const float num);
        friend ostream& operator<<(ostream& salida,const FVector &obj);
        FVector operator--(int);
        FVector operator/(const FVector &obj) const;

    private:
        FVector();
        FVector(const FVector &obj);
        float* vec;
        int cant;
};

#endif // FVECTOR_H
