#include<utilitarias.h>
#include<string.h>
#include<varias.h>
#include<tipos.h>

int alta(t_alumno* alu, FILE* arch, t_arbol *pa)
{
    t_info idx;
    idx.dni=alu->dni;
    if(buscar_en_arbol_bin_busq(pa,&idx,comparar)==VERDADERO)
        return DUPLICADO;
    fseek(arch,0L,SEEK_END);
    fwrite(alu,sizeof(t_alumno),1,arch);
    idx.nro_reg=(ftell(arch)/sizeof(t_alumno))-1;
    return insertar_en_arbol_bin_busq(pa,&idx,comparar);
}

void ingresar_alumno(t_alumno* alu)
{
    char ApyNom[100];
    char *aux;
    printf("\nIngrese el dni: ");
    fflush(stdin);
    scanf("%d",&alu->dni);
    printf("\nIngrese el Apellido y Nombre: ");
    fflush(stdin);
    fgets(ApyNom,100,stdin);
    aux=strchr(ApyNom,'\n');
    *aux='\0';
    strcpy(alu->apyn,ApyNom);
    printf("\nIngrese la cantidad de materias: ");
    fflush(stdin);
    scanf("%d",&alu->cant_materias);
    printf("\nIngrese el promedio: ");
    fflush(stdin);
    scanf("%f",&alu->promedio);
    alu->estado='A';
}

int comparar(const t_info *d1, const t_info *d2)
{
    return d1->dni-d2->dni;
}
