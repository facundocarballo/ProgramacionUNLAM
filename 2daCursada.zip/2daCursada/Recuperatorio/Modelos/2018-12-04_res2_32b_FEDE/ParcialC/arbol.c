#include <tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <arbol.h>

int buscar_en_arbol_bin_busq(const t_arbol* pa, t_info* pd, int (*cmp)(const t_info*, const t_info*) )
{
    int comp;
    if(*pa==NULL)
        return FALSO;
    if((comp=cmp(pd,&(*pa)->info))>0)
        return buscar_en_arbol_bin_busq(&(*pa)->pder,pd,cmp);
    else if(comp<0)
        return buscar_en_arbol_bin_busq(&(*pa)->pizq,pd,cmp);
    else
        return VERDADERO;
}

int insertar_en_arbol_bin_busq(t_arbol* pa, const t_info* pd, int (*cmp)(const t_info*, const t_info*) )
{
    int comp;
    t_nodo_arbol *nuevo_nodo;
    if(*pa!=NULL)
    {
    if((comp=cmp(pd,&(*pa)->info))>0)
        return insertar_en_arbol_bin_busq(&(*pa)->pder,pd,cmp);
    else if(comp<0)
        return insertar_en_arbol_bin_busq(&(*pa)->pizq,pd,cmp);
    else
        return DUPLICADO;
    }
    nuevo_nodo=(t_nodo_arbol*)malloc(sizeof(t_nodo_arbol));
    if(nuevo_nodo==NULL)
        return SIN_MEM;
    nuevo_nodo->info=*pd;
    nuevo_nodo->pder=NULL;
    nuevo_nodo->pizq=NULL;
    *pa=nuevo_nodo;
    return TODO_OK;
}

int cargar_arbol_de_archivo_ordenado(t_arbol* pa, const char* path)
{
    FILE* pf;
    int max_reg_arch;
    pf=fopen(path,"rb");
    if(pf==NULL)
        return ERROR_ARCHIVO;
    fseek(pf,0L,SEEK_END);
    max_reg_arch=(ftell(pf)/sizeof(t_info))-1;
    return cargar_arbol_ordenado(pa,pf,0,max_reg_arch);
}

int cargar_arbol_ordenado(t_arbol *pa,FILE* pf,int li,int ls)
{
    int media=(li+ls)/2;
    t_nodo_arbol* nuevo_nodo;
    if(li>ls)
        return TODO_OK;
    fseek(pf,media*sizeof(t_info),SEEK_SET);
    nuevo_nodo=(t_nodo_arbol*)malloc(sizeof(t_nodo_arbol));
    if(nuevo_nodo==NULL)
        return SIN_MEM;
    fread(&(nuevo_nodo->info),sizeof(t_info),1,pf);
    *pa=nuevo_nodo;
    nuevo_nodo->pder=NULL;
    nuevo_nodo->pizq=NULL;
    cargar_arbol_ordenado(&(*pa)->pizq,pf,li,media-1);
    cargar_arbol_ordenado(&(*pa)->pder,pf,media+1,ls);
    return TODO_OK;
}
