#include <iostream>
#include "Distancia.h"

using namespace std;

int main()
{
    /*
    *   1 Metro en Kilometros    = 0,001
    *   1 Metro en Yardas        = 1,09361
    *   1 Metro en Pulgadas      = 39,3701
    */
    Distancia   d1, ///0 metros
                d2(3500.30), ///Por defecto pone Distancia::metros
                d3(2000.00, Distancia::kilometros); ///Crea un objeto con 2000km
    cout << "D1: " << d1 << " D2: " << d2 << " D3: " << d3<<endl;
    cout << "El valor de la suma es: " << (d3 + d2) << endl;
    d1 = 222.30 + d3; ///La constante representa el valor en metros
    cout << "El valor de la suma es D1: " << d1 << endl;
    if (d1>=d3)
        cout<<"D1 es mayor o igual a D3"<<endl;
    else
        cout<<"D1 es menor que D3"<<endl;
    d3.convertir(Distancia::pulgadas);
    d3 += d2;
    cout << "El valor de la suma es: " << d3 << endl;
    d1.convertir(Distancia::yardas);
    cout << "El valor de d1 es: " << d1 << endl;

    return 0;
}
