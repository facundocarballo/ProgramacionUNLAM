#include "ejercicio3.h"

int** generar_matriz_enteros(int fila,int col )
{
    int ** mat ;
    int i ;
    int j ;
    mat =(int**) malloc(fila * sizeof(int*));
    if(!mat)
        return (int**)SIN_MEMORIA;
    for(i=0;i<fila;i++)
       {
        mat[i]=(int *)malloc(col * sizeof(int));
        if(!mat[i])
          {
             for(j=0;j<i;j++)
                 free(mat[j]);
             free(mat);
             return (int**)SIN_MEMORIA;
          }
          for(j=0;j<col;j++)
              mat[i][j]=i+1;

       }
    return mat ;
}

void trasponer_matriz(int** matriz)
{
    int aux;
    int i,j;
    for(i=0;i<FILA;i++)
    {
        for(j=i+1;j<COLUMNA;j++)
        {
            aux=matriz[i][j];
            matriz[i][j]=matriz[j][i];
            matriz[j][i]=aux;
        }
    }
}
