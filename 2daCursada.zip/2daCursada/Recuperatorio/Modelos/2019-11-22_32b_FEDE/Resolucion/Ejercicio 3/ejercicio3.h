#ifndef EJERCICIO3_H_INCLUDED
#define EJERCICIO3_H_INCLUDED


#include <stdio.h>
#include <stdlib.h>

#define FILA 5
#define COLUMNA 5
#define SIN_MEMORIA 0
int** generar_matriz_enteros();
void trasponer_matriz(int** matriz);
#endif // EJERCICIO3_H_INCLUDED
