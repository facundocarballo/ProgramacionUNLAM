#include <stdio.h>
#include <stdlib.h>
#include "ejercicio3.h"
int main()
{
    int** matriz;
    matriz=generar_matriz_enteros(5,5);
    puts("\n matriz sin trasponer");
    for(int i=0; i<FILA; i++)
    {
        puts("\n");
        for(int j=0; j<COLUMNA; j++)
        {
            printf("\t %d",matriz[i][j]);
        }
    }
    puts("\n");
    trasponer_matriz(matriz);
     puts("\n matriz traspuesta");
     for(int i=0; i<FILA; i++)
    {
        puts("\n");
        for(int j=0; j<COLUMNA; j++)
        {
            printf("\t %d",matriz[i][j]);
        }
    }
    return 0;
}
