#ifndef EJERCICIO4_H_INCLUDED
#define EJERCICIO4_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int mi_strlen(const char* cad);
char* sub(const char*cad, int ini, int fin);
#endif // EJERCICIO4_H_INCLUDED
