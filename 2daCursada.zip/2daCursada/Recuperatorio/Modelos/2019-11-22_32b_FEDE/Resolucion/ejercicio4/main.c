#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ejercicio4.h"
int main()
{
    char cad[]="Hola Mundo";
    char* aux=cad;
    char *c1=sub(aux,4,20);
    char* c2=sub(aux,4,6);
       printf("\n Cadena original: %s",aux);
    printf("\n SubCadena inicia en 4, finaliza en 20: %s",c1);
    printf("\n SubCadena inicia en 4, finaliza en 6: %s",c2);


    return 0;
}
