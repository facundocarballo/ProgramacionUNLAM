#include "ejercicio4.h"
int mi_strlen(const char* cad)
{
    int longitud=0;
    while(*cad!='\0')
    {
        cad++;
        longitud++;
    }
    return longitud;
}
char* sub(const char*cad, int ini, int fin)
{
    int i=0,longitud=mi_strlen(cad);
    char* aux;

    if(longitud<fin)
        fin=longitud;
    aux=(char*)malloc(sizeof(char)*(fin-ini+1));
    if(!aux)
        return (char*)0;
    cad+=ini-1;
    while(*cad!='\0'&& i!=(fin-ini+1))
    {
        aux[i]=*cad;
        cad++;
        i++;
    }
    aux[fin]='\0';
    return aux;
}
