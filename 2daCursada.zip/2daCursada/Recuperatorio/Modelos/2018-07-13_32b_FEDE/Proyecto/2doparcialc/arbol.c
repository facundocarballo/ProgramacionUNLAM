#include <Tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <Arbol.h>
#include <math.h>
