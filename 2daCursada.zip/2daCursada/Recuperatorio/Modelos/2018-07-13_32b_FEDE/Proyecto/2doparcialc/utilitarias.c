#include<utilitarias.h>
#include<string.h>
#include<varias.h>
#include<ctype.h>

