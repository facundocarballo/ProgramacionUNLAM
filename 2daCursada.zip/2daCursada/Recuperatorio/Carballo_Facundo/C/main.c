#include <stdio.h>
#include <stdlib.h>

#include "alumnos.h"
#include "lista.h"

int main()
{
    tAlumno alumnos[3] = {
        {
            1,
            20
        },
        {
            4,
            17
        },
        {
            7,
            18
        }
    };

    tLista lista;

    int i;

    crearLista(&lista);

    for(i = 0; i < 3; i++)
    {
        insertarEnListaAlPrincipio(&lista, &alumnos[i], sizeof(tAlumno));
    }

    mostrarLista(&lista, mostrar_alumno);

    puts("\n\nORDENADO POR CANT. MATERIAS\n\n");

    ordenarSeleccionLista(&lista, comparar_alumnos_cantMaterias);

    mostrarLista(&lista, mostrar_alumno);

    puts("\n\nORDENADO POR DNI\n\n");

    ordenarSeleccionLista(&lista, comparar_alumnos_dni);

    mostrarLista(&lista, mostrar_alumno);


    return 0;
}
