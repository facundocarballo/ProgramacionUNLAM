#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "alumnos.h"

#define TODO_OK 1
#define SIN_MEM 2


typedef struct sNodo
{
    void* info;
    unsigned tamInfo;
    struct sNodo* sig;
}tNodo;

typedef tNodo* tLista;

void crearLista(tLista* pl);

void mostrarLista(tLista* pl, void (*mostar)(const void*));

int insertarEnListaAlPrincipio(tLista* pl, void* d, unsigned tamInfo);

tLista* buscarMenorNodoLista(tLista* pl, int (*cmp)(const void*, const void*));

void ordenarSeleccionLista(tLista* pl, int (*cmp)(const void*, const void*));

#endif // LISTA_H_INCLUDED
