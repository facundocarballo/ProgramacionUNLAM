#ifndef ALUMNOS_H_INCLUDED
#define ALUMNOS_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

typedef struct sAlumno
{
    unsigned dni;
    unsigned cantMaterias;
}tAlumno;

/// Funcion de mostrar alumno
void mostrar_alumno(const void* alu);

/// Funciones de comparacion de alumnos
int comparar_alumnos_dni(const void* a, const void* b);
int comparar_alumnos_cantMaterias(const void* a, const void* b);

#endif // ALUMNOS_H_INCLUDED
