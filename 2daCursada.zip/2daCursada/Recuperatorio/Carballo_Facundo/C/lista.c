#include "lista.h"

void crearLista(tLista* pl)
{
    *pl = NULL;
}

void mostrarLista(tLista* pl, void (*mostar)(const void*))
{
    while(*pl)
    {
        mostar((*pl)->info);
        pl = &(*pl)->sig;
    }
}

int insertarEnListaAlPrincipio(tLista* pl, void* d, unsigned tamInfo)
{
    tNodo* nue;

    /// Reservamos memoria para el nuevo nodo
    nue = (tNodo*)malloc(sizeof(tNodo));
    if (!nue || !(nue->info = malloc(tamInfo)))
    {
        free(nue);
        return SIN_MEM;
    }

    /// Armamos el nodo
    nue->sig = *pl;
    nue->tamInfo = tamInfo;
    memcpy(nue->info, d, tamInfo);

    /// Enganchamos el nodo con la lista
    *pl = nue;

    return TODO_OK;
}

tLista* buscarMenorNodoLista(tLista* pl, int (*cmp)(const void*, const void*))
{
    tLista* menor = pl;

    pl = &(*pl)->sig;

    while(*pl)
    {
        //puts("\nMenor\n");
        //mostrar_alumno((*menor)->info);

        //puts("\npl\n");
        //mostrar_alumno((*pl)->info);

        if (cmp((*pl)->info, (*menor)->info) < 0) menor = pl;

        pl = &(*pl)->sig;
    }

    //puts("\nDevolvemos este menor:\n");
   // mostrar_alumno((*menor)->info);

    return menor;
}

void ordenarSeleccionLista(tLista* pl, int (*cmp)(const void*, const void*))
{
    tLista *menor;

    void* infoAux;
    unsigned tamInfoAux;

    while(*pl)
    {
        /// Mientras *pl sea != NULL

        /// Busamos el menor nodo de la lista
        menor = buscarMenorNodoLista(pl, cmp);

        /// Intercambiamos ese nodo por el *pl

        infoAux = (*pl)->info;
        tamInfoAux = (*pl)->tamInfo;

        (*pl)->info = (*menor)->info;
        (*pl)->tamInfo = (*menor)->tamInfo;

        (*menor)->info = infoAux;
        (*menor)->tamInfo = tamInfoAux;


        /// Hacemos que la lista ahora sea pl = &(*pl)->sig
        pl = &(*pl)->sig;
    }

}
