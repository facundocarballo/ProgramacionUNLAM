#include "alumnos.h"

/// Funcion de mostrar alumno
void mostrar_alumno(const void* alu)
{
    tAlumno* pAlu = (tAlumno*)alu;

    printf("DNI: %d\nCant. Materias: %d\n", pAlu->dni, pAlu->cantMaterias);
}

/// Funciones de comparacion de alumnos
int comparar_alumnos_dni(const void* a, const void* b)
{
    tAlumno* aluA = (tAlumno*)a;
    tAlumno* aluB = (tAlumno*)b;

    return aluA->dni - aluB->dni;
}
int comparar_alumnos_cantMaterias(const void* a, const void* b)
{
    tAlumno* aluA = (tAlumno*)a;
    tAlumno* aluB = (tAlumno*)b;

    return aluA->cantMaterias - aluB->cantMaterias;
}

