#include "cadena.h"


/// Constructores
Cadena::Cadena()
{
    cad = new char[1];

    *cad = '\0';
}

Cadena::Cadena(const char* str)
{
    cad = new char[strlen(str)+1];

    strcpy(cad, str);
}

/// Destructores
Cadena::~Cadena()
{
    delete []cad;
}


/// Metodos

/// Operadores
Cadena& Cadena::operator=(const Cadena& obj)
{
    /// Eliminamos la memoria de la cadena que teniamos anteriormente
    delete []cad;

    cad = new char[strlen(obj.cad)+1];

    strcpy(cad, obj.cad);

    return *this;
}

Cadena& Cadena::operator=(const char* str)
{
    delete []cad;

    cad = new char[strlen(str) + 1];

    strcpy(cad, str);

    return *this;
}

Cadena& Cadena::operator+=(const char* str)
{
    char cadAux[strlen(str) + strlen(cad) + 1];

    strcpy(cadAux, cad);

    delete []cad;

    cad = new char[strlen(str) + strlen(cadAux) + 1];

    strcat(cadAux, str);

    strcpy(cad, cadAux);

    return *this;
}

Cadena Cadena::operator+(const Cadena& obj)const
{
    char str[strlen(cad) + strlen(obj.cad) + 1];

    strcpy(str, cad);

    strcat(str, obj.cad);

    return Cadena(str);
}

bool Cadena::operator!=(const Cadena& obj)const
{
    return strcmp(cad, obj.cad);
}

bool Cadena::operator==(const char* str)const
{
    return !strcmp(cad, str);
}

/// Friends
ostream& operator<<(ostream& sal, const Cadena& obj)
{
    sal << obj.cad;

    return sal;
}

istream& operator>>(istream& ent, Cadena& obj)
{
    char nuevaCadena[1000];

    delete []obj.cad;

    ent.getline(nuevaCadena, 1000);

    obj.cad = new char[strlen(nuevaCadena) + 1];

    strcpy(obj.cad, nuevaCadena);

    return ent;
}

Cadena operator+(const char* str, Cadena& obj)
{
    char nuevaCadena[strlen(str) + strlen(obj.cad) + 1];

    strcpy(nuevaCadena, str);

    strcat(nuevaCadena, obj.cad);

    return Cadena(nuevaCadena);
}
