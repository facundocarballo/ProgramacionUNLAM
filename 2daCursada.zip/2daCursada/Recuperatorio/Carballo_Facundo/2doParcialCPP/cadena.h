#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

#include <iostream>
#include <string.h>

using namespace std;

class Cadena
{
private:
    char* cad;

public:
    /// Constructores
    Cadena(const char* str);
    Cadena();
    /// Destructor
    ~Cadena();
    /// Metodos

    /// Operadores
    Cadena& operator=(const Cadena& obj);
    Cadena& operator=(const char* str);
    Cadena& operator+=(const char* str);
    Cadena operator+(const Cadena& obj)const;
    bool operator!=(const Cadena& obj)const;
    bool operator==(const char* str)const;
    /// Friends
    friend ostream& operator<<(ostream& sal, const Cadena& obj);
    friend istream& operator>>(istream& ent, Cadena& obj);
    friend Cadena operator+(const char* str, Cadena& obj);
};

#endif // CADENA_H_INCLUDED
