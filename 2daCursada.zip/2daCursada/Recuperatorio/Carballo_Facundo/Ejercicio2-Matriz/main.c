#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"

int main()
{
    int matriz[TAM_MATRIZ][TAM_MATRIZ];

    cargarMatriz(matriz);

    puts("MATRIZ ORIGINAL: \n");

    mostrarMatriz(matriz);

    intercambiar_elem_primer_cuad_tercer_cuad(matriz);

    puts("\n MATRIZ DESPUES DE INTERCAMBIAR LOS ELEMENTOS DEL PRIMER CUADRANTE POR LOS DEL TERCER CUADRANTE\n");

    mostrarMatriz(matriz);

    return 0;
}
