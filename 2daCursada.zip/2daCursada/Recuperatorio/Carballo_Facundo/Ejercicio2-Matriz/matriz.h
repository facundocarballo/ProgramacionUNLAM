#ifndef MATRIZ_H_INCLUDED
#define MATRIZ_H_INCLUDED

#define TAM_MATRIZ 15

#include <stdio.h>

void mostrarMatriz(int m[][TAM_MATRIZ]);

void cargarMatriz(int m[][TAM_MATRIZ]);

void intercambiar_elem_primer_cuad_tercer_cuad(int m[][TAM_MATRIZ]);


#endif // MATRIZ_H_INCLUDED
