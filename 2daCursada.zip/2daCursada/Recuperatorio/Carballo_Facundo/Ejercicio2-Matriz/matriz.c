#include "matriz.h"

void mostrarMatriz(int m[][TAM_MATRIZ])
{
    int fila, columna;

    for (fila = 0; fila < TAM_MATRIZ; fila++)
    {
        for(columna = 0; columna < TAM_MATRIZ; columna++)
        {
            printf("%5d", m[fila][columna]);
        }
        printf("\n");
    }
}

void cargarMatriz(int m[][TAM_MATRIZ])
{
    int i = 1, fila, columna;

    for (fila = 0; fila < TAM_MATRIZ; fila++)
    {
        for (columna = 0; columna < TAM_MATRIZ; columna++)
        {
            m[fila][columna] = i;
            i++;
        }
    }
}

void intercambiar_elem_primer_cuad_tercer_cuad(int m[][TAM_MATRIZ])
{
    int fila, columna, aux;

    for (fila = 0; fila < (TAM_MATRIZ/2); fila++)
    {
        for(columna = (TAM_MATRIZ/2) + (TAM_MATRIZ%2 == 0 ? 0 : 1); columna < TAM_MATRIZ; columna++)
        {
            aux = m[fila][columna];
            m[fila][columna] = m[columna][fila];
            m[columna][fila] = aux;
        }
    }
}
