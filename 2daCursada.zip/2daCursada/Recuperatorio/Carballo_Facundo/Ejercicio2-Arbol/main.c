#include <stdio.h>
#include <stdlib.h>
#include "tipos.h"
#include "arbol.h"
#include "matriz.h"


int main()
{
    tAlumno alumnos[3] = {
        {
            7,
            17
        },
        {
            5,
            25
        },
        {
            3,
            18
        }
    };

    tArbolBinBusq arbol, *mayor;
    int i;

    crearArbol(&arbol);
    for (i = 0; i < 3; i++)
    {
        insertarEnArbolBinBusqRec(&arbol, &alumnos[i], sizeof(tAlumno), comparar_alumnos_dni);
    }

    mayor = mayorElemNoClaveArbolBinBusq(&arbol, &arbol, comparar_alumnos_cantMaterias);


    mostrar_alumno((*mayor)->info);

    vaciarArbol(&arbol);

    return 0;
}
