#include "arbol.h"

void crearArbol(tArbolBinBusq* pa)
{
    *pa = NULL;
}

void vaciarArbol(tArbolBinBusq* pa)
{
    if (!*pa) return;

    free((*pa)->info);
    free(*pa);

    vaciarArbol(&(*pa)->izq);
    vaciarArbol(&(*pa)->der);

    *pa = NULL;
}

int insertarEnArbolBinBusqRec(tArbolBinBusq* pa, void* d, unsigned tamInfo,
                              int (*cmp)(const void*, const void*))
{
    int r;

    if (*pa)
    {
        if ((r = cmp(d, (*pa)->info)) > 0)
            return insertarEnArbolBinBusqRec(&(*pa)->der, d, tamInfo, cmp);

        if (r < 0)
            return insertarEnArbolBinBusqRec(&(*pa)->izq, d, tamInfo, cmp);

        return CLA_DUP;
    }

    /// Reservamos memoria para el nodo
    (*pa) = (tNodoA*)malloc(sizeof(tNodoA));
    if (!*pa || !((*pa)->info = malloc(tamInfo)))
    {
        free(*pa);
        return SIN_MEM;
    }

    /// Armamos el nodo
    (*pa)->der = (*pa)->izq = NULL;
    (*pa)->tamInfo = tamInfo;
    memcpy((*pa)->info, d, tamInfo);

    return TODO_OK;
}

tArbolBinBusq* mayorElemNoClaveArbolBinBusq(tArbolBinBusq* pa, tArbolBinBusq* mayor,
                                            int (*cmp)(const void*, const void*))
{
    if (!*pa) return mayor;

    if (cmp((*pa)->info, (*mayor)->info) > 0)
        mayor = pa;

    mayor = mayorElemNoClaveArbolBinBusq(&(*pa)->izq, mayor, cmp);
    mayor = mayorElemNoClaveArbolBinBusq(&(*pa)->der, mayor, cmp);

    return mayor;
}

/// Funciones de comparacion
int comparar_alumnos_dni(const void* a, const void* b)
{
    tAlumno* aluA = (tAlumno*)a;
    tAlumno* aluB = (tAlumno*)b;

    return aluA->dni - aluB->dni;
}

int comparar_alumnos_cantMaterias(const void* a, const void* b)
{
    tAlumno* aluA = (tAlumno*)a;
    tAlumno* aluB = (tAlumno*)b;

    return aluA->cantMaterias - aluB->cantMaterias;
}

/// Funciones de mostrar
void mostrar_alumno(const void* a)
{
    tAlumno* alu = (tAlumno*)a;

    printf("DNI: %d\nCant. Materias: %d\n", alu->dni, alu->cantMaterias);
}
