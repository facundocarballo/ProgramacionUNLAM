#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tipos.h"

typedef struct sNodo
{
    void* info;
    unsigned tamInfo;
    struct sNodo *der, *izq;
} tNodoA;

typedef tNodoA* tArbolBinBusq;

/// Funciones de arbol
void crearArbol(tArbolBinBusq* pa);

void vaciarArbol(tArbolBinBusq* pa);

int insertarEnArbolBinBusqRec(tArbolBinBusq* pa, void* d, unsigned tamInfo,
                              int (*cmp)(const void*, const void*));

tArbolBinBusq* mayorElemNoClaveArbolBinBusq(tArbolBinBusq* pa, tArbolBinBusq* mayor,
                                            int (*cmp)(const void*, const void*));


/// Funciones de comparacion
int comparar_alumnos_dni(const void* a, const void* b);
int comparar_alumnos_cantMaterias(const void* a, const void* b);

/// Funciones de mostrar
void mostrar_alumno(const void* a);

#endif // ARBOL_H_INCLUDED
