#ifndef TIPOS_H_INCLUDED
#define TIPOS_H_INCLUDED

#define TODO_OK 1
#define CLA_DUP 2
#define SIN_MEM 0

typedef struct sAlumno
{
    int dni, cantMaterias;
} tAlumno;


#endif // TIPOS_H_INCLUDED
