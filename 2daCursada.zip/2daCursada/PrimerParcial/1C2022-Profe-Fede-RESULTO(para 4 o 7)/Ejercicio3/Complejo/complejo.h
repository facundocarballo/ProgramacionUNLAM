#ifndef COMPLEJO_H_INCLUDED
#define COMPLEJO_H_INCLUDED

#include <iostream>

using namespace std;

class Complejo
{
private:
    int real, imaginario;
public:
    /// Constructores
    Complejo(int r=1, int i=1);
    /// Destructor
    ~Complejo();
    /// Metodos

    /// Operadores
    Complejo& operator=(const Complejo& comp);
    Complejo operator*(const Complejo& comp);
    Complejo operator+(const Complejo& comp);
    /// Friends
    friend Complejo operator*(const int num, const Complejo& comp);
    friend ostream& operator<<(ostream& sal, const Complejo& comp);
};

#endif // COMPLEJO_H_INCLUDED
