#include <stdio.h>
#include <stdlib.h>

int strcat_mio(char* cad1, const char* cad2)
{
    char* aux;
    char* cad1Ini = cad1;
    char* auxIni = aux;


    /// Vamos insertando en el orden que queremos en esta variable auxiliar
    while(*cad2)
    {

        *aux = *cad2;
        printf("%c = %c\n", *aux, *cad2);
        cad2++;
        aux++;
    }

    printf("%s\n", aux);

    while(*cad1)
    {
        *aux = *cad1;
        cad1++;
        aux++;
    }

    printf("%s\n", aux);

    cad1 = cad1Ini;
    aux = auxIni;

    /// Una vez que tenemos la cadena como la queremos en aux, la copiamos a cad1
    while(*auxIni)
    {
        *cad1 = *aux;
        cad1++;
        aux++;
    }

    return 1;

}

int str_len(const char* cad)
{
    int i = 0;

    while(*cad)
    {
        cad++;
        i++;
    }

    return i;
}

char* strcpy_mio(char* dest, const char* orig)
{
    char* ini = dest;

    printf("strcpy_mio\n");

    while(*orig)
    {
        printf("%c = %c\n", *dest, *orig);
        *dest = *orig;
        orig++;
        dest++;
    }
    *dest = '\0';

    return ini;
}

char* str_cat(char* cad1, const char* cad2)
{
    /// Recibimos:
    ///     - cad1 = "mundo!"
    ///     - cad2 = "Hola "
    /// Queremos devolver:
    ///     - cad1 = "Hola mundo!"

    int cad2Length = str_len(cad2);
    int cad1Length = str_len(cad1);
    int i = cad1Length-1;

    /// Desplazamos la cad1 tantos lugares como la nueva cadena ocupe
    while(i >= 0)
    {
        *(cad1+cad2Length+i) = *(cad1+i);
        i--;
    }

    while(*cad2)
    {
        *cad1 = *cad2;
        cad1++;
        cad2++;
    }


    return cad1;
}


int main()
{
    char cad1[] = {"mundo!"};
    char cad2[] = {"Hola "};

    printf("%s\n", cad1);

    str_cat(cad1, cad2);

    printf("%s\n", cad1);

    return 0;
}
