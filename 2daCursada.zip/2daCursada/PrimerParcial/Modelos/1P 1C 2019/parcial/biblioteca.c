#include <biblioteca.h>
#include <utilitarias.h>
#include <string.h>
#include <lista.h>
void actualizar_stock(FILE * arch_libros, FILE * arch_stock, FILE * arch_err)
{


    FILE * stockfile;
    t_libro libro;
    t_libro_stock stock;
//    t_lista lista;
    char linea[50];



   arch_stock = fopen("../Archivos/nuevo_stock.txt","rt");
    if(!arch_stock)
        exit(1);

    arch_libros = fopen("../Archivos/libros.dat","rb");
    if(!arch_libros)
        exit(1);

    fread(&libro,sizeof(t_libro),1,arch_libros);
    fgets(linea,sizeof(linea),arch_stock);

    while(!feof(arch_stock))
    {
        texto_a_stock(linea,&stock);
        //insertar_lista(&lista,&stock,cmp_stock_libro);
        fgets(linea,sizeof(linea),arch_stock);
    }


        if(strcmpi(stock.isbn, libro.isbn)==0)
        {
            fread(&libro,sizeof(t_libro),1,arch_libros);
        }

        if(strcmpi(stock.isbn, libro.isbn)>0)
        {

            {

                stock.stock -= libro.stock;
                fseek(arch_libros,-sizeof(t_libro),SEEK_CUR);
                fwrite(&stock,sizeof(t_libro_stock),1,arch_libros);
                fseek(arch_libros,0L,SEEK_CUR);
            }


        }


}



int isbn_valido(const char * isbn)
{
    return 1;
}
