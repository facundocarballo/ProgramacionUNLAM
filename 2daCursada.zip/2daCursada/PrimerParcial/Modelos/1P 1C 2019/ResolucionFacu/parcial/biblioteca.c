#include <biblioteca.h>
#include <utilitarias.h>
#include <string.h>
#include <lista.h>
void actualizar_stock(FILE * arch_libros, FILE * arch_stock, FILE * arch_err)
{

}



int isbn_valido(const char * isbn)
{
    return 1;
}
