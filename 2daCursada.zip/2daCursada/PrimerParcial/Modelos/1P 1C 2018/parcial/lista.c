#include<lista.h>
#include<stdlib.h>
#include<stdio.h>


int instertar_lista(t_lista * plista, const t_info * pinfo, int (*comp)(const t_info *, const t_info*), void(*acum)(t_info *, const t_info*))
{
    return 0;
}

int sacar_primero_lista(t_lista * plista, t_info * pinfo)
{
    return 0;
}

