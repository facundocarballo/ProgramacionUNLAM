#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <utilitarias.h>
#include <banco.h>

void texto_a_movimiento(const char * cadena,t_movimiento_banco * pmov)
{

}
