#include<lista.h>
#include<stdlib.h>
#include<stdio.h>

int insertar_prim5_lista(t_lista * plista, const t_info * pinfo, int (*comp)(const t_info *, const t_info*))
{
    /// Recorremos la lista hasta encontrar donde posicionar nuestra info
    t_nodo* aux = *plista;
    t_nodo* sig;
    int i = 0;
    while(aux && comp(aux->info, pinfo) < 0)
    {
        aux = aux->psig;
        i++;
    }

    if (aux || i < 5)
    {
        sig = aux->psig;

        free(aux->info);
        free(aux);

        aux = (t_nodo*)malloc(sizeof(t_nodo));
        if(!aux)
        {
            puts("Lista llena");
            return 0;
        }
        aux->info = (t_info*)malloc(sizeof(t_info));
        if (!aux->info)
        {
            puts("Lista llena");
            free(aux);
            return 0;
        }

        aux->psig = sig;
        memcpy(aux->info, pinfo, sizeof(t_info));
    }
}

int comparar(const t_info * dato1,const t_info *dato2)
{
    return dato1->saldo-dato2->saldo;
}
