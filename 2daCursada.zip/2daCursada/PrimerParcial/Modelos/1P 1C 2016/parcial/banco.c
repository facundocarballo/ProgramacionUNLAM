#include<banco.h>
#include<lista.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>

/// MI RESOLUCION

int cuentaValida(char* cad)
{

}

int encontrarCuenta(t_cuenta_banco* cuenta, char* cdoCta, FILE* archCtas)
{
    fread(cuenta, sizeof(t_cuenta_banco), 1, archCtas);
    while(strcmp(cuenta.cod_cta, cdoCta) != && !feof(archCtas))
    {
        fread(cuenta, sizeof(t_cuenta_banco), 1, archCtas);
    }

    if (!feof(archCtas))
    {
        return 1; /// Encontro la cuenta
    }

    return 0; /// Llego a fin de archivo
}

void actualizar_cuentas_alu(FILE* archCtas, FILE* archMovs, FILE* archErr, t_lista* pLista)
{
    /// Leemos los movimentos del archivo de texto
    char cadena[50];
    t_movimiento_banco movimiento;
    t_cuenta_banco cuenta;

    while(fgets(cadena, sizeof(cadena), archMovs))
    {
        /// Pasamos de la cadena a la estructura movimiento
        sscanf(cadena, "%[^|\n]|%c|%f\n", movimiento.cod_cta, &movimiento.tipo_mov, &movimiento.importe);

        /// Verificar que el numero de cuenta sea valido
        if(cuentaValida(movimiento.cod_cta))
        {
            /// Cuenta valida

            /// Actualizamos el archivo cuentas.dat
            if(encontrarCuenta(&cuenta, movimiento.cod_cta, archCtas))
            {
                /// Encontramos la cuenta, la podemos actualizar
                if(movimiento.tipo_mov == 'D')
                {
                    /// Debitamos de la cuenta
                    cuenta.saldo -= movimiento.importe;
                }
                else if (movimiento.tipo_mov == 'C')
                {
                    /// Acreditamos a la cuenta
                    cuenta.saldo += movimiento.importe;
                }

                /// Escribimos el nuevo estado de la cuenta en su lugar y nos posicionamos para la siguiente lectura
                fseek(archCtas, -(long)(sizeof(t_cuenta_banco)), SEEK_CUR);
                fwrite(&cuenta, sizeof(cuenta), 1, archCtas);
                fseek(archCtas, 0L, SEEK_CUR);

            }

            /// Si el saldo es negativo, fijarse si la tenemos que agregar a la lista de los 5 con mayor saldo descubierto
            if(cuenta.saldo < 0)
            {

            }

        }
        else
        {
            /// Cuenta no valida
            fprintf(archErr, "CDO.CTA: %s\n", movimiento.cod_cta);
        }


    }

}




















/// Resolucion de otro ....

void actualizar_cuentas(FILE * arch_ctas, FILE * arch_movs, FILE * arch_err, t_lista *plista)
{
    char cad_mov[19];
    t_movimiento_banco mov;
    t_cuenta_banco cuenta;
    while(fgets(cad_mov,sizeof(cad_mov),arch_movs)){
        texto_a_movimiento(cad_mov,&mov);
        if(!validar_nro_cuenta(&mov)){
            fprintf(arch_err,"%s, %c, %.2f",mov.cod_cta,mov.tipo_mov,mov.importe);
        }
        else{
            fread(&cuenta,sizeof(t_cuenta_banco),1,arch_ctas);
            while(!feof(arch_ctas)){
                if(mov.cod_cta==cuenta.cod_cta){
                    cuenta.saldo+=mov.tipo_mov=='C'?mov.importe:-mov.importe;
                    fseek(arch_ctas,-sizeof(t_cuenta_banco),SEEK_CUR);
                    fwrite(&cuenta,sizeof(t_cuenta_banco),1,arch_ctas);
                    fseek(arch_ctas,0L,SEEK_CUR);
                }
                fread(&cuenta,sizeof(t_cuenta_banco),1,arch_ctas);
            }
        }
    }


}

int validar_nro_cuenta(const t_movimiento_banco * c1)
{
    int n_par=0,n_impar=0,num,verif,i=0;
    while(c1->cod_cta+i){
        if(*(c1->cod_cta+i)=='/'){
            i++;
            verif = *(c1->cod_cta+i)-48;
        }
        if(*(c1->cod_cta+i)-48%2==0){
            n_par*=10;
            n_par+=*(c1->cod_cta+i)-48;
        }
        else{
            n_impar*=10;
            n_impar+=*(c1->cod_cta+i)-48;
        }
        i++;
    }
    num = n_par - n_impar;
    while(num>9)
        num = (num/100) + (num%100)/10 + (num%10);
    if(num!=verif)
        return 0;
    return 1;
}

void ordenar_por_saldo(t_cuenta_banco vec_ctas[],FILE *arch_ctas){
    int i=0,j=0,ce=0;
    fread(&vec_ctas[i],sizeof(t_cuenta_banco),1,arch_ctas);
    while(!feof(arch_ctas)){
        ce++;
        fread(&vec_ctas[i],sizeof(t_cuenta_banco),1,arch_ctas);
    }
   // for(;i<ce;i++){
     //   if(vec_ctas[i].)
    //}
}
