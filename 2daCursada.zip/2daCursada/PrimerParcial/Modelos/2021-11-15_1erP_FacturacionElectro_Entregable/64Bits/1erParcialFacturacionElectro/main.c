#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../Comun/Comun.h"
#include "../SolucionFacturacionElectro/SolucionFacturacionElectro.h"
#include "../Nodo/Nodo.h"

#define ARG_CLIENTES	1
#define ARG_MEDICIONES	2
#define ARG_FACTURAS	3
#define ARG_PROXIMO_NRO_FACTURA 4
#define ARG_CANT_MESES_A_FACTURAR 5

#define MAX_MESES 10

#define MIN(a,b)(a < b ? a : b)

typedef Nodo* Lista;

int extraerMesesAFacturar(char* argv[], Mes* mesesAFacturar);

int generarFacturas_ALU(const char* nombreArchivoClientes, const char* nombreArchivoMediciones, const char* nombreArchivoFacturas, int proximoNroFactura, const Mes* mesesAFacturar, int cantMesesAFacturar);

/// Lista
void crear_lista_alu(Lista* pLista);
int lista_vacia_ALU(Lista* pLista);
int armar_lista_mediciones_ALU(const char* nombreArchivoMediciones, Lista* pLista);
int insertar_primero_lista_ALU(Lista* pLista, const void* info, unsigned tamInfo);
int insertar_lista_ord_ALU(Lista* pLista, const void* info, unsigned tamInfo, Cmp cmp);
int sacar_primero_lista_ALU(Lista* pLista, void* info, unsigned tamInfo);
void imprimir_lista_ALU(Lista* pLista);
int ver_tope_lista_ALU(Lista* pLista, void* info, unsigned tamInfo);
int eliminar_tope_lista_ALU(Lista* pLista);

/// Clientes
int actualizar_cliente_ALU(FILE* fpClientes, Cliente* cliente, Factura* factura);
void imprimir_cliente(Cliente* cliente);

/// Facturas
int armar_archivo_facturas_ALU(const char* nombreArchivoFacturas, const char* nombreArchivoClientes, Lista* pLista, int nroFactura);
double calcular_consumo_ALU(Cliente* cliente, Medicion* medicion);
int armar_factura_ALU(Factura* factura, Medicion* medicion, Cliente* cliente, int nroFactura);
void imprimir_factura(Factura* factura);

/// Medicion
void imprimir_medicion(Medicion* medicion);

/// CMPs
int cmp_nro_cliente_ALU(const void* cliente1, const void* cliente2);

/// Fecha
void imprimir_fecha(Fecha f1);
int diferencia_dias_ALU(Fecha f1, Fecha f2);
int fecha_mayor_ALU(Fecha f1, Fecha f2);
int comparar_fechas_ALU(Fecha f1, Fecha f2);
int cantDiasMes_ALU(int mes, int anio);

int main(int argc, char* argv[])
{
	int ret = generarArchivos();

	if(ret != TODO_OK)
	{
		printf("Error al generar archivos\n");
		return ret;
	}

	printf("Archivos generados correctamente\n");

	puts("\nAntes de Actualizar:\n");

	mostrarClientes(argv[ARG_CLIENTES]);

	mostrarMediciones(argv[ARG_MEDICIONES]);

	Mes mesesAFacturar[MAX_MESES];

	int cantMesesAFacturar = extraerMesesAFacturar(argv, mesesAFacturar);

    /// ret = generarFacturas(argv[ARG_CLIENTES], argv[ARG_MEDICIONES], argv[ARG_FACTURAS], atoi(argv[ARG_PROXIMO_NRO_FACTURA]), mesesAFacturar, cantMesesAFacturar);
	/// Descomente esta línea y comente la de arriba, para ejecutar su código
    ret = generarFacturas_ALU(argv[ARG_CLIENTES], argv[ARG_MEDICIONES], argv[ARG_FACTURAS], atoi(argv[ARG_PROXIMO_NRO_FACTURA]), mesesAFacturar, cantMesesAFacturar);

	if(ret != TODO_OK)
	{
		printf("Error al generar facturas\n");
		return ret;
	}

	puts("\nDespues de Actualizar:\n");

	mostrarFacturas(argv[ARG_FACTURAS]);

	mostrarClientes(argv[ARG_CLIENTES]);

	return ret;
}


int extraerMesesAFacturar(char* argv[], Mes* mesesAFacturar)
{
	int cantMesesAFacturar = atoi(argv[ARG_CANT_MESES_A_FACTURAR]);

	for(int i = 0; i < cantMesesAFacturar; i++)
		mesesAFacturar[i] = strToMes(argv[ARG_CANT_MESES_A_FACTURAR + 1 + i]);

	return cantMesesAFacturar;
}


int generarFacturas_ALU(const char* nombreArchivoClientes, const char* nombreArchivoMediciones,
    const char* nombreArchivoFacturas, int proximoNroFactura, const Mes* mesesAFacturar, int cantMesesAFacturar)
{
	/// Desarrolle esta función y todas las que invoque. Puede usar funciones de la biblioteca estándar.
	/// Coloque el sufijo _ALU a todas las funciones que desarrolle.
	/// No use otro archivo que no sea main.c. Será el que deberá entregar.

    /// proximaFactura 1201
    /// mesAFacturar 10
    /// cantMeses 2

    Lista lista_mediciones;
    crear_lista_alu(&lista_mediciones);

    /// Leer el archivo movimientos.txt e ir ingresando ordenado a la lista
    armar_lista_mediciones_ALU(nombreArchivoMediciones, &lista_mediciones);

    /// Armar el archivo de facturas
    armar_archivo_facturas_ALU(nombreArchivoFacturas, nombreArchivoClientes, &lista_mediciones, proximoNroFactura);


	return TODO_OK;
}

/// CMPs
int cmp_nro_cliente_ALU(const void* cliente1, const void* cliente2)
{
    /// Nosotros sabemos que este CMP se usa para NRO Cliente
    Medicion* m1 = (Medicion*) cliente1;
    Medicion* m2 = (Medicion*) cliente2;

    /// 0   => SON IGUALES
    /// > 0 => m1 > m2
    /// < 0 => m1 < m2
    return m1->nroCliente - m2->nroCliente;
}

/// LISTA

void crear_lista_alu(Lista* pLista)
{
    *pLista = NULL;
}

int lista_vacia_ALU(Lista* pLista)
{
    return *pLista == NULL;
}

int ver_tope_lista_ALU(Lista* pLista, void* info, unsigned tamInfo)
{
    if (!*pLista)
    {
        printf("LISTA VACIA.\n");
        return 0;
    }

    memcpy(info, (*pLista)->elem, MIN(tamInfo, (*pLista)->tamElem));

    return TODO_OK;
}

int eliminar_tope_lista_ALU(Lista* pLista)
{
    if(!*pLista)
    {
        printf("Lista vacia.\n");
        return 0;
    }

    Nodo* aux = *pLista;

    free(aux->elem);
    free(aux);

    *pLista = aux->sig;

    return TODO_OK;
}

void imprimir_lista_ALU(Lista* pLista)
{
    printf("--------IMPRIMIR LISTA--------\n");
    Medicion medicion;

    while(*pLista)
    {
        memcpy(&medicion, (*pLista)->elem, (*pLista)->tamElem);
        imprimir_medicion(&medicion);
        pLista = &(*pLista)->sig;
    }
}

int sacar_primero_lista_ALU(Lista* pLista, void* info, unsigned tamInfo)
{
    Nodo* aux = *pLista;

    if (!aux)
    {
        printf("Lista vacia.\n");
        return 0;
    }

    *pLista = aux->sig;

    memcpy(info, aux->elem, MIN(tamInfo, aux->tamElem));

    /// Liberamos espacio
    free(aux->elem);
    free(aux);

    return TODO_OK;
}

int insertar_primero_lista_ALU(Lista* pLista, const void* info, unsigned tamInfo)
{
    /// Asignamos espacio para el nuevo nodo
    Nodo* nueNodo = (Nodo*)malloc(sizeof(Nodo));
    if (!nueNodo)
    {
        printf("MEMORIA LLENA.\n");
        return SIN_MEM;
    }
    nueNodo->elem = malloc(tamInfo);
    if (!nueNodo->elem)
    {
        printf("MEMORIA LLENA.\n");
        free(nueNodo);
        return SIN_MEM;
    }

    memcpy(nueNodo->elem, info, tamInfo);
    nueNodo->tamElem = tamInfo;
    nueNodo->sig = *pLista;

    *pLista = nueNodo;

    return TODO_OK;
}

int insertar_lista_ord_ALU(Lista* pLista, const void* info, unsigned tamInfo, Cmp cmp)
{
    /// Asignamos espacio para el nuevo nodo
    Nodo* nueNodo = (Nodo*)malloc(sizeof(Nodo));
    if (!nueNodo)
    {
        printf("MEMORIA LLENA.\n");
        return SIN_MEM;
    }
    nueNodo->elem = malloc(tamInfo);
    if (!nueNodo->elem)
    {
        printf("MEMORIA LLENA.\n");
        free(nueNodo);
        return SIN_MEM;
    }

    /// Recorremos la lista hasta el punto donde yo necesite ingresar mi dato
    while(*pLista && cmp(info, (*pLista)->elem) > 0)
    {
        pLista = &(*pLista)->sig;
    }

    /// Armamos el nodo
    memcpy(nueNodo->elem, info, tamInfo);
    nueNodo->tamElem = tamInfo;
    nueNodo->sig = *pLista;

    /// Hacemos que la lista apunte hacia nuestro nodo
    *pLista = nueNodo;

    return TODO_OK;

}

int armar_lista_mediciones_ALU(const char* nombreArchivoMediciones, Lista* pLista)
{
    FILE* fpMediciones = fopen(nombreArchivoMediciones, "rt");
    if(!fpMediciones)
    {
        printf("Error al abrir archivo de texto en modo lectura.\n");
        return ERR_ARCHIVO;
    }

    char cadena[50];
    Medicion medicion;

    while(fgets(cadena, sizeof(cadena), fpMediciones))
    {
        sscanf(cadena, "%d|%d/%d/%d|%d\n", &medicion.nroCliente, &medicion.fechaMedicion.dia, &medicion.fechaMedicion.mes, &medicion.fechaMedicion.anio, &medicion.valorMedidor);

        insertar_lista_ord_ALU(pLista, &medicion, sizeof(Medicion), cmp_nro_cliente_ALU);
    }

    fclose(fpMediciones);

    return TODO_OK;
}

int armar_lista_clientes_ALU(Lista* pLista, const Cliente* cliente, Medicion* medicion, Lista* pListaMediciones)
{
    crear_lista_alu(pLista);
    ver_tope_lista_ALU(pListaMediciones, medicion, sizeof(Medicion));

    while(medicion->nroCliente == cliente->nroCliente && !lista_vacia_ALU(pListaMediciones))
    {
        //imprimir_medicion(medicion);
        eliminar_tope_lista_ALU(pListaMediciones);
        insertar_primero_lista_ALU(pLista, medicion, sizeof(Medicion));
        ver_tope_lista_ALU(pListaMediciones, medicion, sizeof(Medicion));
    }

    return TODO_OK;
}

/// Cliente
void imprimir_cliente(Cliente* cliente)
{
    puts("----------- CLIENTE -----------");
    printf("Nombre: %s\n", cliente->nombre);
    printf("NRO. Cliente: %d\n", cliente->nroCliente);
    printf("Fecha ultima medicion: %d/%d/%d\n", cliente->fechaUltMedicion.dia, cliente->fechaUltMedicion.mes, cliente->fechaUltMedicion.anio);
    printf("Valor medidor: %d\n", cliente->valorMedidor);
    printf("Ultimo mes facturado: %d/%d\n", cliente->ultMesFacturado.mes, cliente->ultMesFacturado.anio);
    printf("Ultimo consumo del mes: %.2f\n", cliente->ultConsumoMes);
}

int actualizar_cliente_ALU(FILE* fpClientes, Cliente* cliente, Factura* factura)
{
    cliente->fechaUltMedicion = factura->fechaUltMedicion;

    cliente->ultConsumoMes = factura->consumoMes;

    cliente->ultMesFacturado = factura->mesFacturado;

    cliente->valorMedidor = factura->valorMedidor;

    fseek(fpClientes, -(long)sizeof(Cliente), SEEK_CUR);
    fwrite(cliente, sizeof(Cliente), 1, fpClientes);
    fseek(fpClientes, 0L, SEEK_CUR);

    return TODO_OK;
}

/// FACTURAS

void imprimir_factura(Factura* factura)
{
    puts("----------- FACTURA -----------");
    printf("NRO. Factura: %d\n", factura->nroFactura);
    printf("NRO. Cliente: %d\n", factura->nroCliente);
    printf("Fecha ultima medicion: %d/%d/%d\n", factura->fechaUltMedicion.dia, factura->fechaUltMedicion.mes, factura->fechaUltMedicion.anio);
    printf("Valor medidor: %d\n", factura->valorMedidor);
    printf("Mes facturado: %d/%d\n", factura->mesFacturado.mes, factura->mesFacturado.anio);
    printf("Consumo mes: %.2f\n", factura->consumoMes);
}

double calcular_consumo_ALU(Cliente* cliente, Medicion* medicion)
{
    int DM = (medicion->valorMedidor - cliente->valorMedidor);
    //printf("DM(%d) = medicion->valorMedidor(%d) - cliente->valorMedidor(%d)\n", DM, medicion->valorMedidor, cliente->valorMedidor);

    int DD = diferencia_dias_ALU(medicion->fechaMedicion, cliente->fechaUltMedicion);
   // printf("DD(%d)\n", DD);

    int CDE = (DM / DD);
   // printf("CDE(%d) = DM(%d) / DD(%d)\n", CDE, DM, DD);

    //printf("return => %d (%d * %d)\n", CDE *  cantDiasMes_ALU(medicion->fechaMedicion.mes, medicion->fechaMedicion.anio), CDE ,cantDiasMes_ALU(medicion->fechaMedicion.mes, medicion->fechaMedicion.anio));

    return (CDE * cantDiasMes_ALU(medicion->fechaMedicion.mes, medicion->fechaMedicion.anio));

}

int armar_factura_ALU(Factura* factura, Medicion* medicion, Cliente* cliente, int nroFactura)
{
    factura->nroFactura = nroFactura;
    factura->nroCliente = medicion->nroCliente;

    factura->mesFacturado.anio = medicion->fechaMedicion.anio;
    factura->mesFacturado.mes = medicion->fechaMedicion.mes;

    factura->fechaUltMedicion.anio = medicion->fechaMedicion.anio;
    factura->fechaUltMedicion.mes = medicion->fechaMedicion.mes;
    factura->fechaUltMedicion.dia = medicion->fechaMedicion.dia;

    factura->valorMedidor = medicion->valorMedidor;

    factura->consumoMes = calcular_consumo_ALU(cliente, medicion);

    return TODO_OK;
}

int armar_archivo_facturas_ALU(const char* nombreArchivoFacturas, const char* nombreArchivoClientes, Lista* pLista, int nroFactura)
{

    FILE* fpFacturas = fopen(nombreArchivoFacturas, "wb");
    if (!fpFacturas)
    {
        printf("Error al abrir archivo binario en formato escritura.\n");
        return ERR_ARCHIVO;
    }

    FILE* fpClientes = fopen(nombreArchivoClientes, "r+b");
    if (!fpClientes)
    {
        printf("Error al abrir archivo binario en formato lectura/escritura.\n");
        return ERR_ARCHIVO;
    }

    Factura factura;
    Medicion medicion;
    Cliente cliente;
    Lista listaCliente;

    /// Leemos el archivo cliente, y luego armamos una lista de las mediciones de ese cliente
    fread(&cliente, sizeof(Cliente), 1, fpClientes);

    while(!feof(fpClientes))
    {
        /// Armamos la lista de mediciones del cliente
        armar_lista_clientes_ALU(&listaCliente, &cliente, &medicion, pLista);

        while(!lista_vacia_ALU(&listaCliente))
        {
            /// Leemos la medicion correspondiente
            sacar_primero_lista_ALU(&listaCliente, &medicion, sizeof(Medicion));

            /// Armamos la factura
            armar_factura_ALU(&factura, &medicion, &cliente, nroFactura);

            /// Actualizamos estructura cliente
            actualizar_cliente_ALU(fpClientes, &cliente, &factura);

            /// Escribimos el archivo Facturas
            fwrite(&factura, sizeof(Factura), 1, fpFacturas);

            /// Actualizamos el numero de factura
            nroFactura++;
        }

        /// Leemos el siguiente cliente
        fread(&cliente, sizeof(Cliente), 1, fpClientes);
    }

    fclose(fpFacturas);
    fclose(fpClientes);

    return TODO_OK;
}

/// Medicion
void imprimir_medicion(Medicion* medicion)
{
    puts("----------- MEDICION -----------");
    printf("NRO. Cliente: %d\n", medicion->nroCliente);
    printf("Fecha medicion: %d/%d/%d\n", medicion->fechaMedicion.dia, medicion->fechaMedicion.mes, medicion->fechaMedicion.anio);
    printf("Valor medidor: %d\n", medicion->valorMedidor);
}

/// Fecha
void imprimir_fecha(Fecha f1)
{
    printf("%d/%d/%d\n", f1.dia, f1.mes, f1.anio);
}

int fecha_mayor_ALU(Fecha f1, Fecha f2)
{
    if (f1.anio > f2.anio) return 1;
    if (f1.anio < f2.anio) return -1;

    if (f1.mes > f2.mes) return 1;
    if (f1.mes < f2.mes) return -1;

    if (f1.dia > f2.dia) return 1;
    if (f1.dia < f2.dia) return -1;

    return 0;
}

int esBisiesto_ALU(int anio)
{
    if (((anio % 4) == 0) && ((anio % 100) == 0)) return 1;
    if ((anio % 400) == 0) return 1;

    return 0;
}

int cantDiasMes_ALU(int mes, int anio)
{
    int normal[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int bisiesto[13] = {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (esBisiesto_ALU(anio))
    {
        return bisiesto[mes];
    }

    return normal[mes];
}

int comparar_fechas_ALU(Fecha f1, Fecha f2)
{
    if (f1.dia != f2.dia) return 0;
    if (f1.mes != f2.mes) return 0;
    if (f1.anio != f2.anio) return 0;

    return 1;
}

int diferencia_dias_ALU(Fecha f1, Fecha f2)
{
    int diferenciaDias = 0;

    if(fecha_mayor_ALU(f1, f2))
    {
        /// Fecha 1 es mayor que fecha 2
        while(!comparar_fechas_ALU(f1, f2))
        {
            diferenciaDias++;
            f2.dia++;
            if (f2.dia > cantDiasMes_ALU(f2.mes, f2.anio))
            {
                f2.dia = 1;
                f2.mes++;
                if(f2.mes > 12)
                {
                    f2.mes = 1;
                    f2.anio++;
                }
            }
        }

    }
    else
    {
        /// Fecha 1 es menor que fecha 2 (o igual)
         while(!comparar_fechas_ALU(f1, f2))
        {
            diferenciaDias++;
            f1.dia++;
            if (f1.dia > cantDiasMes_ALU(f1.mes, f1.anio))
            {
                f1.dia = 1;
                f1.mes++;
                if(f1.mes > 12)
                {
                    f1.mes = 1;
                    f1.anio++;
                }
            }
        }

    }

    return diferenciaDias;

}
