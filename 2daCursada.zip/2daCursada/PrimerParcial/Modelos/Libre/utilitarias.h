#ifndef UTILITARIAS_H_INCLUDED
#define UTILITARIAS_H_INCLUDED

#include "archivos.h"

void texto_a_parcial_res(const char* cadena, t_parcial* pParcial);

#endif // UTILITARIAS_H_INCLUDED
