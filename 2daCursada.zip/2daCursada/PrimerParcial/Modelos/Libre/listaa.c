#include "lista.h"

void acumular(void* info1, const void* info2)
{
    int* saldo1 = (int*)info1;
    int* saldo2 = (int*)info2;

    *saldo1 += *saldo2;
}

void crear_lista_res(t_lista* pLista)
{
    *pLista = NULL;
}

int lista_vacia(t_lista* pLista)
{
    return *pLista == NULL;
}

void vaciar_lista_res(t_lista* pLista)
{
    t_nodo* nodoAux;
    while(*pLista)
    {
        nodoAux = *pLista;
        pLista = &(*pLista)->pSig;

        free(nodoAux->info);
        free(nodoAux);
    }
}

int insertar_lista_ordenada_res(t_lista* pLista, const void* info, unsigned tamInfo,
                            int(*cmp)(const void*, const void*), /// cmp
                            void(*acum)(void*, const void*)) /// acum
{
    t_nodo* nueNodo;


    /// Recorremos hasta el nodo donde debemos ingresar el dato
    while(*pLista && cmp(info, (*pLista)->info) > 0)
        // mientras la info nueva sea mayor que lo que ya esta en la lista, recorremos
    {
        pLista = &(*pLista)->pSig;
    }

    /// Nos fijamos si el nodo existe
    if (*pLista && cmp(info, (*pLista)->info) == 0 && acum)
    {
        acum((*pLista)->info, info);
        return TODO_OK;
    }

    /// Verificamos que exista memoria para almacenar este nuevo nodo
    nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if (!nueNodo) return SIN_MEMO;

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        free(nueNodo);
        return SIN_MEMO;
    }
    /// Armamos el nuevo nodo

    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->pSig = *pLista;

    *pLista = nueNodo;

    return TODO_OK;
}

int insertar_lista_top3(t_lista* pLista, void* info, unsigned tamInfo,
                        float(*cmp)(const void*, const void*))
{
    int cantElem=0;
    t_nodo* nueNodo;
    /// Primero nos posicionamos en el lugar que debemos insertar
    /// Verificando no pasarnos de 3 elementos
    while(*pLista && cmp(info, (*pLista)->info) < 0 && cantElem < 3)
        // mientras sea menor que avance, pq nosotros queremos al mayor primero
    {
        pLista = &(*pLista)->pSig;
        cantElem++;
    }

    /// Si ya hay 3 elementos en la lista, listo no tenemos que hacer nada
    if (cantElem == 3)
    {
        //puts("Lista TOP 3, LLENA");
        return -3;
    }

    /// Si pasamos esto es que hay que ingresar el nodo
    nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if(!nueNodo) return SIN_MEMO;

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        free(nueNodo);
        return SIN_MEMO;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->pSig = *pLista;

    *pLista = nueNodo;
    cantElem++;

    /// Ahora debemos recorrer la lista y verificar que no existan mas de 3 elementos
    while((*pLista)->pSig)
    {
        pLista = &(*pLista)->pSig;
        cantElem++;
    }

    if (cantElem > 3)
    {
        free((*pLista)->info);
        free(*pLista);
        *pLista = NULL;

    }

    return TODO_OK;
}

int sacar_primero_lista_res(t_lista* pLista, void* dato, unsigned tamDato)
{

    t_nodo* aux = *pLista;

    if(!aux)
    {
        puts("Lista vacia");
        return 0;
    }

    *pLista = aux->pSig;

    memcpy(dato, aux->info, MIN(tamDato, aux->tamInfo));

    free(aux->info);
    free(aux);

    return TODO_OK;
}

int imprimir_parcial(const void* info)
{
    if(info == NULL)
    {
        printf("NOTA|NOMBRE Y APELLIDO|DNI\n");
        return TODO_OK;
    }

    t_parcial* parcial = (t_parcial*)info;

    printf("%d|%s|%d\n", parcial->nota, parcial->nombre_apellido, parcial->dni);

    return TODO_OK;
}

int mostrar_lista_res(t_lista* pLista)
{
    imprimir_parcial(NULL);
    while(*pLista)
    {
        imprimir_parcial((*pLista)->info);
        pLista = &(*pLista)->pSig;
    }

    return TODO_OK;
}


int mostrar_lista_top3(t_lista* pLista)
{
    if (pLista == NULL)
    {
        puts("--------- TOP 3: MEJORES ALUMNOS -----------");
        return 0;
    }

    while(*pLista)
    {
        imprimir_alumno((*pLista)->info);
        pLista = &(*pLista)->pSig;
    }

    return TODO_OK;
}
