#include "utilitarias.h"

void texto_a_parcial_res(const char* cadena, t_parcial* pParcial)
{
    sscanf(cadena, "%d|%[^|\n]|%d\n", &pParcial->nota, pParcial->nombre_apellido, &pParcial->dni);
}
