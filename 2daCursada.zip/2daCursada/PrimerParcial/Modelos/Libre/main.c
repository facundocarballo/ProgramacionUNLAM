#include <stdio.h>
#include <stdlib.h>
#include "archivos.h"

int main()
{
    puts("SE CREAN LOS ARCHIVOS BINARIOS Y DE TEXTO...");
    crear_archivo_binario_alumnos();
    crear_archivo_texto_parciales();

    puts("------------ ANTES DE LA ACTUALIZACION --------------\n");
    puts("------------ alumnos.dat ------------------------------\n");
    imprimir_archivo_alumnos("alumnos.dat");
    puts("------------ parciales.txt ------------------------------\n");
    imprimir_archivo_parciales("parciales.txt");

    puts("\n--------- ACTUALIZANDO.... ------------\n");

    actualizar_archivo_binario_res("alumnos.dat", "parciales.txt");

    puts("\n------------ DESPUES DE LA ACTUALIZACION --------------\n");
    puts("------------ alumnos.dat ------------------------------\n");
    imprimir_archivo_alumnos("alumnos.dat");
    puts("------------ parciales.txt ------------------------------\n");
    imprimir_archivo_parciales("parciales.txt");


    return 0;
}
