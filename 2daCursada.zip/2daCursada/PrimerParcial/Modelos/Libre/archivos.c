#include "archivos.h"
#include "lista.h"
#include "utilitarias.h"

int imprimir_alumno(const void* info)
{
    if (info == NULL)
    {
        printf("DNI|NOMBRE Y APELLIDO|MATERIAS APROBADAS|PROMEDIO\n");
        return TODO_OK;
    }

    t_alumno* alumno = (t_alumno*)info;
    printf("%d|%s|%d|%5f\n", alumno->dni, alumno->nombre_apellido, alumno->cant_materias_aprobadas, alumno->promedio);

    return TODO_OK;
}

int imprimir_archivo_parciales(const char* nombreArchivo)
{
    imprimir_parcial(NULL);

    FILE* fp = fopen(nombreArchivo, "rt");
    if(!fp) return ERR_ARCH;

    char cadena[50];
    while(fgets(cadena, sizeof(cadena), fp))
    {
        printf("%s", cadena);
    }

    fclose(fp);

    return TODO_OK;
}

int imprimir_archivo_alumnos(const char* nombreArchivo)
{
    FILE* fp = fopen(nombreArchivo, "rb");
    if(!fp) return ERR_ARCH;

    t_alumno alumno;
    fread(&alumno, sizeof(t_alumno), 1, fp);

    imprimir_alumno(NULL);
    while(!feof(fp))
    {
        imprimir_alumno(&alumno);
        fread(&alumno, sizeof(t_alumno), 1, fp);
    }

    fclose(fp);

    return TODO_OK;
}

int crear_archivo_binario_alumnos()
{
    FILE* fpAlumnos = fopen("alumnos.dat", "wb");
    if(!fpAlumnos) return ERR_ARCH;

    /// Ordenado por DNI
    t_alumno alumnos[] = {
        {
            40773931,
            "Rodrigo Bueno",
            17,
            7.63
        },
        {
            41773931,
            "Tomas Goicochea",
            15,
            7.25
        },
        {
            42773931,
            "Nicolas Veliz",
            11,
            7.96
        },
        {
            42774931,
            "Facundo Carballo",
            17,
            8.15
        },
        {
            43773931,
            "Victor Povoli Olivera",
            18,
            8.36
        }
    };

    fwrite(&alumnos, sizeof(alumnos), 1, fpAlumnos);

    fclose(fpAlumnos);

    return TODO_OK;
}


int crear_archivo_texto_parciales()
{
    FILE* fpTexto = fopen("parciales.txt", "wt");
    if(!fpTexto) return ERR_ARCH;

    /// Ordenado por Nombre y Apellido
    fprintf(fpTexto, "7|Agustin Santos|42869234\n9|Facundo Carballo|42774931\n7|Nicolas Veliz|42773931\n10|Santiago Castellani|43785369\n");

    fclose(fpTexto);

    return TODO_OK;
}

float cmp_alumnos(const void* a1, const void* a2)
{
    t_alumno* alumno1 = (t_alumno*)a1;
    t_alumno* alumno2 = (t_alumno*)a2;

    return alumno1->promedio - alumno2->promedio;
}

int cmp_parciales_res(const void* info1, const void* info2)
{
    t_parcial* parcial1 = (t_parcial*)info1;
    t_parcial* parcial2 = (t_parcial*)info2;

    return parcial1->dni - parcial2->dni;
}

void acum_parciales_res(void* info1, const void* info2)
{
    t_parcial* parcial1 = (t_parcial*)info1;
    t_parcial* parcial2 = (t_parcial*)info2;

    parcial1->nota += parcial2->nota;
    parcial1->nota /= 2;
}

void actualizar_alumno(t_alumno* alumno, FILE* fp)
{
    fseek(fp, -(long)sizeof(t_alumno), SEEK_CUR);
    fwrite(alumno, sizeof(t_alumno),1, fp);
    fseek(fp, 0L, SEEK_CUR);
}

int actualizar_archivo_binario_res(const char* nombreArchivoBinario, const char* nombreArchivoTexto)
{
    FILE* fpAlumnos = fopen(nombreArchivoBinario, "r+b");
    FILE* fpTexto = fopen(nombreArchivoTexto, "rt");
    FILE* fpError = fopen("errores.txt", "wt");

    if(!fpAlumnos || !fpTexto || !fpError) return ERR_ARCH;

    /// Leemos del archivo de texto y creamos una lista ordenada con eso
    t_alumno alumno;
    t_parcial parcial;
    char cadena[50];

    t_lista listaParciales;
    t_lista listaTop3;
    crear_lista_res(&listaTop3);
    crear_lista_res(&listaParciales);

    while(fgets(cadena, sizeof(cadena), fpTexto))
    {
        /// Convertimos de texto a t_parcial
        texto_a_parcial_res(cadena, &parcial);
        imprimir_parcial(&parcial);
        /// Insertamos en la lista, de forma ordenada
        insertar_lista_ordenada_res(&listaParciales, &parcial, sizeof(t_parcial), cmp_parciales_res, acum_parciales_res);
    }

    puts("---------- IMPRIMIENDO LISTA ORDENADA ---------\n");
    mostrar_lista_res(&listaParciales);

    /// Leemos los alumnos mientras vamos sacando de la lista las nuevas notas

    fread(&alumno, sizeof(t_alumno), 1, fpAlumnos);
    int res = sacar_primero_lista_res(&listaParciales, &parcial, sizeof(parcial));
    while(!feof(fpAlumnos) && res)
    {
        if(parcial.dni > alumno.dni)
        {
            /// Tratamos de ingresar al alumno al top3
            insertar_lista_top3(&listaTop3, &alumno, sizeof(t_alumno), cmp_alumnos);

            fread(&alumno, sizeof(t_alumno), 1, fpAlumnos);
        }
        else if(parcial.dni < alumno.dni)
        {
            res = sacar_primero_lista_res(&listaParciales, &parcial, sizeof(parcial));
        }
        else if(parcial.dni == alumno.dni)
        {
            alumno.cant_materias_aprobadas++;
            alumno.promedio = (alumno.promedio + parcial.nota) / 2;

            actualizar_alumno(&alumno, fpAlumnos);

            /// Tratamos de ingresar al alumno al top3
            insertar_lista_top3(&listaTop3, &alumno, sizeof(t_alumno), cmp_alumnos);

            /// Como sabemos que no hay duplicados leemos de ambos lados
            fread(&alumno, sizeof(t_alumno), 1, fpAlumnos);
            res = sacar_primero_lista_res(&listaParciales, &parcial, sizeof(parcial));
        }
    }

    if(!lista_vacia(&listaParciales))
    {
        vaciar_lista_res(&listaParciales);
    }

    mostrar_lista_top3(NULL);
    mostrar_lista_top3(&listaTop3);

    vaciar_lista_res(&listaTop3);

    fclose(fpAlumnos);
    fclose(fpTexto);
    fclose(fpError);

    return TODO_OK;
}
