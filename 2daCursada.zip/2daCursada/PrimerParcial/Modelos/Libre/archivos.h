#ifndef ARCHIVOS_H_INCLUDED
#define ARCHIVOS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>


#define ERR_ARCH -1
#define TODO_OK 1

/// ESTRUCTURAS

typedef struct s_alumno {
    unsigned dni;
    char nombre_apellido[50];
    unsigned cant_materias_aprobadas;
    float promedio;
} t_alumno;

typedef struct s_parcial {
    unsigned nota;
    char nombre_apellido[50];
    unsigned dni;
} t_parcial;

int crear_archivo_binario_alumnos();
int crear_archivo_texto_parciales();
int actualizar_archivo_binario_res(const char* nombreArchivoBinario, const char* nombreArchivoTexto);

int imprimir_parcial(const void* info);
int imprimir_alumno(const void* info);

int imprimir_archivo_parciales(const char* nombreArchivo);
int imprimir_archivo_alumnos(const char* nombreArchivo);
void actualizar_alumno(t_alumno* alumno, FILE* fp);


#endif // ARCHIVOS_H_INCLUDED
