
//
//
//void acumular(void* info1, const void* info2)
//{
//    int* saldo1 = (int*)info1;
//    int* saldo2 = (int*)info2;
//
//    *saldo1 += *saldo2;
//}
//
//void crear_lista_res(t_lista* pLista)
//{
//    *pLista = NULL;
//}
//
//int insertar_lista_ordenada_res(t_lista* pLista, const void* info, unsigned tamInfo,
//                            int(*cmp)(const void*, const void*), /// cmp
//                            void(*acum)(void*, const void*)) /// acum
//{
//    int res;
//    t_nodo* nueNodo;
//
//
//    /// Recorremos hasta el nodo donde debemos ingresar el dato
//    while(*pLista && res = cmp(info, &(*pLista)->info) > 0)
//        // mientras la info nueva sea mayor que lo que ya esta en la lista, recorremos
//    {
//        pLista = &(*pLista)->pSig;
//    }
//
//    /// Nos fijamos si el nodo existe
//    if (*pLista && !res && acum)
//    {
//        acum((*pLista)->info, info);
//        return TODO_OK;
//    }
//
//    /// Verificamos que exista memoria para almacenar este nuevo nodo
//    nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
//    if (!nueNodo) return SIN_MEMO;
//
//    nueNodo->info = malloc(tamInfo);
//    if(!nueNodo->info)
//    {
//        free(nueNodo);
//        return SIN_MEMO;
//    }
//    /// Armamos el nuevo nodo
//
//    memcpy(nueNodo->info, info, tamInfo);
//    nueNodo->tamInfo = tamInfo;
//    nueNodo->pSig = *pLista;
//
//    *pLista = nueNodo;
//
//    return TODO_OK;
//}
//
//int sacar_primero_lista_res(t_lista* pLista, void* dato, unsigned tamDato)
//{
//
//    t_nodo* aux = *pLista;
//
//    if(!aux)
//    {
//        puts("Lista vacia");
//        return 0;
//    }
//
//    *pLista = aux->pSig;
//
//    memcpy(dato, aux->info, MIN(tamDato, aux->tamInfo));
//
//    free(aux->info);
//    free(aux);
//
//    return TODO_OK;
//}
//
//void imprimir_parcial(const void* info)
//{
//    t_parcial* parcial = (t_parcial*)info;
//
//    printf("NOTA: %d\n", parcial->nota);
//    printf("NOMBRE Y APELLIDO: %s\n", parcial->nombre_apellido);
//    printf("DNI: %d\n", parcial->dni);
//}
//
//void mostrar_lista_res(t_lista* pLista)
//{
//    while(*pLista)
//    {
//        imprimir_parcial((*pLista)->info);
//        pLista = &(*pLista)->pSig;
//    }
//}
