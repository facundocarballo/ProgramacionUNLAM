#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include "string.h"
#include "archivos.h"

#define ERR_ARCH -1
#define TODO_OK 1
#define SIN_MEMO -2
#define MIN(x,y)(x<y?x:y)

typedef struct s_nodo {
    void* info;
    unsigned tamInfo;
    struct s_nodo* pSig;
} t_nodo;

typedef t_nodo* t_lista;


void crear_lista_res(t_lista* pLista);
int lista_vacia(t_lista* pLista);
void vaciar_lista_res(t_lista* pLista);
int insertar_lista_ordenada_res(t_lista* pLista, const void* info, unsigned tamInfo,
                            int(*cmp)(const void*, const void*), /// cmp
                            void(*acum)(void*, const void*)); /// acum

int sacar_primero_lista_res(t_lista* pLista, void* dato, unsigned tamDato);
int insertar_lista_top3(t_lista* pLista, void* info, unsigned tamInfo,
                        float(*cmp)(const void*, const void*));


int mostrar_lista_res(t_lista* pLista);
int mostrar_lista_top3(t_lista* pLista);

#endif // LISTA_H_INCLUDED
