#include <stdio.h>
#include <stdlib.h>

#define TAM 3

int sumar_elem_der_diagonal_principal_y_der_diagonal_secundaria(int matriz[][TAM]);

int main()
{
    int matriz[][TAM] = {
        {1,2,3},
        {1,2,3},
        {1,2,3},
    };
    int res = sumar_elem_der_diagonal_principal_y_der_diagonal_secundaria(matriz);
    printf("RES: %d\n", res);
    return 0;
}


int sumar_elem_der_diagonal_principal_y_der_diagonal_secundaria(int matriz[][TAM])
{
    int res = 0, fila, columna;

    /// Recorremos primero lo que esta a la derecha de la diagonal principal y sumamos
    for(fila = 0; fila < TAM; fila++)
    {
        for(columna = fila+1; columna < TAM; columna++)
        {
            res += matriz[fila][columna];
        }
    }

    /// Recorremos lo que esta a la derecha de la diagona secundaria y sumamos
    for(fila = 1; fila < TAM; fila++)
    {
        for(columna = TAM-1; columna > TAM-fila-1; columna--)
        {
            res += matriz[fila][columna];
        }
    }

    return res;
}
