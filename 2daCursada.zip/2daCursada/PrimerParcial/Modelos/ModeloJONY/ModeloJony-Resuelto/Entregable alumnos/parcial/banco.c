#include<banco.h>
#include<lista.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>
#include<string.h>

/// AUXS
void imprimir_movimiento(t_movimiento_banco* movimiento)
{
    printf("--- MOVIMIENTO ---\n");
    printf("CDO. CTA: %s\n", movimiento->cod_cta);
    printf("TIPO MOVIMIENTO: %c\n", movimiento->tipo_mov);
    printf("IMPORTE: %7.2f\n", movimiento->importe);
}

void imprimir_cuenta(t_cuenta_banco* cuenta)
{
     printf("--- CUENTA ---\n");
     printf("CDO. CUENTA: %s\n", cuenta->cod_cta);
     printf("NOMBRE Y APELLIDO: %s\n", cuenta->apyn);
     printf("DNI: %ld\n", cuenta->dni);
     printf("SALDO: %9f\n", cuenta->saldo);
}


int cmp_movimientos(const t_info* info1, const t_info* info2)
{
    return strcmp(info1->cod_cta, info2->cod_cta);
}

void acum_importe (t_info *mov1, const t_info *mov2)
{
    /// Si los tipos de movimientos son iguales, simplemente sumamos el importe
    if(mov1->tipo_mov==mov2->tipo_mov)
    {
        mov1->importe+=mov2->importe;
        return;
    }

    /// Si los tipos de movimientos son distintos, los restamos
    mov1->importe -= mov2->importe;
    if (mov1->importe < mov2->importe) // (mov1->importe<mov2->importe)
    {
        /// De ser negativo, le cambiamos el tipo de movimiento por el que nos llego ahora
        mov1->tipo_mov=mov2->tipo_mov;
        /// Hacemos que el importe quede en positivo
        ///mov1->importe *= (-1);
    }


    if (mov1->importe<0) mov1->importe *= (-1);

    return;

}

void crear_lista_alu(t_lista* plista)
{
    *plista = NULL;
}

int lista_vacia(t_lista* pl)
{
    return *pl == NULL;
}


void actualizar_cuentas(FILE * arch_ctas, const char * path_movs)
{
    FILE* fpMovs = fopen(path_movs, "rt");
    if(!fpMovs)
    {
        printf("Error al abrir archivo de texto (modo escritura).\n");
        return;
    }

    /// Leemos el archivo de texto y armamos una lista ordenada por CDO. Cuenta
    char cadena[50];
    t_movimiento_banco movimiento;
    t_lista listaMovimientos;
    t_cuenta_banco cuenta;
    crear_lista_alu(&listaMovimientos);
    while(fgets(cadena, sizeof(cadena), fpMovs))
    {
        /// Armamos la estructura binaria e ingresamos a la lista (CON ACUMULACION)
        texto_a_movimiento(cadena, &movimiento);
        instertar_lista(&listaMovimientos, &movimiento, cmp_movimientos, NULL);
    }

    /// Leemos las cuentas y las modificamos usando los valores de la lista
    fread(&cuenta, sizeof(t_cuenta_banco), 1, arch_ctas);
    sacar_primero_lista_res(&listaMovimientos, &movimiento);

    while(!feof(arch_ctas) && !lista_vacia(&listaMovimientos))
    {
        // este while iria si la lista no acumularia los movimientos
        while( strcmp(cuenta.cod_cta, movimiento.cod_cta) == 0 && !lista_vacia(&listaMovimientos) )
        {


            if (movimiento.tipo_mov == 'D')
            {
                cuenta.saldo -= movimiento.importe;
            }

            if (movimiento.tipo_mov == 'C')
            {
                cuenta.saldo += movimiento.importe;
            }

            sacar_primero_lista(&listaMovimientos, &movimiento);
        }

        /// Actualizamos la cuenta
        fseek(arch_ctas, -(long)sizeof(t_cuenta_banco), SEEK_CUR);
        fwrite(&cuenta, sizeof(t_cuenta_banco), 1, arch_ctas);
        fseek(arch_ctas, 0L, SEEK_CUR);

        /// Leemos una nueva cuenta
        fread(&cuenta, sizeof(t_cuenta_banco), 1, arch_ctas);
    }


    /// Cerramos los archivos que abrimos
    fclose(fpMovs);

    return;
}
