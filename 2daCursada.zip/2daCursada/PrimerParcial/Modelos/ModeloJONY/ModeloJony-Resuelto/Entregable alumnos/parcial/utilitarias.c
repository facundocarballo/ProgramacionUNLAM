#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <utilitarias.h>
#include <banco.h>

void texto_a_movimiento(const char * cadena, t_movimiento_banco * pmov)
{
   char *codCuenta = pmov->cod_cta;
    strncpy(codCuenta, cadena, 6);
    codCuenta+=6;
    cadena+=6;
    *codCuenta = '/';
    codCuenta++;
    *codCuenta = *cadena;
    codCuenta++;
    *codCuenta = '\0';
    cadena++;

    pmov->tipo_mov = *cadena;
    cadena++;

    sscanf(cadena, "%9f", &pmov->importe);
}
