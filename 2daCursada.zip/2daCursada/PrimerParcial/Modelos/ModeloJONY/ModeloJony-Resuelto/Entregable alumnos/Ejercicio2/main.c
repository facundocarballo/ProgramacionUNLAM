#include <stdio.h>
#include <stdlib.h>

void reemplazar_sub_cadena(char* cadena, char* sub_cadena, char* nueva_sub_cadena);

int main()
{
    char cadena[] = {"Hello World!\n"};

    reemplazar_sub_cadena(cadena, "World", "Mundo");

    printf("%s\n", cadena);
    return 0;
}

int strlen_alu(char* cad)
{
    int len = 0;
    while(*cad)
    {
        cad++;
        len++;
    }
    return len;
}

void reemplazar_sub_cadena(char* cadena, char* sub_cadena, char* nueva_sub_cadena)
{
    int recorridos = strlen_alu(sub_cadena) - 1;
    int i = 0;
    while(*cadena)
    {
        while(*cadena != sub_cadena && *cadena)
        {
            cadena++;
        }

        while(*cadena == (sub_cadena + i) && i < recorridos)
        {
            cadena++;
            i++;
        }

        if (i == recorridos)
        {
            cadena--;

            while(i > 0)
            {
                *cadena = *(nueva_sub_cadena+i);
                cadena--;
                nueva_sub_cadena++;
                i--;
            }

        }

    }
}
