#include<lista.h>
#include<stdlib.h>
#include<stdio.h>


int instertar_lista(t_lista * plista, const t_info * pinfo,
                    int (*comp)(const t_info *, const t_info*),
                    void(*acum)(t_info *, const t_info*))
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if(!nueNodo)
    {
        printf("SIN MEMORIA.\n");
        return -1;
    }

    /// Recorremos la lista hasta la posicion donde debemos ingresar el nodo
    while(*plista && comp(pinfo, &(*plista)->info) > 0)
    {
        plista = &(*plista)->psig;
    }

    if (*plista && (comp(pinfo, &(*plista)->info) == 0) && acum)
    {
        /// Si el nodo existe, lo acumulamos
        acum(&(*plista)->info, pinfo);
    }
    else
    {
        /// Armamos el nodo
        nueNodo->info = *pinfo;
        nueNodo->psig = *plista;

        /// Enganchamos la lista
        *plista = nueNodo;
    }



    return 0;
}

int sacar_primero_lista(t_lista * plista, t_info * pinfo)
{
    t_nodo* aux = *plista;

    if(!aux)
    {
        printf("Lista vacia.\n");
        return LISTA_VACIA;
    }

    *pinfo = aux->info;

    *plista = aux->psig;

    free(aux);

    return 0;
}


