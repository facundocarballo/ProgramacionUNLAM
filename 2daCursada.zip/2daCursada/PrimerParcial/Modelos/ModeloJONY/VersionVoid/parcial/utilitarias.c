#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <utilitarias.h>
#include <banco.h>

void texto_a_movimiento(const char * cadena, t_movimiento_banco * pmov)
{
    sscanf(cadena, "%7s%c%9f\n", pmov->cod_cta, &pmov->tipo_mov, &pmov->importe);

    char ultimoNumero = *(pmov->cod_cta+6);
    *(pmov->cod_cta+6) = '/';
    *(pmov->cod_cta+7) = ultimoNumero;
    *(pmov->cod_cta+8) = '\0';

}
