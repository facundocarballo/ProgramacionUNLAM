#include "cadena.h"

using namespace std;

int strlen_alu(const char* cad)
{
    int len = 0;

    while(*(cad + len))
    {
        len++;
    }

    return len;
}

int strcpy_alu(char* cadDest, const char* cadOrig)
{
    int i = 0;
    while(*(cadOrig+i))
    {
        *(cadDest+i) = *(cadOrig+i);
        i++;
    }
    *(cadDest+i) = '\0';
    return i;
}

Cadena::Cadena(const char* cad)
{
    pCadena = new char[strlen_alu(cad)];
    strcpy_alu(pCadena, cad);
}

Cadena::Cadena()
{
    pCadena = new char[0];
    *pCadena ='\0';
}

Cadena::Cadena(const Cadena& cad)
{
    pCadena = new char[strlen_alu(cad.pCadena)];
    strcpy_alu(pCadena, cad.pCadena);
}

Cadena::longitud()
{
    return strlen_alu(pCadena);
}

Cadena::~Cadena()
{
    cout << "Destruyendo Cadena: " << *this << endl;
    delete []pCadena;
}

Cadena& Cadena::operator=(char* cad)
{
    //cout << "Operacion = " << endl;
    delete []pCadena;

    //cout << "Tama�o de la nueva cadena: " << strlen_alu(cad) << endl;

    pCadena = new char[strlen_alu(cad)];
    strcpy_alu(pCadena, cad);

    //cout << "Tama�o de la nueva cadena: " << strlen_alu(pCadena) << endl;

    return *this;
}

ostream& operator <<(ostream& izq, const Cadena& der)
{
    char* pCad = der.pCadena;
    while(*pCad)
    {
        izq << *pCad;
        pCad++;
    }

    return izq;
}



