#include <iostream>
#include "cadena.h"

int main()
{
    Cadena c1("una cadena");
    Cadena c2(c1);
    Cadena c3;
    Cadena c4;

    c2 = "otro ejemplo de cadena";
    c4 = "otra cadena de varios caracteres";


    cout << "C1: " <<  c1 << "\n Longitud de c1 = " << c1.longitud() << endl;
    cout << "C2: " << c2 << " \nLongitud de c2 = " << c2.longitud() << endl;
    cout << "C3: " << c3 << " \nLongitud de c3 = " << c3.longitud() << endl;
    cout << "C4: " << c4 << " \nLongitud de c4 = " << c4.longitud() << endl;

    return 0;
}
