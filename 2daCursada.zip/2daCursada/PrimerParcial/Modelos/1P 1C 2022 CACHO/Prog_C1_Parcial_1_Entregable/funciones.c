/**//*             en los siguientes macroreemplazos indique:             *//**/
/**//*    su(s)         APELLIDO(S)     completo(s)                       *//**/
/**//*    su(s)         Nombre(S)       completo(s)                       *//**/
/**//*    su legajo     N�MERO DE DNI   con los puntos de mill�n y de mil *//**/
/**//*    COMISI�N                                                        *//**/
/**//*              reemplazando los que est�n como ejemplo               *//**/
#define APELLIDO    "P�REZ DEL R�O"
#define NOMBRE      "Juan Manuel"
#define DOCUMENTO   "22.333.444"
#define COMISION    "07(7299)"
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/** aqu� insertaremos nuestras observaciones y / o correcciones              **/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#undef APELLIDO
#undef NOMBRE
#undef DOCUMENTO
#undef COMISION
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO DESDE AC� *//**/



/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO HASTA AC� *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#include "funciones.h"
#include <stdlib.h>
#include <string.h>

/// MACROS

#define ES_MAYUSCULA(x)((x<='Z') && (x >= 'A'))
#define ES_MINUSCULA(x)((x>='a') && (x<= 'z'))
#define ES_LETRA(x)(ES_MAYUSCULA(x) || ES_MINUSCULA(x) )
#define ES_ESPACIO(x)(x == ' ' ? 1 : 0)
#define A_MAYUSCULA(x)( ES_MINUSCULA(x) ? (x - ('a' - 'A') ) : x)
#define A_MINUSCULA(x)( ES_MAYUSCULA(x) ? (x + ('a' - 'A') ) : x)
#define MIN(a,b)(a < b ? a : b)

int sacar_primero_lista(tLista* pl, void* info, unsigned tamInfo);

/** para el PUNTO 1 **/
char *normalizarCadena_MIO(char *str)
{

    char* normalizado = str;
    char* lectura = str;

    /// NORMALIZACION
    /// - Primer caracter debe ser una letra
    /// - Permitir un espacio entre palabras
    /// - Permitir puntos en la cadena
    /// - Las palabras siempre empizan con MAYUSCULA

    while(*lectura)
    {

        /// Nos sacamos los primeros espacios de encima
        while(*lectura && !ES_LETRA(*lectura))
            lectura++;

        /// El primer caracter de una palabra debe de estar en MAYUSCULA
        if (*lectura)
        {
            *normalizado = A_MAYUSCULA(*lectura);
            normalizado++;
            lectura++;


            /// Seguimos escribiendo la palabra en minuscula
            while(ES_LETRA(*lectura))
            {
                *normalizado = A_MINUSCULA(*lectura);
                normalizado++;
                lectura++;
            }

            /// Se tienen en consideracion los puntos
            if(*lectura == '.')
            {
                *normalizado = *lectura;
                normalizado++;
                lectura++;
            }


            *normalizado = ' ';
            normalizado++;

        }

    }

    normalizado--;
    *normalizado = '\0';

    return str;
}
/** FIN de PUNTO 1 **/


/** para el PUNTO 2 **/
int fusionarMaestros_MIO(char *nombreArchivo1,
                         char *nombreArchivo2,
                         char *nombreArchivoF)
{
    FILE* fpArch1 = fopen(nombreArchivo1, "rb");
    FILE* fpArch2 = fopen(nombreArchivo2, "rb");
    FILE* fpFusion = fopen(nombreArchivoF, "wb");

    if (!fpArch1 || !fpArch2 || !fpFusion)
    {
        printf("ERROR: Al abrir el archivo.");
        return 0;
    }

    tProducto producto1;
    tProducto producto2;

    fread(&producto1, sizeof(tProducto), 1, fpArch1);
    fread(&producto2, sizeof(tProducto), 1, fpArch2);

    while(!feof(fpArch1) && !feof(fpArch2))
    {
        if (producto1.idProducto <= producto2.idProducto)
        {
            /// Normalizamos la descripcion del producto
            memcpy(producto1.descripcion, normalizarCadena_MIO(producto1.descripcion), sizeof(producto1.descripcion));

            fwrite(&producto1, sizeof(tProducto), 1, fpFusion);
            fread(&producto1, sizeof(tProducto), 1, fpArch1);
        }

        if (producto2.idProducto < producto1.idProducto)
        {
            /// Normalizamos la descripcion del producto
            memcpy(producto2.descripcion, normalizarCadena_MIO(producto2.descripcion), sizeof(producto2.descripcion));

            fwrite(&producto2, sizeof(tProducto), 1, fpFusion);
            fread(&producto2, sizeof(tProducto), 1, fpArch2);
        }

    }

    while(!feof(fpArch1))
    {
        /// Normalizamos la descripcion del producto
        memcpy(producto1.descripcion, normalizarCadena_MIO(producto1.descripcion), sizeof(producto1.descripcion));

        fwrite(&producto1, sizeof(tProducto), 1, fpFusion);
        fread(&producto1, sizeof(tProducto), 1, fpArch1);
    }

    while(!feof(fpArch2))
    {
        /// Normalizamos la descripcion del producto
        memcpy(producto2.descripcion, normalizarCadena_MIO(producto2.descripcion), sizeof(producto2.descripcion));

        fwrite(&producto2, sizeof(tProducto), 1, fpFusion);
        fread(&producto2, sizeof(tProducto), 1, fpArch2);
    }

    fclose(fpArch1);
    fclose(fpArch2);
    fclose(fpFusion);

    return 0;
}
/** FIN de PUNTO 2 **/


/** para el PUNTO 3 **/

int insertar_lista_final(tLista* pl, const void* info, unsigned tamInfo)
{
    tNodo* nueNodo = (tNodo*)malloc(sizeof(tNodo));
    if (!nueNodo)
    {
        printf("SIN MEMORIA.\n");
        return 0;
    }

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        free(nueNodo);
        printf("SIN MEMORIA.\n");
        return 0;
    }

    /// Nos posicionamos al final
    while(*pl)
    {
        pl = &(*pl)->sig;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->sig = *pl;

    *pl = nueNodo;

    return 1;
}

int insertar_lista(tLista* pl, const void* info, unsigned tamInfo)
{
    tNodo* nueNodo = (tNodo*)malloc(sizeof(tNodo));
    if (!nueNodo)
    {
        printf("SIN MEMORIA.\n");
        return 0;
    }

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        free(nueNodo);
        printf("SIN MEMORIA.\n");
        return 0;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->sig = *pl;

    *pl = nueNodo;

    return 1;
}

int cargarMaestroEnLista_MIO(char *nombreArchivoMaestro,
                                                tLista *pl,
                                                FILE *fpPantalla)
{

    FILE* fpMaestro = fopen(nombreArchivoMaestro, "rb");
    if (!fpMaestro)
    {
        printf("ERROR al abrir archivo binario en modo lectura.\n");
        return 0;
    }

    tProducto producto;
    fread(&producto, sizeof(tProducto), 1, fpMaestro);

    while(!feof(fpMaestro))
    {
        insertar_lista_final(pl, &producto, sizeof(tProducto));
        fread(&producto, sizeof(tProducto), 1, fpMaestro);
    }

    fclose(fpMaestro);

    return 0;
}
/** FIN de PUNTO 3 **/



/** para el PUNTO 4 **/
int ver_primero_lista(tLista* pl, void* info, unsigned tamInfo)
{
    if(!*pl)
    {
        printf("Lista Vacia.\n");
        return 0;
    }

    memcpy(info, (*pl)->info, MIN(tamInfo, (*pl)->tamInfo));

    return 1;
}

int eliminarDupYsobrescibirMaestro_MIO(tLista *pl,
                                       int *cantDupEliminados,
                                       const char *nombreArchivoMaestro)
{
    FILE* fpMaestro = fopen(nombreArchivoMaestro, "wb");
    if (!fpMaestro)
    {
        printf("ERROR: Al abrir archivo binario escritura.\n");
        return 0;
    }

    tProducto producto1;
    tProducto producto2;

    sacar_primero_lista(pl, &producto1, sizeof(tProducto));

    (*cantDupEliminados) = 0;

    while(sacar_primero_lista(pl, &producto2, sizeof(tProducto)))
    {
        if(producto1.idProducto == producto2.idProducto )
        {
            (*cantDupEliminados)++;
            producto1.cantidad += producto2.cantidad;
        }
        else
        {
            /// Sobreescribir archivo maestro
            fwrite(&producto1, sizeof(tProducto), 1, fpMaestro);
            producto1 = producto2;
        }
    }

    return TODO_BIEN;
}
/** FIN de PUNTO 4 **/


/** para el PUNTO 5 **/

int cmpNroProducto(const void* producto1, const void* producto2)
{
    tNovedad* p1 = (tNovedad*)producto1;
    tNovedad* p2 = (tNovedad*)producto2;


    /// 0  => son iguales
    /// >0 => p1 > p2
    /// <0 => p1 < p2
    return p1->idProducto - p2->idProducto;
}

void imprimir_lista(tLista* pl)
{
    tNovedad* pNovedad = (tNovedad*)(*pl)->info;

    while(*pl != NULL)
    {
        pNovedad = (tNovedad*)(*pl)->info;
        printf("INFO: %ld|%c|%d\n", pNovedad->idProducto, pNovedad->tipoMovimiento, pNovedad->cantidad);
        printf("TAM INFO: %ld\n", (long)sizeof(tNovedad));
        printf("SIG: %p\n", &(*pl)->sig);
        pl = &(*pl)->sig;
    }
    printf("d");
}

int insertar_lista_ord(tLista* pl, const void* info, unsigned tamInfo, int(*cmp)(const void*, const void*))
{
    tNodo* nueNodo = (tNodo*)malloc(sizeof(tNodo));
    if(!nueNodo)
    {
        printf("SIN MEMORIA.\n");
        return 0;
    }
    nueNodo->info = malloc(tamInfo);
    if(!nueNodo)
    {
        free(nueNodo);
        printf("SIN MEMORIA.\n");
        return 0;
    }

    /// Posicionamos el nodo
    while(*pl && ( cmp((*pl)->info, info) < 0 ) )
    {
        pl = &(*pl)->sig;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->sig = *pl;

    /// Enganchamos el nodo
    *pl = nueNodo;

    return 1;
}

int sacar_primero_lista(tLista* pl, void* info, unsigned tamInfo)
{
    if (!*pl)
    {
        printf("LISTA VACIA.\n");
        return 0;
    }

    tNodo* aux = *pl;

    memcpy(info, aux->info, MIN(tamInfo, aux->tamInfo));
    *pl = aux->sig;

    free(aux->info);
    free(aux);

    return 1;
}

int actualizarMaestroDesdeArchivoDeNovedades_MIO(char *nombreArchivoMaestro,
                                                 char *nombreArchivoNovedades,
                                                 FILE *fpPantalla)
{
    FILE* fpMaestro = fopen(nombreArchivoMaestro, "r+b");
    FILE* fpNovedades = fopen(nombreArchivoNovedades, "rt");

    if (!fpMaestro || !fpNovedades)
    {
        puts("ERROR: Al abrir archivo binario de lectura.\n");
        return 0;
    }

    tLista listaNovedades;
    tProducto producto;
    tNovedad novedad;
    char cadena[50];

    /// Armamos lista ordenada de novedades (por numero de producto)
    crearLista(&listaNovedades);

    while(fgets(cadena, sizeof(cadena), fpNovedades))
    {
        sscanf(cadena, "%ld|%c|%d\n", &novedad.idProducto, &novedad.tipoMovimiento, &novedad.cantidad);
        insertar_lista_ord(&listaNovedades, &novedad, sizeof(tNovedad), cmpNroProducto);
    }

    //printf("IMPRIMIR LISTA.\n");
    //imprimir_lista(&listaNovedades);

    /// Leemos la lista y actualizamos el archivo maestro (productos)
    fread(&producto, sizeof(tProducto), 1, fpMaestro);
    int finDeLista = sacar_primero_lista(&listaNovedades, &novedad, sizeof(tNovedad));
    int cantActualizaciones = 0;
    while(!feof(fpMaestro))
    {
        while(producto.idProducto == novedad.idProducto && finDeLista)
        {
            if (novedad.tipoMovimiento == 'E')
            {
                producto.cantidad -= novedad.cantidad;
            }

            if (novedad.tipoMovimiento == 'I')
            {
                producto.cantidad += novedad.cantidad;
            }

            cantActualizaciones++;
            finDeLista = sacar_primero_lista(&listaNovedades, &novedad, sizeof(tNovedad));
        }

        /// Actualizamos el producto
        fseek(fpMaestro, -(long)sizeof(tProducto), SEEK_CUR);
        fwrite(&producto, sizeof(tProducto), 1, fpMaestro);
        fseek(fpMaestro, 0L, SEEK_CUR);


        /// Leemos un nuevo producto
        fread(&producto, sizeof(tProducto), 1, fpMaestro);

    }


    fclose(fpNovedades);
    fclose(fpMaestro);


    return cantActualizaciones;
}

/** FIN de PUNTO 5 **/

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

