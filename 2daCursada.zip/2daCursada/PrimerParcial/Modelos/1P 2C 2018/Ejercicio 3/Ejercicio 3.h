#ifndef EJERCICIO_3_H_INCLUDED
#define EJERCICIO_3_H_INCLUDED

void mat_transpuesta_insitu(int mat[][6],int tam);
void muestra_mat_cuadrada(int mat[][6],int tam);

#endif // EJERCICIO_3_H_INCLUDED
