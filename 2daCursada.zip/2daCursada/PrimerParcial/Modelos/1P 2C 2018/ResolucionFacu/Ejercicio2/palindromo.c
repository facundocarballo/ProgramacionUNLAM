#include "palindromo.h"

/// Auxiliares
int strlen_alu(char* cad)
{
    int len = 0;

    while(*(cad) != '\0')
    {
        len++;
        cad++;
    }

    return len;
}

void sacar_espacios(char* cad, int len)
{
    char* aux = cad;
    char* aux2;
    while(*(cad) != '\0')
    {
        while(*(cad) != ' ' && *(cad) != '\0')
        {
            cad++;
        }

        if (*(cad) != '\0')
        {
            /// Encontramos un espacio
            aux = cad+1;
            aux2 = cad;
            while(*(aux) != '\0')
            {
                *cad = *aux;
                aux++;
                cad++;
            }
            *cad = '\0';
            cad = aux2;
        }
    }
}

void cadena_a_minuscula(char* cad)
{
    while(*(cad) != '\0')
    {
        *cad = toLowerCase_alu(*cad);
        cad++;
    }
}

void formatear_cadena(char* cad)
{

    /// Primero Sacamos los espacios
    sacar_espacios(cad, strlen_alu(cad));

    /// Segundo pasamos todo a minuscula
    cadena_a_minuscula(cad);

}



/// esPalindromo
int esPalindromo(char* cad)
{
    char* ini = cad;
    char* fin = cad + (strlen_alu(cad) - 1);

    /// Obtenemos una letra de ini
    while(!esLetra(*ini)) ini++;
    /// Obtenemos una letra de fin
    while(!esLetra(*fin)) fin--;

    while(toLowerCase_alu(*(ini)) == toLowerCase_alu(*(fin)) && ini != fin)
    {
        ini++;
        fin--;

        /// Obtenemos una letra de ini
        while(!esLetra(*ini)) ini++;
        /// Obtenemos una letra de fin
        while(!esLetra(*fin)) fin--;

    }

    if (ini == fin && *(ini) == *(fin))
    {
        /// Es palindromo
        return 1;
    }

    return 0;
}
