#include "palindromo.h"

int main()
{
    char anita[] = {"Anita lava la tina"};
    char estudiantes[] = {"Aguante Estudiantes de la Plata"};

    printf("Ejercicio 2, son Palindromos?\n\n");

    printf("Anita lava la tina\n");
    if(esPalindromo(anita))
    {
        puts("ES PALINDROMO");
    }else
    {
        puts("NO ES PALINDROMO");
    }

    printf("Aguante Estudiantes de la Plata\n");
    if(esPalindromo(estudiantes))
    {
        puts("ES PALINDROMO");
    }else
    {
        puts("NO ES PALINDROMO");
    }


    return 0;
}
