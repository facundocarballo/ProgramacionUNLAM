#ifndef PALINDROMO_H_INCLUDED
#define PALINDROMO_H_INCLUDED

#include <stdio.h>
#include<stdlib.h>

/// Macros
#define toLowerCase_alu(a)( ((a <= 'Z') && (a >= 'A')) ? (a + ('a'-'A') ) : a )
#define esLetra(a)( ( ( (a <= 'Z') && (a >= 'A') ) || ( (a <= 'z') && (a >= 'a') ) ) ? 1 : 0 )

/// Auxiliares

int esPalindromo(char* cad);

#endif // PALINDROMO_H_INCLUDED
