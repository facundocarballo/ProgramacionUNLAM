#include <stdio.h>
#include <stdlib.h>

#define ES_MAYUSCULA(x) ( (x >= 'A') && (x <= 'Z') )
#define ES_MINUSCULA(x) ( (x >= 'a') && (x <= 'z') )
#define ES_LETRA(x)( ES_MAYUSCULA(x) || ES_MINUSCULA(x) )
#define A_MINUSCULA(x) ( ES_MAYUSCULA(x) ? ( x + ('a' - 'A') ) : x )
#define A_MAYUSCULA(x) ( ES_MINUSCULA(x) ? ( x - ('a' - 'A') ) : x )

int strlen_alu(char* cad);
int es_palindromo(char* cad);

int main()
{
    char cadena[] = {"515641()Anita   lava la %&!�ti%!na"};

    printf("\n%s\n\n", cadena);
    if (es_palindromo(cadena))
    {
        printf("ES PALINDROMO\n");
    }
    else
    {
        printf("NO ES PALINDROMO\n");
    }
    return 0;
}

int strlen_alu(char* cad)
{
    int len = 0;
    while(*cad)
    {
        cad++;
        len++;
    }

    return len;
}

int es_palindromo(char* cad)
{
    int palindromo = 1;
    char* ini = cad;
    char* fin = cad + (strlen_alu(cad) - 1);

    while(palindromo && ini < fin)
    {
        /// Nos posicionamos en la ultima letra de la cadena
        while(!ES_LETRA(*fin) && fin != ini)
            fin--;

        /// Nos posicionamos en la primera letra de la cadena
        while(!ES_LETRA(*ini) && *ini != '\0')
            ini++;

        /// Comprobamos que sean la misma letra
        if (A_MINUSCULA(*ini) != A_MINUSCULA(*fin))
            palindromo = 0;

        ini++;
        fin--;
    }

    return palindromo;

}
