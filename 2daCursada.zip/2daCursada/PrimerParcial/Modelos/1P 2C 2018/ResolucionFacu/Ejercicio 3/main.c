#include <stdio.h>
#include <stdlib.h>
#define TAM 4

void imprimirMatriz(int matriz[][TAM])
{
    int fila, columna;

    for(fila = 0; fila < TAM; fila++)
    {
        for(columna = 0; columna < TAM; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }
}

void trasponerMatriz(int matriz[][TAM])
{
    int fila, columna, aux;

    for(fila = 0; fila < TAM; fila++)
    {
        for(columna = fila+1; columna < TAM; columna++)
        {
            aux = matriz[fila][columna];
            matriz[fila][columna] = matriz[columna][fila];
            matriz[columna][fila] = aux;
        }
    }

}

int main()
{
    int matriz[][TAM] = {
        {89,33,17,50},
        {73,21,29,57},
        {31,15,30,75},
        {40,91,10,35},
    };

    printf("Ejercicio 3 - Trasponer una matriz insitu\n");

    imprimirMatriz(matriz);
    puts("-------");

    trasponerMatriz(matriz);

    imprimirMatriz(matriz);


    return 0;
}
