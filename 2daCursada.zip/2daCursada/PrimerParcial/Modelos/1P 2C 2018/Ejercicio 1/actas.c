#include<actas.h>
#include<lista.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

void generar_acta(const char * path_alus, const char * arch_notas, const char * arch_acta, const char * arch_obs){
    FILE *arch_alus = fopen(path_alus,"rb"),*arch_nota = fopen(arch_notas,"r"),*arch_act = fopen(arch_acta,"w"),*arch_ob=fopen(arch_obs,"w");
    //if(arch_alus == NULL || arch_nota==NULL || arch_act==NULL || arch_ob==NULL)
        //return 10;
    t_alumno alum;
    t_nota nota;
    t_acta acta;
    t_lista lista;
    crear_lista(&lista);
    char cad[90],*aux;
    fread(&alum,sizeof(t_alumno),1,arch_alus);

    while(!feof(arch_alus)){
        fseek(arch_nota,0l,SEEK_SET);
        aux = fgets(cad,sizeof(cad),arch_nota);
        texto_a_nota_res(cad,&nota);
        acta.p1=0; acta.p2=0; acta.r1=0; acta.r2=0;
        acta.dni = alum.dni;
        strcpy(acta.apyn,alum.apyn);

          while(aux!=NULL){
            if(alum.dni==nota.dni){
                if(strcmp(nota.tipo,"P1")==0) acta.p1=nota.nota;
                if(strcmp(nota.tipo,"P2")==0) acta.p2=nota.nota;
                if(strcmp(nota.tipo,"R1")==0) acta.r1=nota.nota;
                if(strcmp(nota.tipo,"R2")==0) acta.r2=nota.nota;
                printf("\n\n-----------\n%ld %s %d",nota.dni,nota.tipo,nota.nota);
                aux = fgets(cad,sizeof(cad),arch_nota);
                texto_a_nota_res(cad,&nota);

            }
            else{
                aux = fgets(cad,sizeof(cad),arch_nota);
                texto_a_nota_res(cad,&nota);
            }

          }
        calcular_nota_final_res(&acta);
        insertar_lista(&lista,&acta,comparar);
        fread(&alum,sizeof(t_alumno),1,arch_alus);
    }

    while(!lista_vacia(&lista)){
        sacar_primero_lista(&lista,&acta);
        fprintf(arch_act,"%ld %s\t%d %d %d %d %d %s\n",acta.dni,acta.apyn,acta.p1,acta.p2,acta.r1,acta.r2,acta.nota,acta.cond);
    }


}

void calcular_nota_final(t_acta *a){

}

void validar_nota_final(const t_acta *a, FILE * arch_obs){

}
