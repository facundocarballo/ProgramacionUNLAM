#include <stdio.h>
#include <stdlib.h>

/*
Desofuscar la siguiente lineal de texto:
linea="jN jmot k sji sorjdknodrj; ji ouq jmot so omrkdouq nes sjiio. lkksI vjmesA"
La l�nea fue ofuscada de la siguiente manera:
    1.Se identificaron las palabras, bloques de texto compuestos por letras a..z A..Z
    2.Se dieron vuelta las palabras, ej. : hola=>aloh
    3.Se retrocedieron los caracteres pertenecientes al conjunto : "acefhijklo" 3 posiciones en el mismo conjunto de forma circular, luego de la o esta la a.

No utilice cadenas auxiliares.
*/

#define ES_MINUSCULA(x)(x >= 'a' && x <= 'z')
#define ES_MAYUSCULA(x)(x >= 'A' && x <= 'Z')
#define ES_LETRA(x)(ES_MAYUSCULA(x) || ES_MINUSCULA(x))

char obtener_caracter(const char caracter, const char* conjuntoDeCaracteres)
{
    int i = 0;
    /// Buscamos esa letra en el conjunto
    while(*conjuntoDeCaracteres && caracter != *conjuntoDeCaracteres)
    {
        conjuntoDeCaracteres++;
        i++;
    }



}

void mostrar_mensaje(char* msjOfuscado)
{
    const char conjuntoCaracteres[] = {"acefhijklo"};
    char* iniPalabra;
    char* finPalabra;

    /// Buscamos el comienzo de una palabra
    while(!ES_LETRA(*msjOfuscado))
        msjOfuscado++;

    /// Como estan escritas al revez, obtuvimos el final de la palabra
    finPalabra = msjOfuscado;

    /// Obtenemos el puntero al inicio de esta palabra
    while(ES_LETRA(*(msjOfuscado+1))
        msjOfuscado++;

    iniPalabra = msjOfuscado;


    /// Leemos la palabra y vamos modificando los caracteres
    while(finPalabra < iniPalabra)
    {
        *finPalabra = obtener_caracter(*iniPalabra, conjuntoCaracteres);
        finPalabra++;
    }


}


int main()
{
    char cadenaOfuscada[] = {"jN jmot k sji sorjdknodrj; ji ouq jmot so omrkdouq nes sjiio. lkksI vjmesA"};


    return 0;
}
