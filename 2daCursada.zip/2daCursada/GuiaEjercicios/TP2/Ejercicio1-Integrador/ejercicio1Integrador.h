#ifndef EJERCICIO1INTEGRADOR_H_INCLUDED
#define EJERCICIO1INTEGRADOR_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MSJ "Seleccione una de las siguientes opciones:\n- M: Buscar el minimo\n- P: Calcular el promedio de los elementos\n- I: Mostrarlo en orden inverso\n- S: Salir"
#define OPC "MmPpIiSs"

int imprimirVectorFloat(float* vec, int cantElem);
int ingresarCantElem();
int ingresarVecFloat(float* vec, int cantElem);

// Ejercicio 1.A
char desplegarMenu(const char* msg, const char* opc);
// Ejercicio 1.B
int ingresoDeNumeros(float* vec, int cantElem);
// Ejercicio 1.C
float buscarMinimo(float* vec, int cantElem);
// Ejercicio 1.D
int imprimirVectorOrdenInverso(float* vec, int cantElem);
// Ejercicio 1.E
float promedioDelVector(float* vec, int cantElem);
// Ejercicio 1.F
int escribirEnArchivoTXT(float* vecm, int cantElem, FILE* fp);
// Ejercicio 1.G
int programaCompleto();


#endif // EJERCICIO1INTEGRADOR_H_INCLUDED
