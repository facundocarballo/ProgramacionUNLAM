#include "ejercicio1Integrador.h"

// Ejercicio 1.A
char desplegarMenu(const char* msj, const char* opc)
{
    char opta;
    int primVez = 1;

    do
    {
        if(!primVez)
        {
            primVez = 0;
            puts("ERROR! Opcion no valida.");

        }
        printf("%s\n> ", msj);
        fflush(stdin);
        scanf("%c", &opta);
    }while(strchr(opc, opta) == NULL);

    return opta;
}

int escribirEnArchivoTXT(float* vec, int cantElem, FILE* fp)
{
    fprintf(fp, "[ ");
    for(int i = 0; i < cantElem; i++)
    {
        fprintf(fp, "%5.2f ", *(vec + i));
    }
    fprintf(fp, "]\n");

    return 1;
}

// Ejercicio
float buscarMinimo(float* vec, int cantElem)
{
    float min = *(vec);
    int i = 1; // Como ya inicializamos 'min' con el contenido de la posicion 0 del vector de flotantes, le ponemos que empiece desde el 1


    while(i < cantElem)
    {
        if (*(vec + i) < min) min = *(vec + i);
        i++;
    }

    printf("El elemento con menor valor es: %5.2f\n", min);
    return min;
}
//
float promedioDelVector(float* vec, int cantElem)
{
    float sumatoria = *(vec);
    int i = 1;

    while(i < cantElem)
    {
        sumatoria += *(vec + i);
        i++;
    }

    printf("El promedio del vector es: %5.2f\n", sumatoria / (float)cantElem);

    return sumatoria / (float)cantElem;
}

int imprimirVectorOrdenInverso(float* vec, int cantElem)
{
    printf("[ ");
    while(cantElem > 0)
    {
        printf("%5.2f ", *(vec + (cantElem - 1)));
        cantElem--;
    }
    printf("]\n");

    return 1;
}

int ingresarVecFloat(float* vec, int cantElem)
{
    int i = 0;
    puts("Ingresa tu vector de uno en uno.");
    while(i < cantElem)
    {
        printf("> ");
        fflush(stdin);
        scanf("%f", vec + i);
        i++;
    }

    return 1;
}

int ingresarCantElem()
{
    int cantElem = -1;
    int primVez = 1;
    puts("Bienvenido!\n Ingrese la cantidad de elementos del vector de flotantes");
    while(cantElem < 0 || cantElem > 10000)
    {
        if(!primVez)
        {
            primVez = 0;
            puts("ERROR! Ingresaste un numero menor a cero o mayor a 1000. Por favor, ingresa un numero correcto para continuar");
        }
        printf("> ");
        fflush(stdin);
        scanf("%d", &cantElem);
    }

    return cantElem;
}

int imprimirVectorFloat(float* vec, int cantElem)
{
    int i = 0;
    float* vecAux = vec;
    printf("[ ");
    while(i < cantElem)
    {
        printf("%5.2f ", *(vecAux + i));
        i++;
    }

    printf("]\n");

    return 1;
}
