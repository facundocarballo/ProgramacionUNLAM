#include "ejercicio1Integrador.h"

int main()
{
    FILE* fp = fopen("VectorFlotante.txt", "wt");
    if (fp == NULL) return -1;
    int cantElem = ingresarCantElem();
    float vec[1000];
    char opta = '|';
    printf("Cant. Elem: %d\n", cantElem);
    ingresarVecFloat(vec, cantElem);


    while(strchr("Ss", opta) == NULL)
    {
        switch(opta = desplegarMenu(MSJ, "MmPpIiSs"))
        {
            case('M'):
                buscarMinimo(vec, cantElem);
                break;
            case('m'):
                buscarMinimo(vec, cantElem);
                break;
            case('P'):
                promedioDelVector(vec, cantElem);
                break;
            case('p'):
                promedioDelVector(vec, cantElem);
                break;
            case('I'):
                imprimirVectorOrdenInverso(vec, cantElem);
                break;
            case('i'):
                imprimirVectorOrdenInverso(vec, cantElem);
                break;
            default: break;
        }
    }

    escribirEnArchivoTXT(vec, cantElem, fp);
    fclose(fp);
    return 0;
}
