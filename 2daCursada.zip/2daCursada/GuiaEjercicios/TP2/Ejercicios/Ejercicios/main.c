#include "vectores.h"

int main()
{
    tLista lista;
    crearListaInt(&lista);
    agregarNodoAlFinal(&lista, 10);
    agregarNodoAlFinal(&lista, 11);
    imprimirLista(&lista);
    return 0;
}
