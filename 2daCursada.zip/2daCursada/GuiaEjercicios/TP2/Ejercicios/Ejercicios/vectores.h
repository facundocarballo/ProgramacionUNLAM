#ifndef VECTORES_H_INCLUDED
#define VECTORES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef struct sNodo {
    int info;
    struct sNodo* sig;
}tNodo;
typedef tNodo* tLista;

// Ejercicio 2
int* direccionDelElemento(int* vec, int offset);

int crearListaInt(tLista* pL);
tNodo* crearNodo(int info);
int agregarNodoAlFinal(tLista* pL, int info);
int imprimirLista(tLista* pL);





#endif // VECTORES_H_INCLUDED
