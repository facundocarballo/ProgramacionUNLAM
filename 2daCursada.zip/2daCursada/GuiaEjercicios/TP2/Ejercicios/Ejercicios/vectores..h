#ifndef VECTORES__H_INCLUDED
#define VECTORES__H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

// Ejercicio 2
int* direccionDelElemento(int* vec, int cantElem);

#endif // VECTORES__H_INCLUDED
