#include "vectores.h"

int* direccionDelElemento(int* vec, int offset)
{
    return vec+offset;
}

int crearListaInt(tLista* pL)
{
    *pL = NULL;

    return 1;
}

tNodo* crearNodo(int info)
{
    tNodo* pNodo = (tNodo*)malloc(sizeof(tNodo));

    pNodo->info = info;
    pNodo->sig = NULL;

    return pNodo;
}

int agregarNodoAlFinal(tLista* pL, int info)
{
    tLista aux = *pL;

    // Creamos el nodo
    tNodo* pNodo = crearNodo(info);

    // Recorremos la lista
    while(!aux->sig) aux = aux->sig;

    // Asignamos el nodo a la lista.
    aux = pNodo;

    return 1;
}

int imprimirLista(tLista* pL)
{
    tLista aux = *pL;

    while(!aux)
    {
        printf("DATO: %d\n", aux->info);
        aux = aux->sig;
    }

    return 1;
}
