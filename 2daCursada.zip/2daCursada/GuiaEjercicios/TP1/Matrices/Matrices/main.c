#include "matrices.h"

int main()
{
    // int[filas][columnas]
    int matriz[][TAM] = {
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    int resultados[][TAM] = {
        {0,4,2},
        {1,0,3},
        {2,3,0}
    };


    int* puntos;

    puts("MATRIZ");
    imprimirMatriz(matriz);
    puts("---------------------------------");
    puts("ENCIMA DIAGONAL PRINCIPAL");
    imprimirEncimaDiagonalPrincipal(matriz);
    sumatoriaEncimaDiagonalPrincipal(matriz);
    puts("---------------------------------");
    puts("ENCIMA DIAGONAL SECUNDARIA");
    imprimirEncimaDiagonalSecundaria(matriz);
    sumatoriaEncimaDiagonalSecundaria(matriz);
    puts("---------------------------------");
    puts("DEBAJO DIAGONAL PRINCIPAL");
    imprimirDebajoDiagonalPrincipal(matriz);
    sumatoriaDebajoDiagonalPrincipal(matriz);
    puts("---------------------------------");
    puts("DEBAJO DIAGONAL SECUNDARIA");
    imprimirDebajoDiagonalSecundaria(matriz);
    sumatoriaDebajoDiagonalSecundaria(matriz);
    puts("---------------------------------");
    puts("DEBAJO DIAGONAL PRIMARIA INCLUIDA");
    imprimirDebajoDiagonalPrincipalIncluida(matriz);
    puts("---------------------------------");
    puts("DIAGONAL PRINCIPAL");
    imprimirDiagonalPrincipal(matriz);
    puts("---------------------------------");
    puts("DIAGONAL SECUNDARIA");
    imprimirDiagonalSecundaria(matriz);
    puts("---------------------------------");
    puts("ES MATRIZ DIAGONAL?");
    esMatrizDiagonal(matriz);
    puts("---------------------------------");
    puts("ES MATRIZ IDENTIDAD?");
    esMatrizIdentidad(matriz);
    puts("---------------------------------");
    puts("ES MATRIZ SIMETRICA?");
    esMatrizSimetrica(matriz);
    puts("---------------------------------");
    puts("TRANSPONER insitu UNA MATRIZ");
    transponerMatriz(matriz);
    /*
      Cuando devuelve esta matriz, queda ya traspuesta.
      Porque como utilizamos subindices para hacer referencia
      a los elementos de la matriz, en realidad estamos operando
      con punteros. Entonces el valor se modifica tambien en el main
      y no solo dentro de la funcion
    */
    puts("---------------------------------");
    puts("MULTIPLICACION DE MATRICES");
    multiplicarMatrices(matriz, matriz);
    /*
      Cuando devuelve esta matriz, queda ya multiplicada.
      Porque como utilizamos subindices para hacer referencia
      a los elementos de la matriz, en realidad estamos operando
      con punteros. Entonces el valor se modifica tambien en el main
      y no solo dentro de la funcion
    */
    puts("---------------------------------");
    puts("TRIANGULAR IDA Y VUELTA");
    if (laMatrizEsCorrecta(resultados))
    {
        puts("LA MATRIZ ES CORRECTA");
        puntos = cantidadDePuntosDelEquipo(resultados, 0);
        imprimirVector(puntos, TAM);
    }

    free(puntos);


    puts("\n\n\n--------MATRICES PICANTES--------\n");
    puts("Sumatoria de los elementos que se encuentran a la arriba de la digonal principal y de la diagonal secundaria");
    sumatoriaArribaDiagonalPrincipalYSecundaria(matriz);
    puts("Mostrar esos elementos formateados");
    mostrarElementosArribaDiagonalPrincipalYSecundaria(matriz);
    puts("\n-------------------------------------\n");

    puts("Sumatoria de los elementos que se encuentran derecha de la digonal principal y de la diagonal secundaria");
    sumatoriaDerechaDiagonalPrincipalYSecundaria(matriz);
    puts("Mostrar esos elementos formateados");
    mostrarElementosDerechaDiagonalPrincipalYSecundaria(matriz);
    puts("\n-------------------------------------\n");

    puts("Sumatoria de los elementos que se encuentran abajo de la digonal principal y de la diagonal secundaria");
    sumatoriaAbajoDiagonalPrincipalYSecundaria(matriz);
    puts("Mostrar esos elementos formateados");
    mostrarElementosAbajoDiagonalPrincipalYSecundaria(matriz);
    puts("\n-------------------------------------\n");

    puts("Sumatoria de los elementos que se encuentran a la izquierda de la digonal principal y de la diagonal secundaria");
    sumatoriaIzquierdaDiagonalPrincipalYSecundaria(matriz);
    puts("Mostrar esos elementos formateados");
    mostrarElementosIzquierdaDiagonalPrincipalYSecundaria(matriz);
    puts("\n-------------------------------------\n");

    printf("-----------ROTAR MATRIZ-----------\n");
    rotarMatriz(matriz);

    puts("TRASPONER MATRIZ SEGUN DIAGONAL SECUNDARIA");
    printf("Matriz original...\n");
    imprimirMatriz(matriz);
    trasponer_matriz_segund_diag_sec(matriz);
    puts("Matriz traspuesta...");
    imprimirMatriz(matriz);

    return 0;
}
