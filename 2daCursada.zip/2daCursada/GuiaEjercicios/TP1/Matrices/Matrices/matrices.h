#ifndef MATRICES_H_INCLUDED
#define MATRICES_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

#define TAM 3

#define MAX(x,y)(x > y ? x : y)
#define MIN(x,y)(x < y ? x : y)

/// auxs
int imprimirMatriz(int matriz[][TAM]);
int imprimirEncimaDiagonalPrincipal(int matriz[][TAM]);
int imprimirEncimaDiagonalSecundaria(int matriz[][TAM]);
int imprimirDebajoDiagonalPrincipal(int matriz[][TAM]);
int imprimirDebajoDiagonalSecundaria(int matriz[][TAM]);
int imprimirDebajoDiagonalPrincipalIncluida(int matriz[][TAM]);
int imprimirDiagonalPrincipal(int matriz[][TAM]);
int imprimirDiagonalSecundaria(int matriz[][TAM]);
int imprimirVector(int* vec, int cantElem);

/// Encima Diagonal
int sumatoriaEncimaDiagonalPrincipal(int matriz[][TAM]);
int sumatoriaEncimaDiagonalSecundaria(int matriz[][TAM]);

/// Debajo Diagonal
int sumatoriaDebajoDiagonalPrincipal(int matriz[][TAM]);
int sumatoriaDebajoDiagonalSecundaria(int matriz[][TAM]);

/// Matriz Diagonal
int esMatrizDiagonal(int matriz[][TAM]);

/// MATRIZ IDENTIDAD
int esMatrizIdentidad(int matriz[][TAM]);

/// MATRIZ SIMETRICA
int esMatrizSimetrica(int matriz[][TAM]);

/// TRASPONER MATRIZ insitu
int transponerMatriz(int matriz[][TAM]);

/// MULTIPLICACION DE MATRICES CUADRADAS
int multiplicarMatrices(int matriz1[][TAM], int matriz2[][TAM]);

/// TRIANGULAR IDA Y VUELTA
int laMatrizEsCorrecta(int matriz[][TAM]);
int* cantidadDePuntosDelEquipo(int matriz[][TAM], int equipo);

/// MATRICES PICANTES

// Arriba
int sumatoriaArribaDiagonalPrincipalYSecundaria(int matriz[][TAM]);
void mostrarElementosArribaDiagonalPrincipalYSecundaria(int matriz[][TAM]);

// Derecha
int sumatoriaDerechaDiagonalPrincipalYSecundaria(int matriz[][TAM]);
void mostrarElementosDerechaDiagonalPrincipalYSecundaria(int matriz[][TAM]);

// Abajo
int sumatoriaAbajoDiagonalPrincipalYSecundaria(int matriz[][TAM]);
void mostrarElementosAbajoDiagonalPrincipalYSecundaria(int matriz[][TAM]);

// Izquierda
int sumatoriaIzquierdaDiagonalPrincipalYSecundaria(int matriz[][TAM]);
void mostrarElementosIzquierdaDiagonalPrincipalYSecundaria(int matriz[][TAM]);

/// Rotar Matriz
void rotarMatriz(int matriz[][TAM]);

/// Trasponer matriz segun diagonal secundaria
void trasponer_matriz_segund_diag_sec(int matriz[][TAM]);

///// Crear matriz orden N
//int* crear_matriz(int orden);

#endif // MATRICES_H_INCLUDED
