#include "matrices.h"


int imprimirMatriz(int* matriz, int orden)
{
    int j = 0;
    int filas = 0;

    while(j < (orden*orden))
    {
        printf("%5d", *(matriz + j));
        j++;
        filas++;
        if(filas == orden)
        {
            filas = 0;
            printf("\n");
        }
    }

    return 1;
}

int imprimirEncimaDiagonalPrincipal(int* matriz, int orden)
{
    int i = 0;
    int min = 0;
    int max = orden;

    while (i < (orden*orden))
    {

        if (i == max)
        {
            printf("\n");
            min += orden + 1;
            max += orden;
        }

        if (i > min && i < max)
        {
            printf("%5d", *(matriz + i));
        }else
        {
            printf("%5c", '-');
        }

        i++;

    }

    printf("\n");

    return 1;
}

int imprimirEncimaDiagonalSecundaria(int* matriz, int orden)
{
    int i = 0;
    int min = -1;
    int max = orden - 1;
    int renglon = 1;


    while(i < (orden*orden))
    {
        if (i == (orden*renglon))
        {
            printf("\n");
            min += orden;
            max += orden - 1;
            renglon++;
        }

        if (i > min && i < max)
        {
            printf("%5d", *(matriz + i));
        }
        else
        {
            printf("%5c", '-');
        }

        i++;
    }

    printf("\n");

    return 1;
}

int sumatoriaEncimaDiagonalPrincipal(int* matriz, int orden)
{
    int i = 1;
    int min = 0;
    int max = orden;
    int sumatoria = *(matriz + i);

    printf("Sumatoria Encima Diagonal Principal:\n");

    imprimirEncimaDiagonalPrincipal(matriz, orden);

    while (i < (orden*orden))
    {
        i++;
        if (i == max) {
            min += orden + 1;
            max += orden;
        }
        if (i > min && i < max) sumatoria += *(matriz + i);

    }

    printf("Resultado: %d\n", sumatoria);

    return 1;
}

int sumatoriaEncimaDiagonalSecundaria(int* matriz, int orden)
{
    int i = 0;
    int min = -1;
    int max = orden - 1;
    int renglon = 1;
    int sumatoria = 0;


    printf("Imprimir Encima Diagonal Secundaria: \n");
    imprimirEncimaDiagonalSecundaria(matriz, orden);

    while(i < (orden*orden))
    {
        if(i == (orden * renglon))
        {
            renglon++;
            min += orden;
            max += orden - 1;
        }

        if (i > min && i < max) sumatoria += *(matriz + i);

        i++;
    }

    printf("Resultado: %d\n", sumatoria);

    return 1;
}
