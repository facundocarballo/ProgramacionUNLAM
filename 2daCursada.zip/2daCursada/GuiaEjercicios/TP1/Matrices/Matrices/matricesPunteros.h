#ifndef MATRICES_H_INCLUDED
#define MATRICES_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

// aux
int imprimirMatriz(int* matriz, int orden);

// Encima de la Diagonal
int sumatoriaEncimaDiagonalPrincipal(int* matriz, int orden);
int sumatoriaEncimaDiagonalSecundaria(int* matriz, int orden);
int sumatoriaEncimaDiagonalPrincipalIncluida(int* matriz, int orden);
int sumatoriaEncimaDiagonalSecundariaIncluida(int* matriz, int orden);

// Debajo de la diagonal
int sumatoriaDebajoDiagonalPrincipal(int* matriz, int orden);
int sumatoriaDebajoDiagonalSecundaria(int* matriz, int orden);
int sumatoriaDebajoDiagonalPrincipalIncluida(int* matriz, int orden);
int sumatoriaDebajoDiagonalSecundariaIncluida(int* matriz, int orden);

#endif // MATRICES_H_INCLUDED
