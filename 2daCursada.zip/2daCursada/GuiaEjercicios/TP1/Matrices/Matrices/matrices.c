#include "matrices.h"


int imprimirMatriz(int matriz[][TAM])
{
    int fila;
    int columna;

    for (fila = 0; fila < TAM; fila++)
    {
        for (columna = 0; columna < TAM; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }

    return 1;
}

int imprimirEncimaDiagonalPrincipal(int matriz[][TAM])
{
    int fila;
    int columna;

    for (fila = 0; fila < TAM; fila++)
    {
        printf("%*c", (fila+1)*5, ' ');

        for (columna = fila + 1; columna < TAM; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }

        printf("\n");
    }

    return 1;
}

int imprimirEncimaDiagonalSecundaria(int matriz[][TAM])
{
    int filas;
    int columnas;

    for (filas=0; filas < (TAM - 1); filas++)
    {
        for (columnas = 0; columnas < (TAM - filas -1); columnas++)
        {
            printf("%5d", matriz[filas][columnas]);
        }
        printf("\n");
    }

    return 1;
}

int imprimirDebajoDiagonalPrincipal(int matriz[][TAM])
{
    int fila, columna;

    for (fila = 0; fila < TAM; fila++)
    {
        for (columna = 0; columna < fila; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }

    return 1;
}

int imprimirDebajoDiagonalSecundaria(int matriz[][TAM])
{
    int fila, columna;

    for (fila = 0; fila < TAM; fila++)
    {
        printf("%*c", (TAM-fila)*5, ' ');
        for (columna = TAM-fila; columna < TAM; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }

    return 1;
}

int imprimirDebajoDiagonalPrincipalIncluida(int matriz[][TAM])
{
    int fila, columna;

    for(fila = 0; fila < TAM; fila++)
    {
        for(columna = 0; columna <= fila; columna++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }

    return 1;
}

int imprimirDiagonalPrincipal(int matriz[][TAM])
{
    int fila;

    for(fila = 0; fila < TAM; fila++)
    {
        printf("%*d", fila*5, matriz[fila][fila]);
        printf("\n");
    }

    return 1;
}
int imprimirDiagonalSecundaria(int matriz[][TAM])
{
    int fila;

    for(fila = 0; fila < TAM; fila++)
    {
        printf("%*d\n", (TAM - fila - 1) * 5, matriz[fila][TAM-(fila+1)]);
    }

    return 1;
}

int imprimirVector(int* vec, int cantElem)
{
    printf("[");
    for(int i = 0; i < cantElem; i++)
    {
        printf("%5d", *(vec+i));
    }
    printf("%5c", ']');

    return 1;
}

/// SUMATORIAS

int sumatoriaEncimaDiagonalPrincipal(int matriz[][TAM])
{
    int sumatoria = 0;
    int fila;
    int columna;

    for(fila=0; fila < TAM; fila++)
    {
        for(columna = fila+1; columna < TAM; columna++)
        {
            sumatoria += matriz[fila][columna];
        }
    }
    printf("El resultado de la sumatoria ENCIMA DIAGONAL PRINCIPAL ES: %d\n", sumatoria);

    return sumatoria;
}

int sumatoriaEncimaDiagonalSecundaria(int matriz[0][TAM])
{
    int sumatoria = 0;
    int filas;
    int columna;

    for (filas = 0; filas < (TAM - 1); filas++)
    {
        for (columna = 0; columna < (TAM - filas - 1); columna++)
        {
            sumatoria += matriz[filas][columna];
        }
    }

    printf("Resultado de la sumatoria ENCIMA DIAGONAL SECUNDARIA: %d\n", sumatoria);

    return sumatoria;
}


int sumatoriaDebajoDiagonalPrincipal(int matriz[][TAM])
{
    int fila, columna, sumatoria = 0;

    for (fila = 0; fila < TAM; fila++)
    {
        for (columna = 0; columna < fila; columna++)
        {
            sumatoria += matriz[fila][columna];
        }
    }

    printf("El resultado de la SUMATORIA DEBAJO DE LA DIAGONAL PRINCIPAL ES: %d\n", sumatoria);

    return sumatoria;
}

int sumatoriaDebajoDiagonalSecundaria(int matriz[][TAM])
{
    int fila, columna, sumatoria = 0;

    for (fila = 0; fila < TAM; fila++)
    {
        for (columna = TAM-fila; columna < TAM; columna++)
        {
            sumatoria += matriz[fila][columna];
        }
    }

    printf("El resultado de la SUMATORIA DEBAJO DE LA DIAGONAL PRINCIPAL ES: %d\n", sumatoria);

    return sumatoria;
}


/// MATRIZ DIAGONAL
int esMatrizDiagonal(int matriz[][TAM])
{
    int columna = 1, fila = 0, esDiagonal = 1;

    /// Recorremos el triangulo que se forma por encima de la diagonal principal
    while(fila < TAM && esDiagonal)
    {
        while(columna < TAM && esDiagonal)
        {
            if ( matriz[fila][columna] != 0 && matriz[columna][fila] != 0)
            {
                esDiagonal = 0;
            }
            columna++;
        }

        fila++;
        columna = (fila + 1);
    }


    if (esDiagonal)
    {
        puts("LA MATRIZ, ES UNA MATRIZ DIAGONAL");
    }
    else
    {
        puts("LA MATRIZ, NO ES UNA MATRIZ DIAGONAL");
    }


    return esDiagonal;
}

/// MATRIZ IDENTIDAD
int esMatrizIdentidad(int matriz[][TAM])
{
    int columna = 0, fila = 0, esIdentidad = 1;

    while(fila < TAM && esIdentidad)
    {
        while(columna < TAM && esIdentidad)
        {
            if (columna != fila && matriz[fila][columna] != 0 && matriz[columna][fila] != 0)
            {
                esIdentidad = 0;
            }

            if (columna == fila && matriz[fila][columna] != 1)
            {
                esIdentidad = 0;
            }
            columna++;
        }
        fila++;
        columna = fila;
    }

    if (esIdentidad)
    {
        puts("LA MATRIZ, ES UNA MATRIZ IDENTIDAD");
    }
    else
    {
        puts("LA MATRIZ, NO ES UNA MATRIZ IDENTIDAD");
    }

    return esIdentidad;
}

/// MATRIZ SIMETRICA
int esMatrizSimetrica(int matriz[][TAM])
{
    int fila, columna, esSimetria = 1;

    while(fila < TAM && esSimetria)
    {
        while(columna < TAM && esSimetria)
        {
            if (matriz[fila][columna] != matriz[columna][fila])
            {
                esSimetria = 0;
            }
            columna++;
        }
        fila++;
        columna = fila;
    }

    if (esSimetria)
    {
        puts("LA MATRIZ, ES UNA MATRIZ SIMETRICA");
    }
    else
    {
        puts("LA MATRIZ, NO ES UNA MATRIZ SIMETRICA");
    }

    return esSimetria;
}

/// TRASPONER MATRIZ insitu
int transponerMatriz(int matriz[][TAM])
{
    int fila, columna, aux;

    for (fila = 0; fila < TAM; fila++)
    {
        for (columna = (fila + 1); columna < TAM; columna++)
        {
            aux = matriz[columna][fila];
            matriz[columna][fila] = matriz[fila][columna];
            matriz[fila][columna] = aux;
        }
    }

    puts("MATRIZ TRANSPUESTA: ");
    imprimirMatriz(matriz);

    return 1;
}

/// MULTIPLICACION DE MATRICES CUADRADAS
int multiplicarMatrices(int matriz1[][TAM], int matriz2[][TAM])
{
    int fila, columna;

    for (fila=0; fila < TAM; fila++)
    {
        for(columna=0; columna < TAM; columna++)
        {
            matriz1[fila][columna] *= matriz2[fila][columna];
        }
    }

    puts("RESULTADO:");
    imprimirMatriz(matriz1);

    return 1;
}

/// TRIANGULAR IDA Y VUELTA

// aux
int cantidadDePuntosQueLeCorresponden(int puntos)
{
    /// teniendo en cuenta que es IDA y VUELTA, estos son los posibles pts para cada equipo
    switch(puntos)
    {
        case 0: return 6;
        case 2: return 2;
        case 4: return 1;
        case 6: return 0;
        case 3: return 3;
        default: return -1;
    }


}

int laMatrizEsCorrecta(int matriz[][TAM])
{
    int fila = 0, columna = 1, esCorrecta = 1;

    /// Lo primero que hay que verificar es que la diagonal principal sean todos 0
    while (fila < TAM && esCorrecta)
    {
        if (matriz[fila][fila] != 0)
        {
            esCorrecta = 0;
        }
        fila++;
    }

    if (!esCorrecta) return esCorrecta;

    /// Ahora tenes que verificar que los puntos este bien distribuidos

    fila = 0;

    while(fila < TAM && esCorrecta)
    {
        while(columna < TAM && esCorrecta)
        {
            if (cantidadDePuntosQueLeCorresponden(matriz[fila][columna]) != matriz[columna][fila])
            {
                esCorrecta = 0;
            }
            columna++;
        }
        fila++;
        columna = fila+1;
    }

    return esCorrecta;

}

int* cantidadDePuntosDelEquipo(int matriz[][TAM], int equipo)
{
    int columna;
    int* vec = (int*)malloc(sizeof(int) * TAM);

    for(columna = 0; columna < TAM; columna++)
    {
        *(vec+columna) = matriz[equipo][columna];
    }

    return vec;
}

/// MATRICES PICANTES

// Arriba
int sumatoriaArribaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int res = 0, fila, columna;

    for(fila=0; fila < ((TAM-1)/2); fila++)
    {
        for(columna=fila+1; columna < (TAM-fila-1); columna++)
        {
            res += matriz[fila][columna];
        }
    }

    printf("EL RESULTADO ES: %d\n", res);

    return res;
}



void mostrarElementosArribaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int fila, columna;

    for(fila=0; fila < ( (TAM - 1) /2); fila++)
    {
        for(columna=fila+1; columna < (TAM-fila-1); columna++)
        {
            printf("%*d",((columna+1)*5),matriz[fila][columna]);
        }
        printf("\n");
    }
}

// Derecha
int sumatoriaDerechaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int res = 0, fila, columna;

    for (fila = 1; fila < (TAM - 1); fila++)
    {
        for(columna = MAX(TAM-fila, fila+1); columna < TAM; columna++)
        {
            res += matriz[fila][columna];
        }
    }

    printf("RESULTADO: %d\n", res);

    return res;
}


void mostrarElementosDerechaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int fila, columna;

    for(fila=1; fila < columna; fila++)
    {
        for(columna=MAX(TAM-fila, fila+1); columna < TAM; columna++)
        {
            printf("%*d", (columna+1)*5, matriz[fila][columna]);
        }
        printf("\n");
    }
}

// Abajo
int sumatoriaAbajoDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int res=0, fila, columna;

    for(fila=(TAM/2)+1; fila < TAM; fila++)
    {
        for (columna=1; columna < fila; columna++)
        {
            res += matriz[fila][columna];
        }
    }

    printf("RESULTADO: %d\n", res);

    return res;
}

void mostrarElementosAbajoDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int fila, columna;

    for(fila=(TAM/2)+1; fila < TAM; fila++)
    {
        for(columna=1; columna < fila; columna++)
        {
            printf("%*d", (columna+1)*5, matriz[fila][columna]);
        }
        printf("\n");
    }
}

// Izquierda
int sumatoriaIzquierdaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int res=0, fila, columna;

    for(fila=1; fila < TAM; fila++)
    {
        for(columna=0; columna < MIN(fila, TAM-(fila+1)); columna++)
        {
            res += matriz[fila][columna];
        }
    }

    printf("RESULTADO: %d\n", res);

    return res;
}

void mostrarElementosIzquierdaDiagonalPrincipalYSecundaria(int matriz[][TAM])
{
    int fila, columna;

    for(fila=1; fila < TAM; fila++)
    {
        for(columna=0; columna < MIN(fila, TAM-(fila+1)); columna++)
        {
            printf("%*d", (columna+1)*5, matriz[fila][columna]);
        }
        printf("\n");
    }
}

/// Rotar Matriz

void rotarMatriz(int matriz[][TAM])
{
    int fila, columna;

    for(columna=TAM-1; columna >= 0; columna--)
    {
        for(fila=0; fila < TAM; fila++)
        {
            printf("%5d", matriz[fila][columna]);
        }
        printf("\n");
    }
}

/// Trasponer Matriz segun diagonal secundaria
void trasponer_matriz_segund_diag_sec(int matriz[][TAM])
{
    int fila, columna, aux;

    for(fila=0; fila < (TAM - 1); fila++)
    {
        for(columna=0; columna < (TAM - fila - 1); columna++)
        {
            aux = matriz[fila][columna];
            matriz[fila][columna] = matriz[TAM-columna-1][TAM-fila-1];
            matriz[TAM-columna-1][TAM-fila-1] = aux;
        }
    }
}

//
//int* crear_matriz(int orden)
//{
//    int* matriz = (int*)malloc(orden*orden);
//
//    for (int i =0; i < orden*orden; i++)
//    {
//        *(matriz+i) = i*2;
//    }
//
//    return matriz;
//}
//
//void liberar_matriz(int orde, int* matriz)
//{
//    free(matriz);
//}
