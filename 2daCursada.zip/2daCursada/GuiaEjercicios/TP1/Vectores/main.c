#include "ejercicios.h"

int main()
{
    char cad[10] = "Facundo";
    int res = strTOint(cad);
    printf("%s vale %d\n", cad, res);
    return 0;
}
