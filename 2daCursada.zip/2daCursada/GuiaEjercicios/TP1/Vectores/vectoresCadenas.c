#include "ejercicios.h"

// Funciones Auxiliares
void imprimirVector(int* vec, int cantElem)
{
    printf("[ ");
    for (int i = 0; i < cantElem; i++) printf("%d ", *(vec + i));
    printf("]\n");
}

int strlen_alu(char* cad)
{
    char* aux = cad;
    int cantElem = 0;

    while(*aux != '\0')
    {
        cantElem++;
        aux++;
    }

    return cantElem;
}



int main22al26()
{
    int vec[13] = {3,3,3,3, 5, 7, 10, 11, 14, 16, 18, 20, 23};
    imprimirVector(vec, 13);
    int eliminados = eliminarINTdeVecPorCompleto(vec, 13, 3);
    imprimirVector(vec, 13 - eliminados);
    return 0;
}

// Ejercicio 22
int insertarINTen(int* vecInt, int pos, int elem)
{
    // Nos posicionamos en el elemento a agregar/reemplazar
    vecInt += pos;
    // Lo reemplazamos
    *vecInt = elem;

    return 0;
}

// Ejercicio 23 (ASC = Menor a Mayor)
int insertarINTenVecOrdAsc(int* vecInt, int cantElem, int elem)
{
    int aux = 0;
    for(int i = 0; i < cantElem; i++)
    {
        if(elem < *(vecInt + i))
        {
            aux = *(vecInt + i);
            *(vecInt + i) = elem;
            elem = aux;
        }
    }

    return 0;
}

// Ejercicio 24
int eliminarPosdeVec(int* vecInt, int cantElem, int posElem)
{
    int aux = 0;
    for (int i = 0; i < cantElem; i++)
    {
        if (i >= posElem)
        {
            aux = *(vecInt + i + 1);
            *(vecInt + i + 1) = *(vecInt + i);
            *(vecInt + i) = aux;
        }
    }

    return 0;
}

// Ejercicio 25
int eliminarINTdeVec(int* vecInt, int cantElem, int elem)
{
    int aux = 0;
    int encontrado = 0;
    for (int i = 0; i < cantElem; i++)
    {
        if (elem == *(vecInt + i) || encontrado)
        {
            encontrado = 1;
            aux = *(vecInt + i + 1);
            *(vecInt + i + 1) = *(vecInt + i);
            *(vecInt + i) = aux;
        }
    }

    return 0;
}

// Ejercicio 26
int eliminarINTdeVecPorCompleto(int* vecInt, int cantElem, int elem)
{
    int encontrados = 0;

    for(int i = 0; i < cantElem; i++)
    {
        if (elem == *(vecInt + i)) encontrados++;
    }

    for (int i = 0; i <= encontrados; i++)
        eliminarINTdeVec(vecInt, cantElem - i, elem);

    return encontrados;
}

// Ejercicio 27
int esPalindromo(char* cad)
{
    char* auxIZQ = cad;
    char* auxDER = cad;
    auxDER += strlen_alu(cad) - 1;

    while(toUppercase(*auxIZQ) == toUppercase(*auxDER) && auxDER != auxIZQ)
    {
        printf("%c == %c\n", *auxIZQ, *auxDER);
        auxDER--;
        auxIZQ++;
    }

    if (auxDER == auxIZQ) return 1;

    return 0;
}

// Ejercicio 28
int strTOint(char* cad)
{
    int res = 0;

    while(*cad != '\0')
    {
        res += (int)*cad;
        cad++;
    }

    return res;
}
