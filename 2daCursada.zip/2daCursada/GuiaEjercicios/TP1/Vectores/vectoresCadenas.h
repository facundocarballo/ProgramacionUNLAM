#ifndef EJERCICIOS_H_INCLUDED
#define EJERCICIOS_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

// Ejercicio 21
#define truncFloat(numReal) (int)(numReal)
#define toUppercase(a) ((a >= 65 && a <= 90) ? a : (a - ('a' - 'A')))

// Funciones Auxiliares
void imprimirVector(int* vec, int cantElem);
int strlen_alu(char* cad);

// Ejercicio 22
int insertarINTen(int* vecInt, int pos, int elem);
// Ejercicio 23
int insertarINTenVecOrdAsc(int* vecInt, int cantElem, int elem);
// Ejercicio 24
int eliminarPosdeVec(int* vecInt, int cantElem, int posElem);
// Ejercicio 25
int eliminarINTdeVec(int* vecInt, int cantElem, int elem);
// Ejercicio 26
int eliminarINTdeVecPorCompleto(int* vecInt, int cantElem, int elem);
// Ejercicio 27
int esPalindromo(char* cad);
// Ejercicio 28
int strTOint(char* cad);

#endif // EJERCICIOS_H_INCLUDED
