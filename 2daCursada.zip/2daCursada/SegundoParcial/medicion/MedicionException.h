#ifndef MEDICIONEXCEPTION_H_INCLUDED
#define MEDICIONEXCEPTION_H_INCLUDED

#include <iostream>
#include <stdlib.h>
using namespace std;

class MedicionException
{
private:
	string mensaje;

public:
	MedicionException(const string& msj);
	const string& getMensaje() const;
};

#endif // MEDICIONEXCEPTION_H_INCLUDED
