#include <iostream>
#include <stdlib.h>
#include "Medicion.h"
#include "MedicionException.h"

using namespace std;

int main()
{
    Medicion m1mv(100.0,"Mv");
    Medicion m2mv(20.0,"Mv");
    Medicion m4amp(3.0,"Amp");
    Medicion m3mv=m1mv-m2mv;
    //count<<"Resultado 1:"<<180.0+m3mv<<endl; NO ES COUNT
    cout<<"Resultado 1:"<<180.0+m3mv<<endl;

    try {
        cout <<m3mv-m4amp<<endl;
    }catch(MedicionException& MedicionException){
        cout <<"No se pueden restar mediciones de distinta unidad de medida"<<endl;
    }
}
