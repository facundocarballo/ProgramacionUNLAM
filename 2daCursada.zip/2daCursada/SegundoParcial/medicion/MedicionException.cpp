#include "MedicionException.h"

MedicionException::MedicionException(const string& msj)
{
	this->mensaje = msj;
}


const string& MedicionException::getMensaje() const
{
	return this->mensaje;
}
