#include "Medicion.h"

Medicion::Medicion()
{
    this->med=0;
    this->unidad="Nada";
}

Medicion::Medicion(float _med, const char *_unidad)
{
    this->med=_med;
    this->unidad = new char[strlen(_unidad) + 1];
	strcpy(this->unidad, _unidad);
}

Medicion Medicion::operator- (const Medicion &m) const
{
    Medicion aux;
    //strcpy(aux.unidad, m.unidad);
    aux.med=med-m.med;
    return aux;
}

Medicion operator+ (float num, const Medicion& m )
{
    Medicion aux;
    //strcpy(aux.unidad, m.unidad);
    aux.med=m.med+num;
    return aux;
}
 ostream& operator << (ostream& output, const Medicion &obj)
 {
     output << obj.med;

     return output;
 }
