#ifndef MEDICION_H_INCLUDED
#define MEDICION_H_INCLUDED

#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

class Medicion {

    protected:
        float med;
        char *unidad;
    public:
        Medicion();
        Medicion(float med, const char *unidad);
        Medicion operator- (const Medicion &m) const;
        friend Medicion operator+ (float num, const Medicion& med );
        friend ostream& operator<<(ostream&, const Medicion&);



};



#endif // MEDICION_H_INCLUDED
