#include "HoraDelDia.h"

/// Metodos privados
bool HoraDelDia::esHoraValida(int _h, int _m, int _s)const
{
    if (_h < 24 && _h >= 0 && _m < 60 && _m >= 0 && _s < 60 && _s >= 0)
        return true;
    return false;
}

HoraDelDia HoraDelDia::obtenerHoraDesdeSegundos(int _s)const
{
    int horas = 0, minutos = 0, segundos = _s;


    if ((_s / 60) > 0)
    {
        segundos = _s % 60;
        minutos = _s / 60;
    }

    if ((minutos / 60) > 0)
    {
        horas = minutos / 60;
        minutos = minutos % 60;
    }

    return HoraDelDia(horas, minutos, segundos);
}

HoraDelDia HoraDelDia::sumarHorasDelDia(const HoraDelDia& obj)const
{
    int _h, _m, _s, mayor, menor, fS = 0, fM = 0;

    /// Calculamos los segundos
    if ((s + obj.s) < 60)
    {
        _s = s + obj.s;
    }
    else
    {
        mayor = MAX(s, obj.s);
        menor = MIN(s, obj.s);

        _s = menor - (60 - mayor);

        fS = 1;
    }

    /// Calculamos los minutos
    if ((m + obj.m + fS) < 60)
    {
        _m = m + obj.m + fS;
    }
    else
    {
        mayor = MAX(m, obj.m);
        menor = MIN(m, obj.m);

        _m = menor - (60 - mayor) + fS;

        fM = 1;
    }

    /// Calculamos las horas
    if ((h + obj.h + fM) < 24)
    {
        _h = h + obj.h;
    }
    else
    {
        mayor = MAX(h, obj.h);
        menor = MIN(h, obj.h);

        _h = menor - (24 - mayor) + fM;
    }

    return HoraDelDia(_h, _m, _s);
}

HoraDelDia HoraDelDia::agregarSegundos(int _s)const
{
    HoraDelDia n = obtenerHoraDesdeSegundos(_s);

    return sumarHorasDelDia(n);
}

/// Constructor
HoraDelDia::HoraDelDia(int _h, int _m, int _s)
{
    if (esHoraValida(_h, _m, _s))
    {
        h = _h;
        m = _m;
        s = _s;
    }
    else
    {
        h = 0;
        m = 0;
        s = 0;
    }
}


/// Metodos
HoraDelDia HoraDelDia::getHoraMaxima()
{
    return HoraDelDia(23,59,59);
}

/// Operadores
bool HoraDelDia::operator!=(const HoraDelDia& obj)const
{
    if (h != obj.h) return true;

    if (m != obj.m) return true;

    if (s != obj.s) return true;

    return false;
}

HoraDelDia HoraDelDia::operator+(const HoraDelDia& obj)const
{
    return sumarHorasDelDia(obj);
}

HoraDelDia HoraDelDia::operator++(int)
{
    HoraDelDia n(h, m, s);

    HoraDelDia nn = agregarSegundos(1);

    h = nn.h;
    m = nn.m;
    s = nn.s;

    return n;
}


HoraDelDia& HoraDelDia::operator=(const HoraDelDia& obj)
{
    h = obj.h;
    m = obj.m;
    s = obj.s;
    return *this;
}

HoraDelDia& HoraDelDia::operator+=(int _s)
{
    HoraDelDia n = agregarSegundos(_s);

    HoraDelDia nn = sumarHorasDelDia(n);

    h = nn.h;

    m = nn.m;

    s = nn.s;

    return *this;
}

/// Friends
istream& operator>>(istream& ent, HoraDelDia& obj)
{
    cout << "Ingresa la hora: ";
    ent >> obj.h;

    cout << "Ingresa los minutos: ";
    ent >> obj.m;

    cout << "Ingresa los segundos: ";
    ent >> obj.s;

    return ent;
}

ostream& operator<<(ostream& sal, const HoraDelDia& obj)
{
    sal << obj.h << ":" << obj.m << ":" << obj.s << endl;
    return sal;
}

HoraDelDia operator+(const int _s, const HoraDelDia& obj)
{
    HoraDelDia n(obj.h, obj.m, obj.s);

    n.agregarSegundos(_s);

    return n;
}
