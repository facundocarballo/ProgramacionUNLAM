#ifndef HORADELDIA_H_INCLUDED
#define HORADELDIA_H_INCLUDED

#include <iostream>

#define MAX(x,y)(x>y?x:y)
#define MIN(x,y)(x<y?x:y)


using namespace std;

class HoraDelDia
{
private:
    int h, m, s;
    /// Metodos privados
    bool esHoraValida(int _h, int _m, int _s)const;
    HoraDelDia obtenerHoraDesdeSegundos(int _s)const;
    HoraDelDia sumarHorasDelDia(const HoraDelDia& obj)const;
    HoraDelDia agregarSegundos(int _s)const;
public:
    /// Constructores
    HoraDelDia(int _h = 0, int _m = 0, int _s = 0);
    /// Destructor

    /// Metodos
    static HoraDelDia getHoraMaxima();
    /// Operadores
    bool operator!=(const HoraDelDia& obj)const;
    HoraDelDia operator+(const HoraDelDia& obj)const;
    HoraDelDia operator++(int); // post incremento
    HoraDelDia& operator=(const HoraDelDia& obj);
    HoraDelDia& operator+=(int _s);
    /// Friends
    friend istream& operator>>(istream& ent, HoraDelDia& obj);
    friend ostream& operator<<(ostream& sal, const HoraDelDia& obj);
    friend HoraDelDia operator+(int _s, const HoraDelDia& obj);

};


#endif // HORADELDIA_H_INCLUDED
