#include <tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <arbol.h>
#include "../include/utilitarias.h"

void crearArbolBinBusq(tArbolBinBusq* p)
{
    *p = NULL;
}

int cargarArchivoBinOrdenadoArbolBinBusq(tArbolBinBusq* p, const char* path, unsigned tamInfo)
{
    FILE* arch;
    int cantReg, r;

    if (!(arch = fopen(path, "rb"))) return ERROR_ARCHIVO;

    fseek(arch, 0L, SEEK_END);
    cantReg = ftell(arch) / tamInfo;

    r = cargarDesdeDatosOrdenadosArbolBinBusqRec(p, arch, 0, cantReg-1, &tamInfo, leer_archivo_indice);

    fclose(arch);

    return r;
}

int cargarDesdeDatosOrdenadosArbolBinBusqRec(tArbolBinBusq* p, void* ds, int li, int ls, void* params,
                                             unsigned(*leer)(void**, void*, unsigned, void*))
{
    int m, r;

    if (li > ls) return TODO_OK;

    m = (li + ls)/2;

    /// Reservamos memoria para el nodo
    (*p) = (tNodoArbol*)malloc(sizeof(tNodoArbol));
    if (!*p || !((*p)->tamInfo = leer(&(*p)->info, ds, m, params)))
    {
        free(*p);
        return SIN_MEM;
    }

    /// Armamos el nodo
    (*p)->der = (*p)->izq = NULL;

    if ((r = cargarDesdeDatosOrdenadosArbolBinBusqRec(&(*p)->izq, ds, li, m-1, params, leer)) != TODO_OK)
        return r;

    return cargarDesdeDatosOrdenadosArbolBinBusqRec(&(*p)->der, ds, m+1, ls, params, leer);

}

int insertarRecArbolBinBusq(tArbolBinBusq *p, const void *d, unsigned tam,
                            int (*cmp)(const void*, const void *))
{
    tNodoArbol* nue;
    int rc;

    if (*p)
    {
        /// Si el arbol no esta vacio, lo tengo que recorrer para encontrar la posicion donde insertarlo
        if ((rc = cmp(d, (*p)->info)) > 0)
            return insertarRecArbolBinBusq(&(*p)->der, d, tam, cmp);

        if (rc < 0)
            return insertarRecArbolBinBusq(&(*p)->izq, d, tam, cmp);

        return DUPLICADO;
    }

    /// Reservamos memoria para el nodo
    nue = (tNodoArbol*)malloc(sizeof(tNodoArbol));
    if (!nue || !(nue->info = malloc(tam)))
    {
        free(nue);
        return SIN_MEM;
    }

    /// Armamos el nodo
    nue->der = nue->izq = NULL;
    nue->tamInfo = tam;
    memcpy(nue->info, d, tam);

    *p = nue;

    return TODO_OK;
}

int grabarEnArchivoOrdenadoArbolBin(tArbolBinBusq *p, const char * path)
{
    FILE* fp;

    if (!(fp = fopen(path, "wb"))) return ERROR_ARCHIVO;

    recorrerEnOrdenArbolBinBusq(p, fp, 0, accion_escribir_archivo_indice);

    fclose(fp);

    return TODO_OK;
}

void recorrerEnOrdenArbolBinBusq(const tArbolBinBusq * p, void * params, unsigned n,
                                 void (*accion)(void *, unsigned, unsigned, void *))
{
    if (!*p) return;

    recorrerEnOrdenArbolBinBusq(&(*p)->izq, params, n+1, accion);
    accion((*p)->info, (*p)->tamInfo, n, params); /// Ese 0 en realidad tiene que ser el nivel en donde esta el arbol...
    recorrerEnOrdenArbolBinBusq(&(*p)->der, params, n+1, accion);
}

void recorrerEnOrdenInversoArbolBinBusq(const tArbolBinBusq* p, void* params, unsigned n,
                                        void (*accion)(void*, unsigned, unsigned, void*))
{
    if (!*p) return;

    recorrerEnOrdenInversoArbolBinBusq(&(*p)->der, params, n+1, accion);
    accion((*p)->info, (*p)->tamInfo, n, params);
    recorrerEnOrdenInversoArbolBinBusq(&(*p)->izq, params, n+1, accion);
}

void arbolGrafico(const tArbolBinBusq* pa, void (*mostar)(void *, unsigned, unsigned, void *))
{
    unsigned tamInfo = sizeof(tRegInd);
    recorrerEnOrdenInversoArbolBinBusq(pa, &tamInfo, 0, mostar);
}

void vaciarArbolBin(tArbolBinBusq *p)
{
    if (!*p) return; /// Arbol vacio

    /// Liberamos la memoria de ese nodo
    free((*p)->info);
    free(*p);

    /// Recorremos el arbol en forma recursiva
    vaciarArbolBin(&(*p)->izq);
    vaciarArbolBin(&(*p)->der);

    *p = NULL;
}

int buscarElemArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                             int (*cmp)(const void *, const void *))
{
    int r;

    if (!*p) return NO_EXISTE;

    if ((r = cmp(d, (*p)->info)) > 0)
        return buscarElemArbolBinBusq(&(*p)->der, d, tam, cmp);

    if (r < 0) return buscarElemArbolBinBusq(&(*p)->izq, d, tam, cmp);

    /// Si llegamos hasta aca, es que existe el elemento

    memcpy(d, (*p)->info, MIN(tam, (*p)->tamInfo));

    return TODO_OK;

}

tNodoArbol** mayorNodoArbolBin(tArbolBinBusq* p)
{
    if (!*p) return NULL;

    while((*p)->der) p = &(*p)->der;

    return p;
}

tNodoArbol** menorNodoArbolBin(tArbolBinBusq* p)
{
    if (!*p) return NULL;

    while((*p)->izq) p = &(*p)->izq;

    return p;
}

const tArbolBinBusq* mayorNodoNoClaveArbolBinBusq(const tArbolBinBusq* p, const tArbolBinBusq* mayor,
                                          int(*cmp)(const void*, const void*))
{
    if (!*p) return mayor;

    if (cmp((*p)->info, (*mayor)->info) > 0)
        mayor = p;

    mayor = mayorNodoNoClaveArbolBinBusq(&(*p)->izq, mayor, cmp);
    mayor = mayorNodoNoClaveArbolBinBusq(&(*p)->der, mayor, cmp);

    return mayor;
}

int mayorElemNoClaveArbolBinBusq(const tArbolBinBusq *p, void *d, unsigned tam,
                                 int (*cmp)(const void *, const void *))
{
    const tArbolBinBusq* mayor = p;

    if (!*p) return NO_EXISTE;

    mayor = mayorNodoNoClaveArbolBinBusq(&(*p)->izq, mayor, cmp);
    mayor = mayorNodoNoClaveArbolBinBusq(&(*p)->der, mayor, cmp);

    /// Copiamos la info del mayor nodo no clave dentro de d
    memcpy(d, (*mayor)->info, MIN(tam, (*mayor)->tamInfo));

    return TODO_OK;
}


unsigned alturaArbolBin(const tArbolBinBusq* p)
{
    int hi, hd;

    if (!*p) return 0;

    hi = alturaArbolBin(&(*p)->izq);
    hd = alturaArbolBin(&(*p)->der);

    return MAX(hi, hd) + 1;
}

int eliminarRaizArbolBinBusq(tArbolBinBusq* p)
{
    tNodoArbol *elim, **remp;

    if (!*p) return NO_EXISTE;

    free((*p)->info);

    if (!(*p)->der && !(*p)->izq)
    {
        free(*p);
        *p = NULL;
        return TODO_OK;
    }


    remp = alturaArbolBin(&(*p)->izq) > alturaArbolBin(&(*p)->der) ?
                mayorNodoArbolBin(&(*p)->izq) : menorNodoArbolBin(&(*p)->der);

    elim = *remp;

    (*p)->info = elim->info;
    (*p)->tamInfo = elim->tamInfo;

    *remp = elim->der ? elim->der : elim->izq;

    free(elim);

    return TODO_OK;
}


int eliminarElemArbolBinBusq(tArbolBinBusq *p, void *d, unsigned tam,
                             int (*cmp)(const void *, const void *))
{
    int r;

    if (!*p) return NO_EXISTE;

    if ((r = cmp(d, (*p)->info)) > 0)
        return eliminarElemArbolBinBusq(&(*p)->der, d, tam, cmp);

    if (r < 0)
        return eliminarElemArbolBinBusq(&(*p)->izq, d, tam, cmp);

    /// Copiamos memoria al dato del usuario
    memcpy(d, (*p)->info, MIN(tam, (*p)->tamInfo));

    eliminarRaizArbolBinBusq(p);

    return TODO_OK;

}
