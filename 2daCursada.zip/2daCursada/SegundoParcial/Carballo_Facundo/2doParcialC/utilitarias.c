#include<utilitarias.h>
#include<string.h>
#include<varias.h>

void ingresar_alumno(tAlumno* alu)
{
    printf("Ingrese el DNI: ");
    fflush(stdin);
    scanf("%d", &alu->dni);

    printf("Ingrese Apellido y Nombre: ");
    fflush(stdin);
    gets(alu->apyn);

    printf("Ingrese la cantidad de materias: ");
    fflush(stdin);
    scanf("%d", &alu->cant_materias);

    printf("Ingrese el promedio: ");
    fflush(stdin);
    scanf("%f", &alu->promedio);

    alu->estado = 'A';

}


void ingresar_dni_alumno(tAlumno* alu)
{
    printf("Ingrese el DNI: ");
    fflush(stdin);
    scanf("%d", &alu->dni);
}

int baja(tAlumno* alu, FILE* arch, tArbolBinBusq* pa)
{
    tRegInd indice;
    indice.dni = alu->dni;

    /// Tenemos que encontrar y eliminar el nodo dentro del arbol
    //if(!buscarElemArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_dni))
        //return NO_EXISTE;

    if(!eliminarElemArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_dni))
        return NO_EXISTE;

    /// Con el indice encontrado, leemos directamente del archivo alumnos.dat el alumno
    fseek(arch, (long)indice.nro_reg*sizeof(tAlumno), SEEK_SET);
    fread(alu, sizeof(tAlumno), 1, arch);

    /// Actualizamos su estado a 'B'
    alu->estado = 'B';

    /// Reescribimos el archivo con el alumno modificado
    fseek(arch, (long)indice.nro_reg*sizeof(tAlumno), SEEK_SET);
    fwrite(alu, sizeof(tAlumno), 1, arch);

    return TODO_OK;
}

int alta (tAlumno * alu, FILE * arch, tArbolBinBusq* pa)
{
    int nroReg;
    unsigned tamInfo;
    tRegInd indice;

    /// Armamos el indice
    tamInfo = sizeof(tAlumno);

    fseek(arch, 0L, SEEK_END);
    nroReg = ftell(arch) / tamInfo;

    indice.dni = alu->dni;
    indice.nro_reg = nroReg;

    /// Escribir el alumno en el archivo alumnos.dat
    fwrite(alu, tamInfo, 1, arch);

    /// Agregar el alumno (indice) en el arbol
    return insertarRecArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_dni);
}


int agregar_materia(FILE* arch, tArbolBinBusq* pa)
{
    tRegInd indice;
    tAlumno alu;
    int nuevaNota;
    float sumaNotas;

    printf("Ingrese el DNI: ");
    fflush(stdin);
    scanf("%d", &indice.dni);

    /// Obtenemos el nroReg del arbol
    if (!buscarElemArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_dni))
        return NO_EXISTE;

    /// Leemos el alumno del archivo "alumnos.dat"
    fseek(arch, (long)indice.nro_reg*sizeof(tAlumno), SEEK_SET);
    fread(&alu, sizeof(tAlumno),1, arch);

    /// Mostramos por pantalla el alumnno
    mostrar_alumno(&alu);

    /// Le pedimos que ingrese la nueva nota
    printf("Ingrese la nueva nota: ");
    fflush(stdin);
    scanf("%d", &nuevaNota);

    /// Obtenemos la suma de todas las notas anteriores
    sumaNotas = alu.cant_materias * alu.promedio;

    /// Sumamos a eso la nota actual
    sumaNotas += nuevaNota;

    /// Actualizamos la cant. materias
    alu.cant_materias++;

    /// Sacamos el nuevo promedio
    alu.promedio = sumaNotas / alu.cant_materias;

    /// Mostramos el alumno actualizado
    mostrar_alumno(&alu);

    /// Reescribimos el alumno en el archivo "alumnos.dat"
    fseek(arch, (long)indice.nro_reg*sizeof(tAlumno), SEEK_SET);
    fwrite(&alu, sizeof(tAlumno), 1, arch);

    return TODO_OK;

}


void imprimir_archivo(FILE* arch)
{
    tAlumno alu;

    fseek(arch, 0L, SEEK_SET);
    fread(&alu, sizeof(tAlumno), 1, arch);

    while(!feof(arch))
    {
        mostrar_alumno(&alu);
        fread(&alu, sizeof(tAlumno), 1, arch);
    }

}

void imprimir_archivo_ordenado(FILE* arch, tArbolBinBusq* pa)
{
    recorrerEnOrdenArbolBinBusq(pa, arch, 0, leer_mostrar_alumno);
}

int baja_ultimo(FILE * arch, tArbolBinBusq* pa)
{
    tRegInd indice;
    tAlumno alu;

    /// Buscar el registro mas alto dentro del arbol
    if (!mayorElemNoClaveArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_nro_reg))
        return NO_EXISTE;

    eliminarElemArbolBinBusq(pa, &indice, sizeof(tRegInd), comparar_dni);

    /// Leer el ultimo registro ingresado
    fseek(arch, (long)sizeof(tAlumno)*indice.nro_reg, SEEK_SET);
    fread(&alu, sizeof(tAlumno), 1, arch);

    /// Actualizar el estado a 'B'
    alu.estado = 'B';

    printf("Eliminado:\n");
    mostrar_alumno(&alu);

    /// Reescribimos el alumno con su nuevo estado
    fseek(arch, (long)sizeof(tAlumno)*indice.nro_reg, SEEK_SET);
    fwrite(&alu, sizeof(tAlumno), 1, arch);

    return TODO_OK;
}

int compactar_y_reindexar(FILE ** arch, tArbolBinBusq * pindice, const char * path)
{
    /// Abrimos el archivo indice en modo escritura
    if (!(*arch = fopen(path, "wb"))) return ERROR_ARCHIVO;

    recorrerEnOrdenArbolBinBusq(pindice, *arch, 0, accion_escribir_archivo_indice);

    fclose(*arch);

    return TODO_OK;
}

/// Funciones de mostrar
void mostrar_alumno(tAlumno* alu)
{
    printf("DNI: %d\nApellido y Nombre: %s\nMaterias: %d \t Promedio: %5.2f\nEstado: %c\n", alu->dni, alu->apyn, alu->cant_materias, alu->promedio, alu->estado);
}

/// Funciones de comparacion
int comparar_dni(const void* a, const void* b)
{
    tRegInd* indA = (tRegInd*)a;
    tRegInd* indB = (tRegInd*)b;


    return indA->dni - indB->dni;
}

int comparar_nro_reg(const void* a, const void* b)
{
    tRegInd* indA = (tRegInd*)a;
    tRegInd* indB = (tRegInd*)b;

    return indA->nro_reg - indB->nro_reg;
}

/// Funciones de acciones
void accion_escribir_archivo_indice(void* info, unsigned tamInfo, unsigned n, void* params)
{
    fwrite(info, tamInfo, 1, (FILE*)params);
}

void mostrar_arbol(void* info, unsigned tamInfo, unsigned n, void* params)
{
    tRegInd* indice = (tRegInd*)info;
    printf("%*c%d\n", n*5, ' ', indice->dni);
}

void leer_mostrar_alumno(void* info, unsigned tamInfo, unsigned n, void* params)
{
    tAlumno alu;
    tRegInd* pIndice = (tRegInd*)info;

    /// Nos posicionamos en el archivo
    fseek((FILE*)params, (long)pIndice->nro_reg*sizeof(tAlumno), SEEK_SET);
    fread(&alu, sizeof(tAlumno), 1, (FILE*)params);

    mostrar_alumno(&alu);
}

/// Funciones de lectura
unsigned leer_archivo_indice(void** pInfo, void* pArch, unsigned pos, void* params)
{
    unsigned tamInfo = *((unsigned*)params);

    /// Reservamos memoria para la info
    *pInfo = malloc(tamInfo);
    if (!*pInfo) return 0;

    /// Nos posicionamos dentro del archivo para leer
    fseek((FILE*)pArch, (long)pos*tamInfo, SEEK_SET);

    return fread(*pInfo, tamInfo, 1, (FILE*)pArch);
}
