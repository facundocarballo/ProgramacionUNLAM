#include "lista.h"

int main()
{
    t_lista lista;
    crear_lista(&lista);

    char nombre1[] = {"Facundo"};
    char nombre2[] = {"Victor"};
    char nombre3[] = {"Rodrigo"};
    char nombre4[] = {"Nicolas"};
    char nombre5[] = {"Santiago"};

    poner_al_comienzo(&lista, nombre1, sizeof(nombre1));
    poner_al_comienzo(&lista, nombre2, sizeof(nombre2));
    poner_al_final(&lista, nombre3, sizeof(nombre3));
    poner_al_comienzo(&lista, nombre4, sizeof(nombre4));
    poner_al_comienzo(&lista, nombre5, sizeof(nombre5));

    imprimir_lista(&lista);

    return 0;
}
