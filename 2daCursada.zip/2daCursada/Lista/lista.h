#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#define TODO_OK 0
#define SIN_MEM 1

#define MIN(x,y) (x < y ? x : y)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct s_nodo {
    void* info;
    unsigned tamInfo;
    struct s_nodo* sig;
} t_nodo;

typedef t_nodo* t_lista;

/// Auxs
void imprimir_lista(t_lista* pl);

/// Primitivas
void crear_lista(t_lista* pl);
void vaciar_lista(t_lista* pl);
int lista_vacia(const t_lista* pl);
int lista_llena(const t_lista* pl, unsigned tamInfo);
int poner_al_comienzo(t_lista* pl, const void* info, unsigned tamInfo);
int sacar_primero(t_lista* pl, void* info, unsigned tamInfo);
int poner_al_final(t_lista* pl, const void* info, unsigned tamInfo);
int sacar_ultimo(t_lista* pl, void* info, unsigned tamInfo);
int ver_primero(const t_lista* pl, void* info, unsigned tamInfo);
int ver_ultimo(const t_lista* pl, void* info, unsigned tamInfo);

#endif // LISTA_H_INCLUDED
