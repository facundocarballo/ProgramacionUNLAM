#include "lista.h"



void crear_lista(t_lista* pl)
{
    *pl = NULL;
}

void vaciar_lista(t_lista* pl)
{
    t_nodo* aux;
    while(*pl) /// mientras la lista no este apuntando a un puntero NULL
    {
        /// Obtenemos el nodo a eliminar
        aux = *pl;

        /// Asignamos la lista al siguiente
        *pl = aux->sig;

        /// Liberamos memoria
        free(aux->info);
        free(aux);
    }
}

int lista_vacia(const t_lista* pl)
{
    return *pl == NULL;
}

int lista_llena(const t_lista* pl, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    void* nueInfo = malloc(tamInfo);

    free(nueInfo);
    free(nueNodo);

    return !nueInfo || !nueNodo;
}

int poner_al_comienzo(t_lista* pl, const void* info, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if (!nueNodo)
    {
        puts("LISTA LLENA");
        return 0;
    }

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        puts("LISTA LLENA");
        free(nueNodo);
        return 0;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->sig = *pl;

    /// La lista tiene que apuntar a este nuevo nodo
    *pl = nueNodo;

    return 1;
}

int sacar_primero(t_lista* pl, void* info, unsigned tamInfo)
{
    if(!*pl)
    {
        puts("LISTA VACIA");
        return 0;
    }

    /// Obtenemos el primer nodo
    t_nodo* aux = *pl;

    /// Copiar el dato al usuario
    memcpy(info, aux->info, MIN(tamInfo, aux->tamInfo));

    /// Reasignar la lista al siguiente del primer nodo
    *pl = aux->sig;

    /// Liberar la memoria
    free(aux->info);
    free(aux);

    return 1;
}

int poner_al_final(t_lista* pl, const void* info, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if(!nueNodo)
    {
        puts("LISTA LLENA");
        return 0;
    }

    nueNodo->info = malloc(tamInfo);
    if(!nueNodo->info)
    {
        puts("LISTA LLENA");
        free(nueNodo);
        return 1;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->tamInfo = tamInfo;
    nueNodo->sig = NULL;

    /// Recorrer la lista hasta el final
    t_nodo* aux = *pl;
    while(aux->sig)
    {
        aux = aux->sig;
    }

    /// Asignamos al ultimo de la lista el nuevo nodo
    aux->sig = nueNodo;

    return 1;
}

int sacar_ultimo(t_lista* pl, void* info, unsigned tamInfo)
{
    if (!*pl)
    {
        puts("LISTA VACIA");
        return 0;
    }

    /// Recorre la lista hasta el ante ultimo nodo
    t_nodo* aux = *pl;
    while(aux->sig->sig)
    {
        aux = aux->sig;
    }
    /// Se obtiene el dato del ultimo nodo
    memcpy(info, aux->sig->info, MIN(tamInfo, aux->sig->tamInfo));

    /// Se libera memoria
    free(aux->sig->info);
    free(aux->sig);

    /// Se actualiza el ultimo de lista
    aux->sig = NULL;

    return 1;
}

int ver_primero(const t_lista* pl, void* info, unsigned tamInfo)
{
    if (!*pl)
    {
        puts("LISTA VACIA");
        return 0;
    }

    /// Obtenemos el nodo a ver
    t_nodo* aux = *pl;

    /// Copiamos el dato
    memcpy(info, aux->info, MIN(aux->tamInfo, tamInfo));

    return 1;
}

int ver_ultimo(const t_lista* pl, void* info, unsigned tamInfo)
{
    if (!*pl)
    {
        puts("LISTA VACIA");
        return 0;
    }

    /// Recorre la lista hasta el ultimo nodo
    t_nodo* aux = *pl;
    while(aux->sig)
    {
        aux = aux->sig;
    }

    /// Copiamos el dato del ultimo nodo
    memcpy(info, aux->info, MIN(tamInfo, aux->tamInfo));

    return 1;
}

void imprimir_lista(t_lista* pl)
{
    /// Como sabemos que la lista es de cadena de caracteres, los datos a obtener son cadenas de caracteres
    t_nodo* aux = *pl;
    char* dato;
    while(aux)
    {
        /// Obtenemos el dato
        dato = (char*)aux->info;

        /// Imprimimos
        printf("%s\n", dato);
        if (aux->sig)
        {
            printf("|\n|\n|\n|\n|\nV\n");
        }


        /// Avanzamos
        aux = aux->sig;
    }
}
