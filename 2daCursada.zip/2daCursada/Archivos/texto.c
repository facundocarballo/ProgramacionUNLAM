#include "texto.h"


void imprimirArchivoTexto(char* nombreArchivo)
{
    FILE* fp = fopen(nombreArchivo, "rt");
    if (!fp)
    {
        puts("ERROR: Al abrir archivo de lectura de texto.");
        return;
    }
    char cadena[100];
    printf("IMPRIMIENDO ARCHIVO DE TEXTO....\n\n");
    while(fgets(cadena, sizeof(cadena), fp))
    {
        printf("%s\n", cadena);
    }

    fclose(fp);

    return;
}

void crearArchivoTexto(char* nombreArchivo, t_alumno* alumnos, int cantAlumnos)
{
    FILE* fp = fopen(nombreArchivo, "wt");
    if (!fp)
    {
        puts("ERROR: Abriendo el archivo de escritura de texto.");
        return;
    }
    for(int i = 0; i < cantAlumnos; i++)
    {
        t_alumno* aux = alumnos+i;
        fprintf(fp, "%d|%s|%s|%s|%d|%d\n", aux->dni, aux->nombre, aux->apellido, aux->carrera, aux->materiasAprobadas, aux->materiasDeLaCarrera);
    }

    fclose(fp);

}

/// aux
void cambiarExtension(char* nombreArchivo, char* ext)
{
    char* aux = nombreArchivo;
    char* auxExt = ext;

    printf("nombreArchivo: %s\n", aux);
    printf("Extension nueva: %s\n\n", auxExt);

    /// Recorremos la cadena hasta encontrar el '.'
    puts("Recorremos la cadena hasta encontrar el .");
    while(*(aux) != '.')
    {
        printf("%c", *aux);
        aux++;
    }
    aux++;

    printf("\n\naux queda apuntado a => (%c)\n", *aux);
    puts("CAMBIAMOS LA EXTENSION\n");
    /// Cambiamos la extension
    while(*(auxExt) != '\0')
    {
        printf("%c = %c\n\n", *aux, *auxExt);
        *aux = *auxExt;
        aux++;
        auxExt++;
    }

    *aux = '\0';

    printf("Nombre Archivo: %s\n", nombreArchivo);

    return;
}

int txtAbin(char* nombreArchivo)
{
    FILE* fpText = fopen(nombreArchivo, "rt");
    if (!fpText)
    {
        puts("ERROR: Abriendo el archivo de lectura de texto.");
        return 0;
    }
    FILE* fpBIN = fopen("txtAbin.dat", "wb");
    if (!fpBIN)
    {
        puts("ERROR: Abriendo el archivo de lectura de texto.");
        return 0;
    }


    t_alumno alumno;

    /// Obtienen los campos desde el archivo de texto
    int cantCamposLeidos =  fscanf(fpText, "%d|%[^|\n]|%[^|\n]|%[^|\n]|%d|%d\n",
                 &alumno.dni, alumno.nombre, alumno.apellido,
                 alumno.carrera, &alumno.materiasAprobadas, &alumno.materiasDeLaCarrera
                 );

    while(cantCamposLeidos == 6)
    {
        /// Escribir el archivo binario
        fwrite(&alumno, sizeof(alumno), 1, fpBIN);
        /// Obtienen los campos desde el archivo de texto
        cantCamposLeidos = fscanf(fpText, "%d|%[^|\n]|%[^|\n]|%[^|\n]|%d|%d\n",
                 &alumno.dni, alumno.nombre, alumno.apellido,
                 alumno.carrera, &alumno.materiasAprobadas, &alumno.materiasDeLaCarrera
                 );
    }

    fclose(fpBIN);
    fclose(fpText);

    return 1;
}


