#include "texto.h"
#include "binario.h"

int main()
{
    t_alumno alumnos[] = {
        {
            42774931,
            "Facundo",
            "Carballo",
            "Ing. Informatica",
            17,
            44
        },
        {
            43854369,
            "Victor",
            "Olivera",
            "Ing. Informatica",
            18,
            44
        },
        {
            42774896,
            "Leandro",
            "Caceres",
            "Derecho",
            5,
            40
        }
    };

    t_alumno alumnos2[] = {
        {
            43555855,
            "Santiago",
            "Pele",
            "Ing. Informatica",
            16,
            44
        },
        {
            42369789,
            "Nicolas",
            "Veliz",
            "Ing. Informatica",
            11,
            44
        },
        {
            35122745,
            "Ezequiel",
            "Blanco",
            "Ing. Informatica",
            17,
            44
        },
        {
            39587963,
            "Juan Pablo",
            "Correa",
            "Ing. Informatica",
            26,
            44
        }
    };

    /// Creacion de archivo de texto
    crearArchivoTexto("alumnos2.txt", alumnos2, 4);
    imprimirArchivoTexto("alumnos2.txt");

    puts("\n--------------------------------------------\n");

    /// Creacion de archivo binario
    crearArchivoBIN("alumnos.dat", &alumnos, sizeof(alumnos));
    imprimirArchivoBIN("alumnos.dat");


    puts("\n--------------------------------------------\n");


    puts("MERGE");

    juntarArchivosBIN("alumnos.dat", "alumnos2.txt");

    imprimirArchivoBIN("merge.dat");


    return 0;
}
