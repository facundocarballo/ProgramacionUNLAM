#ifndef TEXTO_H_INCLUDED
#define TEXTO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "alumno.h"

void imprimirArchivoTexto(char* nombreArchivo);
void crearArchivoTexto(char* nombreArchivo, t_alumno* alumnos, int cantAlumnos);
int txtAbin(char* nombreArchivo);

/// auxs
void cambiarExtension(char* nombreArchivo, char* ext);

#endif // TEXTO_H_INCLUDED
