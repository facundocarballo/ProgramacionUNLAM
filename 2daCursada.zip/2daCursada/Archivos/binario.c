#include "binario.h"
#include "texto.h"


void imprimirArchivoBIN(char* nombreArchivo)
{
    FILE* fp = fopen(nombreArchivo, "rb");
    if (!fp)
    {
        puts("ERROR: Abriendo archivo lectura binario.");
        return;
    }

    puts("IMPRIMIENDO ARCHIVO BINARIO.... \n");

    t_alumno alumno;
    fread(&alumno, sizeof(alumno), 1, fp);
    while(!feof(fp))
    {
        printf("DNI: %d\nNOMBRE: %s\nAPELLIDO: %s\nCARRERA: %s\nMATERIAS APROBADAS: %d\nMATERIAS DE LA CARRERA: %d\n\n",
               alumno.dni, alumno.nombre, alumno.apellido, alumno.carrera, alumno.materiasAprobadas, alumno.materiasDeLaCarrera);
        fread(&alumno, sizeof(alumno), 1, fp);
    }

    fclose(fp);

    return;
}


void crearArchivoBIN(char* nombreArchivo, void* info, unsigned tamInfo)
{
    FILE* fp = fopen(nombreArchivo, "wb");
    if (!fp)
    {
        puts("ERROR: Abriendo archivo escritura binario.");
        return;
    }

    fwrite(info, tamInfo, 1, fp);

    fclose(fp);

    return;
}

int binAtxt(char* nombreArchivo)
{
    FILE* fpBIN = fopen(nombreArchivo, "rb");
    FILE* fpText = fopen("binAtxt.txt", "wt");
    if (!fpBIN)
    {
        puts("ERROR: Al abrir archivo binario en modo lectura");
        return 0;
    }
    if(!fpText)
    {
        puts("ERROP: Al abrir archivo de texto en modo escritura");
        return 0;
    }

    t_alumno alumno;

    /// Leer del archivo binario
    fread(&alumno, sizeof(alumno), 1, fpBIN);

    while(!feof(fpBIN))
    {
        /// Escribir en el archivo de texto
        fprintf(fpText, "%d|%s|%s|%s|%d|%d\n", alumno.dni, alumno.nombre, alumno.apellido, alumno.carrera, alumno.materiasAprobadas, alumno.materiasDeLaCarrera);

        /// Leer del archivo binario
        fread(&alumno, sizeof(alumno), 1, fpBIN);
    }

    fclose(fpBIN);
    fclose(fpText);


    return 1;

}

int ordenarArchivoBIN(char* nombreArchivo)
{
    imprimirArchivoBIN(nombreArchivo);
    /// funciona pero para mi es de otra forma
    /// ordenamiento de menor a mayor (Ascendente)
    FILE* fp = fopen(nombreArchivo, "r+t");
    if (!fp)
    {
        puts("ERROR: Al abrir el archivo para odernar.");
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    int cantElem = ftell(fp) / sizeof(t_alumno);
    fseek(fp, 0, SEEK_SET);
    int i = 0;
    t_alumno alumnoMayor;
    t_alumno alumno;
    t_alumno aux;

    fread(&alumnoMayor, sizeof(t_alumno), 1, fp);

    while(cantElem > 1)
    {
        i = 0;
        while(i < (cantElem-1))
        {
            fread(&alumno, sizeof(t_alumno), 1, fp);
            printf("\n%s(%d) > %s(%d) ? \n", alumno.nombre, alumno.materiasAprobadas, alumnoMayor.nombre, alumnoMayor.materiasAprobadas);
            if(alumno.materiasAprobadas > alumnoMayor.materiasAprobadas)
            {
                printf("\nSI\n");
                aux = alumnoMayor;
                alumnoMayor = alumno;
                alumno = aux;
            }
            i++;
        }

        printf("\nSe escribe %s(%d) en [%d]\n", alumno.nombre, alumno.materiasAprobadas, cantElem-2);
        /// Escribimos el del final en donde hacemos el intercambio
        fseek(fp, (long)(cantElem-2) * (long)sizeof(t_alumno), SEEK_SET);
        fwrite(&alumno, sizeof(t_alumno), 1, fp);

        printf("\nSe escribe %s(%d) en [%d]\n", alumnoMayor.nombre, alumnoMayor.materiasAprobadas, cantElem-1);
        /// Escribimos el MAYOR al final
        fseek(fp, (long)(cantElem-1) * (long)sizeof(t_alumno), SEEK_SET);
        fwrite(&alumnoMayor, sizeof(t_alumno), 1, fp);

        /// Posicionamos devuelta el archivo al principio
        fseek(fp, 0, SEEK_SET);

        alumnoMayor = alumno;
        cantElem--;
    }

    fclose(fp);

    return 1;

}


int juntarArchivosBIN(char* nombreArchivoBIN, char* nombreArchivoText)
{
    /// Pasar el de texto a binario
    txtAbin(nombreArchivoText); /// esta funcion crea un archivo binario llamado "txtAbin.dat"

    FILE* fpBIN1, *fpBIN2, *fpMerge;
    fpBIN1 = fopen(nombreArchivoBIN, "rb");
    fpBIN2 = fopen("txtAbin.dat", "rb");
    fpMerge = fopen("merge.dat", "wb");
    if (!fpBIN1)
    {
        puts("ERROR: al abir archivo de lectura binaria");
        return 0;
    }
    if(!fpBIN2)
    {
        puts("ERROR: al abrir archivo de lectura binaria");
        return 0;
    }
    if(!fpMerge)
    {
        puts("ERROR: al abir archivo de escritura binaria");
        return 0;
    }

    t_alumno alumno1;
    t_alumno alumno2;
    /// Comparar uno con uno e ir agregando a otro archivo el resultado final

    fread(&alumno1, sizeof(t_alumno), 1, fpBIN1);
    fread(&alumno2, sizeof(t_alumno), 1, fpBIN2);

    while(!feof(fpBIN1) && !feof(fpBIN2))
    {
        if (alumno1.materiasAprobadas < alumno2.materiasAprobadas)
        {
            fwrite(&alumno1, sizeof(t_alumno), 1, fpMerge);
            fread(&alumno1, sizeof(t_alumno), 1, fpBIN1);
        }
        else
        {
            fwrite(&alumno2, sizeof(t_alumno), 1, fpMerge);
            fread(&alumno2, sizeof(t_alumno), 1, fpBIN2);
        }

    }

    /// Continuar agregando al archivo final, desde el archivo que sigue conteniendo datos
    while(!feof(fpBIN1))
    {
        fwrite(&alumno1, sizeof(t_alumno), 1, fpMerge);
        fread(&alumno1, sizeof(t_alumno), 1, fpBIN1);
    }

    while(!feof(fpBIN2))
    {
        fwrite(&alumno2, sizeof(t_alumno), 1, fpMerge);
        fread(&alumno2, sizeof(t_alumno), 1, fpBIN2);
    }

    /// Cerrar los archivos

    fclose(fpBIN1);
    fclose(fpBIN2);
    fclose(fpMerge);

    return 1;
}
