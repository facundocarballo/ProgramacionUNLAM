#ifndef ALUMNO_H_INCLUDED
#define ALUMNO_H_INCLUDED

typedef struct {
    unsigned int dni;
    char nombre[100];
    char apellido[100];
    char carrera[100];
    unsigned int materiasAprobadas;
    unsigned int materiasDeLaCarrera;
} t_alumno;

#endif // ALUMNO_H_INCLUDED
