#ifndef BINARIO_H_INCLUDED
#define BINARIO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "alumno.h"

void imprimirArchivoBIN(char* nombreArchivo);
void crearArchivoBIN(char* nombreArchivo, void* info, unsigned tamInfo);
int binAtxt(char* nombreArchivo);
int ordenarArchivoBIN(char* nombreArchivo);
int juntarArchivosBIN(char* nombreArchivoBIN, char* nombreArchivoText);

#endif // BINARIO_H_INCLUDED
