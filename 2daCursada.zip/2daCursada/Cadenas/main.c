#include <stdio.h>
#include <stdlib.h>
#include "cadena.h"

#include <string.h>

#define PARTE_ENTERA(x)((int)(x))
#define REDONDEAR(x)((int)(x+0.5))

#define LOG_INT(x)(printf("%d\n", x))

int main()
{
    char palabra1[] = {"El amor es magico magico y magico victor"};
    char palabra2[] = {"maGico"};
    float real = 15.4;

    const char* pRes = strstr_alu(palabra1, palabra2);

    printf("pRes (%p) = %s\n", pRes, pRes);

    printf("%d\n", PARTE_ENTERA(real));
    printf("Redondear: %d\n", REDONDEAR(real));

    int res = reemplazar_subcadenas(palabra1, palabra2, "LINDOO");
    printf("CADENAS ENCONTRADAS: %d\n", res);
    printf("CADENA: %s\n", palabra1);



    return 0;
}
