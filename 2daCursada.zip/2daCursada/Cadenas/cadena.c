#include "cadena.h"

/// Anagramas
int es_anagrama(const char* pCadena1, const char* pCadena2)
{
    int i = 0, longitud1 = 0, longitud2 = 0,
    vec_abc[26] = {0}; /// Inicializamos el vector del abecedario en 0

    /// Recorremos la primera cadena
    while(*pCadena1)
    {
        /// Incrementamos el valor de la letra dentro del vector del abecedario
        vec_abc[A_MINUSCULA(*pCadena1) - 'a']++;
        /// Incrementamos el puntero a cadena
        pCadena1++;
        /// Incrementamos la longitud de la cadena 1
        longitud1++;
    }

    /// Recorremos la segunda cadena
    while(*pCadena2)
    {
        /// Incrementamos el valor de la letra dentro del vector del abecedario
        vec_abc[A_MINUSCULA(*pCadena2) - 'a']--;
        /// Incrementamos el puntero a cadena
        pCadena2++;
        /// Incrementamos la longitud de la cadena 2
        longitud2++;
    }

    /// Si no tienen la misma longitud, sabemos que no son anagramas
    if(longitud1 != longitud2) return 0;

    /// Recorremos el vector del abecedario en busca de que todos sus elementos sigan en 0
    while(i < 26 && vec_abc[i] == 0)
    {
        i++;
    }

    /// Si lo recorrio todo, es anagrama
    if (i == 26) return 1;

    /// Sino, no lo es
    return 0;

}

/// Palindromo

int es_palindromo(const char* pCad)
{
    const char* pIniCad = pCad;
    const char* pFinCad;
    int esPalindromo = 1;

    /// Obtenemos el puntero de fin de cadena
    while(*(pCad+1)) pCad++;
    pFinCad = pCad;

    /// Colocamos el pCad en el inicio de la cadena
    pCad = pIniCad;

    /// Recorremos la cadena completa
    while(esPalindromo && *pCad)
    {
        /// Salteamos todos los caracteres que no sean letras tanto del principio como del final
        while(*pCad && !ES_LETRA(*pCad)) pCad++;

        while((pFinCad != pIniCad) && !ES_LETRA(*pFinCad)) pFinCad--;

        while(ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pFinCad)))
        {
            pCad++;
            pFinCad--;
        }

        if (ES_LETRA(*pCad) && ES_LETRA(*pFinCad) && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pFinCad)))
        {
            esPalindromo = 0;
        }
    }

    return esPalindromo;
}


/// Subcadenas
int encontrar_subcadena(const char* pCadena, const char* pSubCadena)
{
    const char* iniSubCadena = pSubCadena;
    int encontrada = 0;

    while(*pCadena && !encontrada)
    {
        /// Recorremos la cadena en busca de esta subcadena
        while(*pCadena && A_MINUSCULA(*pCadena) != A_MINUSCULA(*pSubCadena))
        {
            pCadena++;
        }

        /// Recorremos la cadena y verificamos si contiene la subcadena completa
        while(*pCadena && *pSubCadena && (A_MINUSCULA(*pSubCadena) == A_MINUSCULA(*(pCadena))))
        {
            pCadena++;
            pSubCadena++;
        }

        /// Si contiene la subcadena completa, este puntero apuntara a '\0'
        if (!*pSubCadena)
        {
            /// ENCONTRAMOS LA SUBCADENA
            encontrada = 1;
        }
        else
        {
            /// No encontramos la subcadena
            pSubCadena = iniSubCadena;
        }
    }

    return encontrada;

}

int encontrar_subcadenas(const char* pCadena, const char* pSubCadena)
{
    const char* iniSubCadena = pSubCadena;
    int encontrada = 0;

    while(*pCadena)
    {
        /// Recorremos la cadena en busca de esta subcadena
        while(*pCadena && A_MINUSCULA(*pCadena) != A_MINUSCULA(*pSubCadena))
        {
            pCadena++;
        }

        /// Recorremos la cadena y verificamos si contiene la subcadena completa
        while(*pCadena && *pSubCadena && (A_MINUSCULA(*pSubCadena) == A_MINUSCULA(*(pCadena))))
        {
            pCadena++;
            pSubCadena++;
        }

        /// Si contiene la subcadena completa, este puntero apuntara a '\0'
        if (!*pSubCadena)
        {
            /// ENCONTRAMOS LA SUBCADENA
            encontrada++;
            pSubCadena = iniSubCadena;
        }
        else
        {
            /// No encontramos la subcadena
            pSubCadena = iniSubCadena;
        }
    }

    return encontrada;
}

int reemplazar_subcadena(char* pCadena, const char* pSubCadena, const char* nuevaSubCadena)
{
    const char* iniSubCadena = pSubCadena;
    char* iniCadena;
    int encontrada = 0;

    while(*pCadena && !encontrada)
    {
        /// Recorremos la cadena en busca de esta subcadena
        while(*pCadena && A_MINUSCULA(*pCadena) != A_MINUSCULA(*pSubCadena))
        {
            pCadena++;
        }

        if (*pCadena)
        {
            /// Si pCadena != '\0' significa que encontro por lo menos la primera letra coincidente
            iniCadena = pCadena;
        }

        /// Recorremos la cadena y verificamos si contiene la subcadena completa
        while(*pCadena && *pSubCadena && (A_MINUSCULA(*pSubCadena) == A_MINUSCULA(*(pCadena))))
        {
            pCadena++;
            pSubCadena++;
        }

        /// Si contiene la subcadena completa, este puntero apuntara a '\0'
        if (!*pSubCadena)
        {
            /// ENCONTRAMOS LA SUBCADENA
            encontrada = 1;
            /// La reemplazamos
            pSubCadena = iniSubCadena;
            while(*pSubCadena)
            {
                *iniCadena = *nuevaSubCadena;
                nuevaSubCadena++;
                iniCadena++;
                pSubCadena++;
            }
        }
        else
        {
            /// No encontramos la subcadena
            pSubCadena = iniSubCadena;
        }
    }

    return encontrada;
}

int reemplazar_subcadenas(char* pCadena, const char* pSubCadena, const char* nuevaSubCadena)
{
    const char* iniSubCadena = pSubCadena;
    char* iniCadena = pCadena;
    const char* iniNuevaCadena = nuevaSubCadena;
    int encontrada = 0;

    while(*pCadena)
    {
        /// Recorremos la cadena en busca de esta subcadena
        while(*pCadena && A_MINUSCULA(*pCadena) != A_MINUSCULA(*pSubCadena))
        {
            pCadena++;
        }

        /// Si pCadena es != de '\0' quiere decir que se encontro la primera coincidencia
        if(*pCadena)
        {
            /// Guardamos el puntero de donde dejamos la cadena
            iniCadena = pCadena;
        }

        /// Recorremos la cadena y verificamos si contiene la subcadena completa
        while(*pCadena && *pSubCadena && (A_MINUSCULA(*pSubCadena) == A_MINUSCULA(*(pCadena))))
        {
            pCadena++;
            pSubCadena++;
        }

        /// Si contiene la subcadena completa, este puntero apuntara a '\0'
        if (!*pSubCadena)
        {
            /// ENCONTRAMOS LA SUBCADENA
            encontrada++;
            pSubCadena = iniSubCadena;
            while(*pSubCadena)
            {
                *iniCadena = *nuevaSubCadena;
                nuevaSubCadena++;
                iniCadena++;
                pSubCadena++;
            }

            /// Volvemos a colocar el puntero en el inicio de la subcadena por si existe otra a reemplazar
            pSubCadena = iniSubCadena;
            nuevaSubCadena = iniNuevaCadena;
        }
        else
        {
            /// No encontramos la subcadena
            pSubCadena = iniSubCadena;
        }
    }

    return encontrada;
}



/// Biblioteca String
const char * strstr_alu(const char* pCad, const char* pSubCad)
{
    const char* pIniSubCad = pSubCad;
    const char* pRes = NULL;
    int encontrada = 0;

    while(*pCad && !encontrada)
    {
        /// Recorrer la cadena principal (pCad) en busca del primer caracter de pSubCad
        while(*pCad && (A_MINUSCULA(*pCad) != A_MINUSCULA(*pSubCad)))
            pCad++;

        /// Asignamos el puntero de pCad al puntero que retornamos
        if (*pCad) pRes = pCad;

        /// Recorremos la cadena principal y la subcadena, en busca de que coincidan exactamente
        while(*pCad && *pSubCad && (A_MINUSCULA(*pCad) == A_MINUSCULA(*pSubCad)))
        {
            pCad++;
            pSubCad++;
        }

        /// Nos preguntamos si la subCadena llego al caracter nulo
        if (!*pSubCad)
        {
            /// ENCONTRAMOS LA SUBCADENA
            encontrada = 1;
        }
        else
        {
            /// Asignamos al pSubCadena devuelta al inicio de esa subCadena para que siga buscando en pCad
            pSubCad = pIniSubCad;

        }
    }

    return pRes;
}
