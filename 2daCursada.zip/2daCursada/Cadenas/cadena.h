#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

#include <stdlib.h>

#define ES_MINUSCULA(x)(x >= 'a' && x <= 'z')
#define ES_MAYUSCULA(x)(x >= 'A' && x <= 'Z')
#define ES_LETRA(x)(ES_MINUSCULA(x) || ES_MAYUSCULA(x))
#define A_MINUSCULA(x)(ES_MAYUSCULA(x) ? x + ('a' - 'A') : x)
#define A_MAYUSCULA(x)(ES_MINUSCULA(x) ? x - ('a' - 'A') : x)

/// Anagrama
int es_anagrama(const char* pCadena1, const char* pCadena2);

/// Subcadenas
int encontrar_subcadena(const char* pCadena, const char* subCadena);
int encontrar_subcadenas(const char* pCadena, const char* subCadena);
int reemplazar_subcadena(char* pCadena, const char* subCadena, const char* nuevaSubCadena);
int reemplazar_subcadenas(char* pCadena, const char* pSubCadena, const char* nuevaSubCadena);



const char * strstr_alu(const char* pCad, const char* pSubCad);

#endif // CADENA_H_INCLUDED
