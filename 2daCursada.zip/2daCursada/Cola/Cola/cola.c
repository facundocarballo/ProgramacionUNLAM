#include "cola.h"

void crear_cola(t_cola* pc)
{
    pc->pri = NULL;
    pc->ult = NULL;
}

void vaciar_cola(t_cola* pc)
{
    t_nodo* aux;
    while(pc->pri) /// mientras el primer nodo sea distinto de nulo
    {
        /// Obtenemos el nodo a eliminar
        aux = pc->pri;

        /// Eliminamos el nodo
        free(pc->pri->info);
        free(pc->pri);

        /// Ponemos a la cabeza al nodo siguiente
        pc->pri = aux->sig;
    }
    pc->ult = NULL;
}

int cola_llena(const t_cola* pc, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    void* nueInfo = malloc(tamInfo);

    free(nueNodo);
    free(nueInfo);

    return nueNodo == NULL || nueInfo == NULL;

}

int cola_vacia(const t_cola* pc)
{
    return pc->pri == pc->ult == NULL;
}

int poner_en_cola(t_cola* pc, const void* info, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if (!nueNodo)
    {
        puts("PILA LLENA.");
        return 0;
    }
    nueNodo->info = malloc(tamInfo);
    if (!nueNodo->info)
    {
        puts("PILA LLENA.");
        free(nueInfo);
        return 0;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->sig = NULL;
    nueNodo->tamInfo = tamInfo;

    /// Poner el nodo dentro del puntero a cola
    if(pc->ult)
    {
        pc->ult->sig = nueNodo;
    }
    else
    {
        pc->pri = nueNodo;
    }

    /// Ponemos el nuevo nodo al final de la cola
    pc->ult = nueNodo;

    return 1;
}

int sacar_de_cola(t_cola* pc, void* dato, unsigned tamInfo)
{
    if (!pc->pri)
    {
        puts("COLA VACIA.");
        return 0;
    }

    /// Obtenemos el nodo a sacar
    t_nodo* aux = pc->pri;

    /// Enviamos el dato al puntero que nos llega
    memcpy(dato, aux->info, MIN(tamInfo, aux->tamInfo));

    /// Liberamos memoria
    free(aux->info);
    free(aux->pri);

    /// Actualizamos el primero de la cola
    pc->pri = aux->sig;

    return 1;
}

int ver_primero(const t_cola* pc, void* dato, unsigned tamInfo)
{
    if (!pc->pri)
    {
        puts("PILA VACIA.");
        return 0;
    }

    memcpy(dato, pc->pri->info, MIN(tamInfo, pc->pri->tamInfo));

    return 1;
}
