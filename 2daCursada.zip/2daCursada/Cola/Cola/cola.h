#ifndef COLA_H_INCLUDED
#define COLA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define MIN(x,y) (x < y ? x : y

typedef struct s_nodo{
    void* info;
    unsigned tamInfo;
    struct s_nodo* sig;
}t_nodo;

typedef struct{
    t_nodo* pri, *ult;
}t_cola;

void crear_cola(t_cola* pc);
void vaciar_cola(t_cola* pc);
int cola_llena(const t_cola* pc, unsigned tamInfo);
int cola_vacia(const t_cola* pc);
int poner_en_cola(t_cola* pc, const void* info, unsigned tamInfo);
int sacar_de_cola(t_cola* pc, void* dato, unsigned tamInfo);
int ver_primero(const t_cola* pc, void* dato, unsigned tamInfo);

#endif // COLA_H_INCLUDED
