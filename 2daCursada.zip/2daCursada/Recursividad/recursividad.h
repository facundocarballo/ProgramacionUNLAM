#ifndef RECURSIVIDAD_H_INCLUDED
#define RECURSIVIDAD_H_INCLUDED

int factorial(int x);

#endif // RECURSIVIDAD_H_INCLUDED
