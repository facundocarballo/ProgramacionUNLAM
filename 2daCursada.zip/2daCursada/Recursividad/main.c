#include <stdio.h>
#include <stdlib.h>
#include "recursividad.h"


int main()
{
    printf("%d\n", factorial(6));
    return 0;
}
