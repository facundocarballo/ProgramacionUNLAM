#ifndef FECHAS_H_INCLUDED
#define FECHAS_H_INCLUDED
#include "CONSTANTES.h"

typedef struct {
    int dia;
    int mes;
    int anio;
}tFecha;


int funcionMainFechas();
int esFechaValida(tFecha *fecha);
void obtenerDiaSiguiente(tFecha *fecha);
void aumentarDiasBISIESTO(tFecha *fecha, int dias);
void aumentarDias(tFecha *fecha, int dias);
void aumentarUnDiaBISIESTO(tFecha *fecha);
void aumentarUnDia(tFecha *fecha);



#endif // FECHAS_H_INCLUDED
