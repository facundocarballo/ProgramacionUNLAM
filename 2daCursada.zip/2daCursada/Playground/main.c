#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "archivos.h"


int main()
{
    puts("Hello, World!");
    return 0;
}
