#include "Strings.h"


int funcionMainStrings() {
    puts("Prueba de strcpy....\n");

    char origen[] = { "Hola" };
    char destino[5];

    strcpy(origen, destino);

    puts("Variable Direccion Contenido");
    printf("Origen: %p %s \n", &origen, origen);
    printf("Destino %p %s \n\n", &destino, destino);

    puts("Prueba de toUppercase.....\n");

    char cadena[] = { "Hola, esta es una cadena de texto que tendra que salir toda en mayusculas. ASI." };

    printf("Cadena Original: %s\n", cadena);
    toUppercase(cadena);
    printf("Cadena Despues de la funcion: %s\n\n", cadena);

    puts("Prueba de toLowecase...\n");

    toLowercase(cadena);

    printf("Cadena Despues de la funcion: %s\n\n", cadena);

    puts("Prueba de strFormatter...\n");

    char strAFormatear[] = { "hola a todos como estan. espero que esten bien. La anterior oracion la tendrian que haber corregido porque no puse una mayuscula despues del punto." };

    printf("Antes de strFormatter(): %s\n", strAFormatear);

    strFormatter(strAFormatear);

    printf("Despues de strFormatter(): %s\n", strAFormatear);


    return 0;
}

void strcpy(char *origen, char *destino) {

    while(*origen) {
        *destino = *origen;
        destino++;
        origen++;
    }
    *destino = '\0';
}

// Funciones auxiliares

int esMayuscula(char c) {
    return c >= 'A' && c <= 'Z';
}

int esMinuscula(char c) {
    return c >= 'a' && c <= 'z';
}

int esCaracter(char c) {
    return esMayuscula(c) || esMinuscula(c);
}

void toUppercase(char *str) {
    while(*str) {

        if (esMinuscula(*str)) *str = *str - ('a' - 'A');
        // En la tabla ascii, 'a' = 97 y 'A' = 65 => (a - A = 32)
        str++;
    }
}


void toLowercase(char *str){
    while(*str) {
        if (esMayuscula(*str)) *str = *str + ('a' - 'A');
        str++;
    }
}

void strFormatter(char *str) {

    if (esMinuscula(*str)) *str = *str - ('a' - 'A');

    while(*str) {
        if (*str == '.') {
           str += 2;
           if(*str && esMinuscula(*str)) *str = *str - ('a' - 'A');
        }

        str++;

    }
}
