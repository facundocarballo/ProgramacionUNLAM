#include "listaEnlazada.h"

int listaEnlazadaMain() {
    tLista lista;
    crearLista(&lista);

    alum alumno = { "Facundo", "Ing. Informatica", 44, 17 };
    alum alumno2 = { "Nicolas", "Ing. Informatica", 44, 15 };
    alum alumno3 = { "Leandro", "Abogacia", 44, 15 };

    insertarAlPrincipio(&lista, &alumno, sizeof(alum));
    insertarAlPrincipio(&lista, &alumno2, sizeof(alum));
    insertarAlPrincipio(&lista, &alumno3, sizeof(alum));
    insertarAlFinal(&lista, &alumno3, sizeof(alum));

    //imprimirLista(&lista);

    printf("Buscar dato en lista...\n\n");
    buscarDato(&lista, &alumno);

    return 0;
}

// alum alumno = *(alum*)dato; // Casteo de un puntero void a un tipo de dato.

int crearLista(tLista* lista) {
    /*
        tLista es un puntero a nodo.
        Crear lista hace que la lista apunte a NULL.
        Como si el nodo al que apunta se encontrase en NULL.
    */

    *lista = NULL;
    return 1;
}
// fsf
tNodo* crearNodo(unsigned cantBytes, const void* info) {

    tNodo* nuevoNodo;

    if
    (
        (nuevoNodo = (tNodo*)malloc(sizeof(tNodo))) == NULL ||
        ( (nuevoNodo->info = malloc(cantBytes) ) == NULL)
    )
    {
        free(nuevoNodo);
        return NULL;
    }

    memcpy(nuevoNodo->info, info, cantBytes);
    nuevoNodo->tamInfo = cantBytes;
    nuevoNodo->sig = NULL;
    return nuevoNodo;
}

int insertarAlFinal(tLista* pLista, const void* info, const unsigned cantBytes) {
    // Creamos el nodo
    tNodo* nuevoNodo = crearNodo(cantBytes, info);

    // Colocamos el nodo al final de la lista
    tLista lista = *pLista;
    while(lista->sig != NULL) lista = lista->sig;
    lista->sig = nuevoNodo;

}

int compareAlum(alum* alumno1, alum* alumno2) {
    // strcmp devuelve 0 si las cadenas son iguales
    if (strcmp(alumno1->nombre, alumno2->nombre) != 0) return 0;
    if (strcmp(alumno1->carrera, alumno2->carrera) != 0) return 0;
    if (alumno1->materiasAprobadas != alumno2->materiasAprobadas) return 0;
    if (alumno1->materiasDeLaCarrera != alumno2->materiasDeLaCarrera) return 0;

    return 1;
}

int buscarDato(tLista* pLista, const void* info) {
    // Casteamos la informacion al tipo de estructura que estamos analizando.
    alum alumnoAbuscar = *((alum*)info);

    // Recorremos la lista y buscamos que exista esta informacion
    tLista lista = *pLista;
    alum alumno = *((alum*)lista->info);
    while(!compareAlum(&alumno, &alumnoAbuscar) && lista->sig != NULL)
    {
        lista = lista->sig;
        alumno = *((alum*)lista->info);
    }

    if (!compareAlum(&alumno, &alumnoAbuscar))
    {
        printf("ALUMNO NO ENCONTRADO.\n");
        return 0;
    }

    printf("ALUMNO ENCONTRADO.\n");
    return 1;
}

int insertarAlPrincipio(tLista* pLista, const void* info, const unsigned cantBytes) {
    // Creamos el nodo
    tNodo* nuevoNodo = crearNodo(cantBytes, info);

    // Actualizamos el nodo siguiente del recien creado
    nuevoNodo->sig = *pLista;

    // Actualizamos el nodo al que apunta pLista.
    *pLista = nuevoNodo;

    return 1;
}

int imprimirNodo(const tNodo* nodo) {
    alum alumno = *((alum*)nodo->info);
    printf("%s | %s | %d | %d\n", alumno.nombre, alumno.carrera, alumno.materiasAprobadas, alumno.materiasDeLaCarrera);
    return 1;
}

void imprimirLista(const tLista* pLista) {
    tLista listaAux = *pLista;
    while(listaAux != NULL) {
        imprimirNodo(listaAux);
        listaAux = listaAux->sig;
    }
    return;
}
