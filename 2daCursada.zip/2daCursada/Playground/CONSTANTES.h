#ifndef CONSTANTES_H_INCLUDED
#define CONSTANTES_H_INCLUDED

#define false 0;
#define true 1;

#endif // CONSTANTES_H_INCLUDED
