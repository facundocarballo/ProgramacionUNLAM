#ifndef VECTORES_H_INCLUDED
#define VECTORES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

// Funciones auxiliares
int buscarMenor(int *vec, int desde, int cantElem);

/*
    @dev:   - Consiste en recorrer el vector, tomar un numero
            - base e ir preguntandose en cada iteracion si
            - ese numero es menor que el base, si lo es el
            - cambiamos el numero base por ese menor y seguimos
            - recorriendo hasta que lleguemos al final. Luego
            - volvemos a recorrer el vector en busca de otro
            - numero menor, repetimos este proceso N-1 veces.
*/
void ordenamientoBurbujeo(int *vec, int cantElem);

/*
    @dev:   - Consiste en buscar el menor numero dentro
            - del vector, y lo intercambiamos con el de
            - la primera posicion. Luego hacemos lo mismo
            - pero desde el segundo elemento, encontramos
            - el menor y lo colocamos en el segundo
            - elemento. Repetimos este proceso hasta que
            - sea el ultimo elemento del vector.
*/
void ordenamientoSeleccion(int *vec, int cantElem);

/*
    @dev:   - Consiste en insertar los elementos en orden
            - en otro nuevo vector. Cuando terminemos de
            - llenar el segundo vector, se iguala el nuevo
            - al viejo.
*/
void ordenamientoInsercion(int *vec, int cantElem);

#endif // VECTORES_H_INCLUDED
