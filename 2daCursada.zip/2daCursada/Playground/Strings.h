#ifndef STRINGS_H_INCLUDED
#define STRINGS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void strcpy(char *origen, char *destino);
void toUppercase(char *str);
void toLowercase(char *str);
void strFormatter(char *str);



#endif // STRINGS_H_INCLUDED
