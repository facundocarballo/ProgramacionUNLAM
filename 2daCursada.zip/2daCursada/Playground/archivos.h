#ifndef ARCHIVOS_H_INCLUDED
#define ARCHIVOS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nombre[50];
    char carrera[50];
    int totalMaterias;
    int materiasAprobadas;
}alum;

int archivosBinarios();
int primerPrueba();
int segundaPrueba();
int terceraPrueba();
int cuartaPrueba();
int quintaPrueba();
int separarCadenaEnPalabras(char* cad);
int transformarCadenaEnEstructura(char* cad, alum* alumno);
int ordenarArchivo();
int actualizarArchivo(FILE* fp, alum* alumno1, alum* alumno2, const char modo);
int escribirArchivoOrdenado(FILE* fp, alum* alumno1, alum* alumno2, const char modo);
int cmp_alum (const alum* alum1, const alum* alum2);
int obtenerTamanoArchivo(FILE* fp);
int imprimirArchivo(FILE* fp);

#endif // ARCHIVOS_H_INCLUDED
