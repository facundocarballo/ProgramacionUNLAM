#include "documentacion.h"

/// void funcionDePrueba(void)
void funcionDePrueba() {
    printf("Hola Mundo\n");
}
