#ifndef DOCUMENTACION_H_INCLUDED
#define DOCUMENTACION_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

/** Funcion de prueba, esta no devuelve ni recibe ningun parametro. Es solamente de ejemplo para ver como funciona la documentacion de codigo.
**/
/** \brief
 *
 * \param void
 * \param void
 * \return void
 *
 */

void funcionDePrueba();

#endif // DOCUMENTACION_H_INCLUDED
