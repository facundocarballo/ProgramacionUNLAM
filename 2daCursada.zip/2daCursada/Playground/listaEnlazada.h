#ifndef LISTAENLAZADA_H_INCLUDED
#define LISTAENLAZADA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct sNodo {
    void* info;
    unsigned tamInfo;
    struct sNodo* sig;
}tNodo;
typedef tNodo* tLista;

typedef struct s_alum {
    char nombre[100];
    char carrera[100];
    char materiasDeLaCarrera;
    char materiasAprobadas;
} alum;

int crearLista(tLista* lista);
tNodo* crearNodo(const unsigned cantBytes, const void* info);
int insertarAlPrincipio(tLista* pLista, const void* info, const unsigned cantBytes);
int insertarAlFinal(tLista* pLista, const void* info, const unsigned cantBytes);
int buscarDato(tLista* pLista, const void* info);

void imprimirLista(const tLista* pLista);
int imprimirNodo(const tNodo* nodo);

int insertarEnOrdenASC(const void *dato, void* lista);
int insertarEnOrdenDEC(const void *dato, void* lista);

#endif // LISTAENLAZADA_H_INCLUDED
