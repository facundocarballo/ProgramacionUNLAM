#include "archivos.h"
#include <string.h>
/*
// C::\\Usuarios\\AND6D\\Documentos\\Facundo\\programacionUNLAM\\2daCursada\\GuiaEjercicios\\
*/

int archivosBinarios() {
    puts("Escribimos archivo...");
    FILE *fp = fopen("MiNuevoArchivo.dat", "wb");
    if(fp == NULL) return -1;

    alum alumnos[] = {
        {"Nicolas", "Ing. Informatica", 44, 11},
        {"Facundo", "Ing. Informatica", 44, 17},
        {"Ezequiel", "Ing. Informatica", 44, 17},
        {"Victor", "Ing. Informatica", 44, 19}
    }; // Esta ordenado

    fwrite(&alumnos, sizeof(alumnos), 1, fp);

    fclose(fp);

    puts("Actualizamos archivo...");
    fp = fopen("MiNuevoArchivo.dat", "r+b");
    if(fp == NULL) return -1;

    alum alumno;
    fread(&alumno, sizeof(alumno), 1, fp);
    while(!feof(fp))
    {
        if (strcmp(alumno.nombre, "Nicolas") == 0)
        {
            strcpy(alumno.nombre, "Nicolas Modificado");
            fseek(fp, -1L * (long)sizeof(alumno), SEEK_CUR);
            fwrite(&alumno, sizeof(alumno), 1, fp);
            fseek(fp, 0, SEEK_CUR);
        }

        fread(&alumno, sizeof(alumno), 1, fp);
    }

    fclose(fp);

    puts("Imprimimos el archivo...");

    fp = fopen("MiNuevoArchivo.dat", "rb");
    if (fp == NULL) return -1;

    fread(&alumno, sizeof(alumno), 1, fp);
    while(!feof(fp))
    {
        printf("%s - %s - %d - %d\n", alumno.nombre, alumno.carrera, alumno.totalMaterias, alumno.materiasAprobadas);
        fread(&alumno, sizeof(alumno), 1, fp);
    }

    fclose(fp);

    return 0;
}

int primerPrueba() {
    FILE* fp = fopen("archivosCreados\\prueba1.dat", "wb");

    // Si no lo pudo abrir, devuelve NULL. Como NULL = 0, entonces en el if pregunto (fp)
    if (!fp) {
        puts("No se pudo abrir el archivo correctamente.");
        return -1;
    }

    alum alumno1 = { "Facundo", "Ing. Informatica", 44, 17 };
    alum alumno2 = { "Nicolas", "Ing. Informatica", 44, 11 };
    alum alumno3 = { "Victor", "Ing. Informatica", 44, 20 };
    alum alumno4 = { "Leandro", "Derecho", 40, 6 };
    alum alumno5 = { "Agustin", "Educacion Fisica", 50, 18 };

    fwrite(&alumno1, sizeof(alum), 1, fp);
    fwrite(&alumno2, sizeof(alum), 1, fp);
    fwrite(&alumno3, sizeof(alum), 1, fp);
    fwrite(&alumno4, sizeof(alum), 1, fp);
    fwrite(&alumno5, sizeof(alum), 1, fp);

    fclose(fp);

    return 0;
}

int segundaPrueba() {

    FILE* fp = fopen("archivosCreados\\prueba1.dat", "rb");

    if (!fp) {
        puts("No se pudo abrir el archivo correctamente.");
        return -1;
    }

    alum alumno;

    fread(&alumno, sizeof(alum), 1, fp);
    while(!feof(fp)) {
        printf("%s | %s | %d | %d\n", alumno.nombre, alumno.carrera, alumno.totalMaterias, alumno.materiasAprobadas);
        fread(&alumno, sizeof(alum), 1, fp);
    }

    fclose(fp);

    return 0;
}

int terceraPrueba() {
    FILE* fp = fopen("archivosCreados\\terceraPrueba.txt", "wt");

    if (!fp) {
        puts("No se pudo abrir el archivo correctamente.");
        return -1;
    }

    alum alumno1 = { "Facundo", "Ing. Informatica", 44, 17 };
    alum alumno2 = { "Nicolas", "Ing. Informatica", 44, 11 };
    alum alumno3 = { "Victor", "Ing. Informatica", 44, 20 };
    alum alumno4 = { "Leandro", "Derecho", 40, 6 };
    alum alumno5 = { "Agustin", "Educacion Fisica", 50, 18 };

    fprintf(fp, "Nombre | Carrera | Materias de la Carrera | Materias Aprobadas\n");
    fprintf(fp, "%s | %s | %d | %d\n", alumno1.nombre, alumno1.carrera, alumno1.totalMaterias, alumno1.materiasAprobadas);
    fprintf(fp, "%s | %s | %d | %d\n", alumno2.nombre, alumno2.carrera, alumno2.totalMaterias, alumno2.materiasAprobadas);
    fprintf(fp, "%s | %s | %d | %d\n", alumno3.nombre, alumno3.carrera, alumno3.totalMaterias, alumno3.materiasAprobadas);
    fprintf(fp, "%s | %s | %d | %d\n", alumno4.nombre, alumno4.carrera, alumno4.totalMaterias, alumno4.materiasAprobadas);
    fprintf(fp, "%s | %s | %d | %d\n", alumno5.nombre, alumno5.carrera, alumno5.totalMaterias, alumno5.materiasAprobadas);

    fclose(fp);
    return 0;
}

int cuartaPrueba() {
    FILE* fp = fopen("archivosCreados\\terceraPrueba.txt", "rt");
    char cadenaReceptora[100];

    if (!fp) {
        puts("No se pudo abrir el archivo correctamente.");
        return -1;
    }

    // Si lee fin de archivo devuelve 0 (cero) y sale del while
    while(fgets(cadenaReceptora, sizeof(cadenaReceptora), fp)) {
        printf("%s\n", cadenaReceptora);
    }

    return 0;
}

int quintaPrueba() {
    FILE* fp = fopen("archivosCreados\\terceraPrueba.txt", "rt");
    if (!fp) {
        puts("No se pudo abrir el archivo correctamente.");
        return -1;
    }

    alum alumno;
    char cadenaReceptora[100];

    while(fgets(cadenaReceptora, sizeof(cadenaReceptora), fp)) {
        transformarCadenaEnEstructura(cadenaReceptora, &alumno);
        printf("------------------------------------------------\nAlumno encontrado:\n");
        printf("NOMBRE: %s\n", alumno.nombre);
        printf("CARRERA: %s\n", alumno.carrera);
        printf("MATERIAS DE LA CARRERA: %d\n", alumno.totalMaterias);
        printf("MATERIAS APROBADAS: %d\n", alumno.materiasAprobadas);
        printf("%d PORCIENTO DE LA CARRERA HECHA\n", (alumno.materiasAprobadas) * 100 / alumno.totalMaterias);
    }

    fclose(fp);
    return 0;
}

int ordenarArchivo()
{
    /**
        El problema de este algoritmo es que solamente ordena en una pasada.
    */
    FILE* fpRead  = fopen("archivosCreados\\terceraPrueba.txt", "rt");
    FILE* fpWrite = fopen("archivosCreados\\alumnosOrdenados.txt", "wt"); // archivo de lectura+escritura

    if (fpRead == NULL || fpWrite == NULL) {
        puts("No se pudo abrir los archivos correctamente.");
        return -1;
    }

    char cadena[256];
    alum alumno1;
    alum alumno2;

    if (fgets(cadena, sizeof(cadena), fpRead) == NULL) {
        fclose(fpRead);
        fclose(fpWrite);
        puts("El archivo se encuentra ordenado.");
    }

    transformarCadenaEnEstructura(cadena, &alumno1);
    printf("Alumno1: %s\n", alumno1.nombre);

    while(fgets(cadena, sizeof(cadena), fpRead))
    {
        transformarCadenaEnEstructura(cadena, &alumno2);
        printf("Alumno2: %s\n", alumno2.nombre);

        char res =  cmp_alum(&alumno1, &alumno2);
                //actualizarArchivo(fp, &alumno1, &alumno2, res);
        escribirArchivoOrdenado(fpWrite, &alumno1, &alumno2, res);
                // En el caso de escribir el alumno1, tengo guardar el alumno2.
                // La variable alumno2 sirve como auxiliar.
        if (res <= 0){
            alumno1 = alumno2;
            printf("Se escribio Alumno1\nAhora\nAlumno1: %s\n", alumno1.nombre);
        }else {
            printf("Se escribio Alumno2\n");
        }

    }
    fprintf(fpWrite, "%s|%s|%d|%d\n", alumno1.nombre, alumno1.carrera, alumno1.totalMaterias, alumno1.materiasAprobadas);
    puts("Archivo ordenado satisfactoriamente.");
    fclose(fpRead);
    fclose(fpWrite);
    return 0;
}

int escribirArchivoOrdenado(FILE* fp, alum* alumno1, alum* alumno2, const char modo)
{
    if (modo > 0) {
        // alumno1 tiene mas materias aprobadas que el alumno2 (se escribe el alumno2)
        fprintf(fp, "%s|%s|%d|%d\n", alumno2->nombre, alumno2->carrera, alumno2->totalMaterias, alumno2->materiasAprobadas);
    }else {
        // alumno2 tiene mas materias aprobadas que el alumno1 (se escribe el alumno1)
        fprintf(fp, "%s|%s|%d|%d\n", alumno1->nombre, alumno1->carrera, alumno1->totalMaterias, alumno1->materiasAprobadas);
    }
    return 1;
}

int actualizarArchivo(FILE* fp, alum* alumno1, alum* alumno2, const char modo)
{


    if (modo > 0) {
        // alumno1 tiene mas materias aprobadas que el alumno2 (se escribe el alumno2)
        printf("se escribe alumno2 (%s)\n", alumno2->nombre);
        fseek(fp, -2L * (long)sizeof(alum), SEEK_CUR);
        fprintf(fp, "%s|%s|%d|%d\n", alumno2->nombre, alumno2->carrera, alumno2->totalMaterias, alumno2->materiasAprobadas);
        fseek(fp, 1L * (long)sizeof(alum), SEEK_CUR);
    }else {
        // alumno2 tiene mas materias aprobadas que el alumno1 (se escribe el alumno1)
        printf("se escribe alumno1 (%s)\n", alumno1->nombre);
        fseek(fp, -2L * (long)sizeof(alum), SEEK_CUR);
        fprintf(fp, "%s|%s|%d|%d\n", alumno1->nombre, alumno1->carrera, alumno1->totalMaterias, alumno1->materiasAprobadas);
        fseek(fp, 1L * (long)sizeof(alum), SEEK_CUR);
    }

    imprimirArchivo(fp);

    return 1;
}

int imprimirArchivo(FILE* fp)
{
    char cadena[256];
    while(fgets(cadena, sizeof(cadena), fp)) printf("%s\n", cadena);
    return 1;
}

int obtenerTamanoArchivo(FILE* fp) {
    int nroRenglones = 0;
    char cadena[256];

    while(fgets(cadena, sizeof(cadena), fp))
    {
        printf("%s\n", cadena);
        nroRenglones++;
    }
    printf("%d...\n", nroRenglones);
    fseek(fp, 1, SEEK_SET);

    return nroRenglones;
}

int cmp_alum (const alum* alum1, const alum* alum2)
{
    return (alum1->materiasAprobadas - alum2->materiasAprobadas);
}

int transformarCadenaEnEstructura(char* cad, alum* alumno) {
    char* cadenaAux = cad;
    char palabrasEncontradas = 0;

    // Llegamos hasta el final de la cadena
    while(*cadenaAux != '\n') cadenaAux++;
    *cadenaAux = '\0';

    // Recorremos la cadena de atras para adelante hasta encontrar el separador
    while(cadenaAux > cad) {
        //printf("Dir. cadenaAux != Dir. cad\n");
        //printf("0x%p != 0x%p\n", cadenaAux, cad);

        while(*cadenaAux != '|' && cadenaAux >= cad) {
            //printf("*cadenaAux != '|' (%c != '|')\n", *cadenaAux);
            cadenaAux--;
        }

        if (cadenaAux > cad) *cadenaAux = '\0';
        cadenaAux++;

        // Seteamos la cadena dentro de la estructura
        if (palabrasEncontradas == 0) alumno->materiasAprobadas = atoi(cadenaAux);
        if (palabrasEncontradas == 1) alumno->totalMaterias = atoi(cadenaAux);
        if (palabrasEncontradas == 2) strncpy(alumno->carrera, cadenaAux, sizeof(alumno->carrera) - 1);
        if (palabrasEncontradas == 3) strncpy(alumno->nombre, cadenaAux, sizeof(alumno->nombre) - 1);

        palabrasEncontradas++;
        cadenaAux--;
    }

    return 0;
}


int separarCadenaEnPalabras(char* cad) {
    char* cadenaAux = cad;

    // Llegamos hasta el final de la cadena
    while(*cadenaAux != '\n') cadenaAux++;
    *cadenaAux = '\0';

    // Recorremos la cadena de atras para adelante hasta encontrar el separador
    while(cadenaAux > cad) {
        //printf("Dir. cadenaAux != Dir. cad\n");
        //printf("0x%p != 0x%p\n", cadenaAux, cad);

        while(*cadenaAux != '|' && cadenaAux >= cad) {
            //printf("*cadenaAux != '|' (%c != '|')\n", *cadenaAux);
            cadenaAux--;
        }

        if (cadenaAux > cad) *cadenaAux = '\0';

        // Imprimimos la pala   bra encontrada
        cadenaAux++;
        printf("Palabra encontrada: %s\n", cadenaAux);
        cadenaAux--;
        if(cadenaAux < cad) puts("");

    }

    return 0;
}

/*
while(cadenaReceptora != '|') {
            *pCadenaInfo = cadenaReceptora;
            pCadenaInfo++;
            cadenaReceptora++;
        }
        *pCadenaInfo = '\0';
        alumno.nombre = cadenaInformacion;
        pCadenaInfo = cadenaInformacion;
        cadenaReceptora++;

        while(cadenaReceptora != '|') {
            *pCadenaInfo = cadenaReceptora;
            pCadenaInfo++;
            cadenaReceptora++;
        }
        *pCadenaInfo = '\0';
        alumno.carrera = cadenaInformacion;
        pCadenaInfo = cadenaInformacion;
        cadenaReceptora++;

        while(cadenaReceptora != '|') {
            *pCadenaInfo = cadenaReceptora;
            pCadenaInfo++;
            cadenaReceptora++;
        }
        *pCadenaInfo = '\0';
        alumno.materiasAprobadas = cadenaInformacion;
        pCadenaInfo = cadenaInformacion;
        cadenaReceptora++;


*/
