#include <stdio.h>
#include <stdlib.h>

#include "Fechas.h"

#define esBisiesto( X ) ( ( ( X ) % 4 == 0 ) && ( ( X ) % 100 != 0 ) || ( ( X ) % 400 == 0 ) )

int funcionMainFechas() {
    tFecha hoy = { 1, 4, 1999 };

    // hoy = obtenerDiaSiguiente(hoy);
    // Esto no funciona porque no estamos trabajando con punteros...

    aumentarDias(&hoy, 365);

    printf("Fecha en el main, %d/%d/%d.", hoy.dia, hoy.mes, hoy.anio);

    return 0;
}

// Ejercicio 14-> Desarrollar una funci�n que determine si una fecha es formalmente correcta->
int esFechaValida(tFecha *fecha) {

    if (fecha->dia > 31 || fecha->dia < 1 || fecha->mes > 12 || fecha->mes < 1 || fecha->anio < 1 ) return false;

    int diasDelMes[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int diasDelMesBISIESTO[13] = { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };


    if ( esBisiesto(fecha->anio) && diasDelMesBISIESTO[fecha->mes] >= fecha->dia ) return true;

    if ( !esBisiesto(fecha->anio) && diasDelMes[fecha->mes] >= fecha->dia ) return true;

    return false;

}

void aumentarUnDiaBISIESTO(tFecha* fecha) {
    int diasDelMesBISIESTO[13] = { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    if (fecha->dia + 1 <= diasDelMesBISIESTO[fecha->mes]) fecha->dia++;
            else if (fecha->mes + 1 <= 12){
                fecha->dia = 1;
                fecha->mes++;
            }else {
                fecha->anio++;
                fecha->mes = 1;
                fecha->dia = 1;
            }
}

void aumentarUnDia(tFecha* fecha) {
    int diasDelMes[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    if (fecha->dia + 1 <= diasDelMes[fecha->mes]) fecha->dia++;
            else if (fecha->mes + 1 <= 12){
                fecha->dia = 1;
                fecha->mes++;
            }else {
                fecha->anio++;
                fecha->mes = 1;
                fecha->dia = 1;
            }
}

void aumentarDias(tFecha *fecha, int dias) {

    printf("Fecha Inicial: %d/%d/%d\n", fecha->dia, fecha->mes, fecha->anio);
    printf("Fecha despues de sumarle %d dias: \n", dias);


    while (dias > 0) {

        if (esBisiesto(fecha->anio)) {
            aumentarUnDiaBISIESTO(fecha);
        }else {
            aumentarUnDia(fecha);
        }

        dias--;

    }

    printf("Fecha Final: %d/%d/%d \n", fecha->dia, fecha->mes, fecha->anio);
}

void aumentarDiasBISIESTO(tFecha *fecha, int dias) {

    printf("Fecha Inicial: %d/%d/%d\n", fecha->dia, fecha->mes, fecha->anio);
    printf("Fecha despues de sumarle %d dias: \n", dias);

    while (dias > 0) {

        if (esBisiesto(fecha->anio)) {
            aumentarUnDiaBISIESTO(fecha);
        }else {
            aumentarUnDia(fecha);
        }
        dias--;

    }

    printf("Fecha Final: %d/%d/%d \n", fecha->dia, fecha->mes, fecha->anio);
}

// Ejercicio 15-> Desarrollar una funci�n que a partir de una fecha obtenga la correspondiente al d�a siguiente->
void obtenerDiaSiguiente(tFecha *fecha) {

    esBisiesto(fecha->anio) ? aumentarDiasBISIESTO(fecha, 1) : aumentarDias(fecha, 1);

}


