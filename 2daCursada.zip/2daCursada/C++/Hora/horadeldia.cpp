#include "horadeldia.h"

/// Funciones Privadas
void HoraDelDia::agregarSegundo()
{
    if ((segundos + 1) < 60)
    {
        segundos++;
        return;
    }

    segundos = 0;

    if ((minutos + 1) < 60)
    {
        minutos++;
        return;
    }

    minutos = 0;

    if ((horas + 1) < 24)
    {
        horas++;
        return;
    }

    horas = 0;

    return;
}

/// Constructor
HoraDelDia::HoraDelDia(const int _h, const int _m, const int _s)
{
    if (_h >= 24 || _h < 0)
        throw HoraExp("Error: Hora incorrecta");

    if (_m >= 60 || _m < 0)
        throw HoraExp("Error: Minutos incorrectos");

    if (_s >= 60 || _s < 0)
        throw HoraExp("Error: Segundos incorrectos");

    horas = _h;
    minutos = _m;
    segundos = _s;
}


/// Destructor
HoraDelDia::~HoraDelDia()
{

}

/// Metodos
HoraDelDia HoraDelDia::getHoraMaxima()const
{
    HoraDelDia h(23,59,59);

    return h;
}

/// Operadores
bool HoraDelDia::operator>=(const HoraDelDia& obj)const
{
    if (horas >= obj.horas)
        return true;
    else if (horas < obj.horas)
        return false;

    if (minutos >= obj.minutos)
        return true;
    else if (minutos < obj.minutos)
        return false;

    if (segundos >= obj.segundos)
        return true;

    return false;
}


bool HoraDelDia::operator<(const HoraDelDia& obj)const
{
    if (horas < obj.horas)
        return true;
    else if (horas > obj.horas)
        return false;

    if (minutos < obj.minutos)
        return true;
    else if (minutos > obj.minutos)
        return false;

    if (segundos < obj.segundos)
        return true;

    return false;
}

HoraDelDia HoraDelDia::operator++(int)
{
    HoraDelDia n(horas, minutos, segundos);

    agregarSegundo();

    return n;
}

HoraDelDia HoraDelDia::operator+(const HoraDelDia& obj)const
{
    HoraDelDia n
}
