#ifndef HORAEXP_H_INCLUDED
#define HORAEXP_H_INCLUDED

class HoraExp
{
private:
    string mensaje;
public:
    HoraExp(const string& _m);
    ~HoraExp();
    const string& getMensaje()const;
};

#endif // HORAEXP_H_INCLUDED
