#include "horaExp.h"


/// Constructor
HoraExp::HoraExp(const string& _m)
{
    mensaje = _m;
}

/// Destructor
HoraExp::~HoraExp()
{

}

/// Metodos
const string& HoraExp::getMensaje()
{
    return mensaje;
}

