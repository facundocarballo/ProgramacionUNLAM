#ifndef HORADELDIA_H_INCLUDED
#define HORADELDIA_H_INCLUDED

#include <iostream>
#include "horaExp.h"

using namespace std;

class HoraDelDia
{
private:
    int horas, minutos, segundos;
    HoraDelDia agregarSegundo();
public:
    /// Constructores
    HoraDelDia(const int _h = 0, const int _m = 0, const _s = 0);
    /// Destructores
    ~HoraDelDia();
    /// Metodos
    HoraDelDia getHoraMaxima()const;
    /// Operadores
    bool operator>=(const HoraDelDia& obj)const;
    bool operator<(const HoraDelDia& obj)const;
    HoraDelDia operator++(int); // post incremento
    HoraDelDia operator+(const HoraDelDia& obj)const;
    HoraDelDia& operator+=(const int _s);
    HoraDelDia& operator=(const HoraDelDia& obj);
    /// Friends
    friend istream& operator>>(istream& ent, HoraDelDia& obj);
    friend ostream& operator<<(ostream& sal, const HoraDelDia& obj);
    friend HoraDelDia operator+(int _s, const HoraDelDia& obj);
};

#endif // HORADELDIA_H_INCLUDED
