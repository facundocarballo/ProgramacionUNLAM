#include "complejo.h"

Complejo::Complejo(const int r, const int i)
{
    real = r;
    imaginario = i;
}

/// Destructor
Complejo::~Complejo()
{

}

/// Metodos
float Complejo::getReal()
{
    return real;
}

float Complejo::getImaginario()
{
    return imaginario;
}
/// Operadores
Complejo Complejo::operator+(const Complejo& comp)
{
    Complejo nuevoComplejo;

    nuevoComplejo.imaginario = imaginario + comp.imaginario;
    nuevoComplejo.real = real + comp.real;

    return nuevoComplejo;
}

Complejo Complejo::operator+(const int r)
{
    Complejo nuevoComplejo;

    nuevoComplejo.real = real + r;

    return nuevoComplejo;
}

Complejo& Complejo::operator=(const Complejo& comp)
{
    real = comp.real;
    imaginario = comp.imaginario;

    return *this;
}
/// Friend
ostream& operator<<(ostream& sal, const Complejo& comp)
{
    sal << "REAL: " << comp.real << endl;
    sal << "IMAGINARIO: " << comp.imaginario;

    return sal;
}
