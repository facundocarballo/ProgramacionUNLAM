#ifndef COMPLEJO_H_INCLUDED
#define COMPLEJO_H_INCLUDED

#include <iostream>

using namespace std;

class Complejo
{
private:
    float real, imaginario;
public:
    /// Constructor
    Complejo(const int r=1, const int i=1);
    /// Destructor
    ~Complejo();
    /// Metodos
    float getReal();
    float getImaginario();
    /// Operadores
    Complejo operator+(const Complejo& comp);
    Complejo operator+(const int r);
    Complejo& operator=(const Complejo& comp);
    Complejo operator*(const Complejo& comp);
    /// Friend
    friend ostream& operator<<(ostream& sal, const Complejo& comp);
};

#endif // COMPLEJO_H_INCLUDED
