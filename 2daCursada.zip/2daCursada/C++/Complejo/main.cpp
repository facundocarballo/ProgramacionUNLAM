#include <iostream>
#include "complejo.h"

using namespace std;

int main()
{
    Complejo c1;
    Complejo c2(4, 9);
    Complejo c3;


    c3 = c2 + c1;

    cout << c3 << endl;

    c3 = c2;

    cout << "Despues..." << endl;
    cout << c3 << endl;

    return 0;
}
