#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

#include <string>
#include <iostream>


/*
    TODO:
        - Clase Estudiante (hereda de Persona)
        - Clase Empledo (hereda de Persona)
        - Hacer funciones para cada tipo de clase
        - Mostrar por el main algunas cosas de Persona, Empleado y Estudiante

*/

using namespace std;

class Persona
{
private:
    string nombre;
    string apellido;
    int edad;
    unsigned int dni;
    char sexo;
    /// Podriamos agregarle Fecha (nacimiento)

public:
    /// Constructores
    Persona();
    Persona(const Persona& p);
    Persona(const string& n, const string& a);
    Persona(const int d, const int e, const char s);
    Persona(const int d, const int e);
    Persona(const int d, const char s);
    Persona(const char s);
    /// Destructor
    ~Persona();
    /// Metodos
    int obtener_edad();
    unsigned int obtener_dni();
    string obtener_nombre();
    char obtener_sexo();
    /// Operadores
    Persona& operator=(const Persona& per);
    Persona& operator++(); // Preincremento
    Persona operator++(int); // Posincremento
    /// Friends
    friend ostream& operator<<(ostream& sal, const Persona& per);
    friend istream& operator>>(istream& in, Persona& per);

};

#endif // PERSONA_H_INCLUDED
