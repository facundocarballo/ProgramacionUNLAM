#include "estudiante.h"

/// Constructores
   Estudiante::Estudiante()
   {
        //nombre = "";
        nombre_carrera = "";
        //apellido = "";
        //sexo = '\0';
        //edad = 0;
//        dni = 0;
        cant_materias_aprobadas = 0;
        materias_totales_carrera = 0;
        cod_carrera = 0;
   }
   Estudiante::Estudiante(const Estudiante& est)
   {
        nombre = est.nombre;
        nombre_carrera = est.nombre_carrera;
        apellido = est.apellido;
        sexo = est.sexo;
        edad = est.edad;
        dni = est.dni;
        cant_materias_aprobadas = est.cant_materias_aprobadas;
        materias_totales_carrera = est.materias_totales_carrera;
        cod_carrera = est.cod_carrera;
   }

   Estudiante::Estudiante(const Persona& per)
   {
        nombre = per.nombre;
        nombre_carrera = "";
        apellido = per.apellido
        sexo = per.sexo;
        edad = per.edad;
        dni = per.dni;
        cant_materias_aprobadas = 0;
        materias_totales_carrera = 0;
        cod_carrera = 0;
   }
   /// Destructor
   Estudiante::~Estudiante(){}
   /// Metodos
   float Estudiante::porcentaje_de_carrera_hecha()
   {
        if (materias_totales_carrera == 0) return 0;

        return (cant_materias_aprobadas * 100) / materias_totales_carrera;
   }
   unsigned int Estudiante::cantidad_materias_restantes()
   {
        return materias_totales_carrera - cant_materias_aprobadas;
   }
   /// Operadores
   Estudiante& Estudiante::operator=(const Estudiante& est)
   {
        nombre = est.nombre;
        nombre_carrera = est.nombre_carrera;
        apellido = est.apellido;
        sexo = est.sexo;
        edad = est.edad;
        dni = est.dni;
        cant_materias_aprobadas = est.cant_materias_aprobadas;
        materias_totales_carrera = est.materias_totales_carrera;
        cod_carrera = est.cod_carrera;

        return *this;
   }

   Estudiante& Estudiante::operator=(const Persona& per)
   {
        nombre = per.nombre;
        nombre_carrera = "";
        apellido = per.apellido
        sexo = per.sexo;
        edad = per.edad;
        dni = per.dni;
        cant_materias_aprobadas = 0;
        materias_totales_carrera = 0;
        cod_carrera = 0;

        return *this;
   }

   Estudiante& Estudiante::operator++() /// Preincremento
   {
        cant_materias_aprobadas++;

        return *this;
   }

   Estudiante Estudiante::operator++(int i) /// Posincremento
   {
        Estudiante nE(*this);

        nE.cant_materias_aprobadas++;

        return nE;
   }

   /// Friends
   friend ostream& operator<<(ostream& sal, const Estudiante& est)
   {
       sal << "estudiante:" << endl;
       sal << "nombre y apellido: " << est.nombre << " " << est.apellido << endl;
       sal << "dni: " << est.dni << endl;
       sal << "carrera: " << est.nombre_carrera << endl;
       sal << "materias aprobadas: " << est.cant_materias_aprobadas << endl;
       sal << "porcentaje de la carrera hecho: " << est.porcentaje_de_carrera_hecha();
   }

   friend istream& operator>>(istream& in, Estudiante& est)
   {
       cout << "ingrese el nombre del estudiante: ";
       in >> est.nombre;

       cout << "ingrese el apellido del estudiante: ";
       in >> est.apellido;

       cout << "ingrese el dni del estudiante: ";
       int >> est.dni;
   }
