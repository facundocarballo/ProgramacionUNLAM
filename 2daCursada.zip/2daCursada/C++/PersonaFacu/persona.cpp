#include "persona.h"

/// Constructores
Persona::Persona()
{
    nombre = "";
    apellido = "";
    edad = 0;
    dni = 0;
    sexo = '\0';
}

Persona::Persona(const Persona& p)
{
    nombre = p.nombre;
    apellido = p.apellido;
    edad = p.edad;
    sexo = p.sexo;
    dni = p.dni;
}

Persona::Persona(const string& n, const string& a)
{
    nombre = n;
    apellido = a;
    edad = 0;
    dni = 0;
    sexo = '\0';
}

Persona::Persona(const int d, const int e, const char s)
{
    nombre = "";
    apellido = "";
    dni = d;
    edad = e;
    sexo = s;
}


Persona::Persona(const int d, const int e)
{
    nombre = "";
    apellido = "";
    dni = d;
    edad = e;
    sexo = '\0';
}

Persona::Persona(const int d, const char s)
{
    dni = d;
    sexo = s;
    nombre = "";
    apellido = "";
    edad = 0;
}

Persona::Persona(const char s)
{
    sexo = s;
    nombre = "";
    apellido = "";
    edad = 0;
    dni = 0;
}

/// Destructor
Persona::~Persona()
{

}

/// Metodos
int Persona::obtener_edad()
{
    return edad;
}
unsigned int Persona::obtener_dni()
{
    return dni;
}
string Persona::obtener_nombre()
{
    return nombre;
}

char Persona::obtener_sexo()
{
    return sexo;
}
/// Operadores
Persona& Persona::operator=(const Persona& per)
{
    nombre = per.nombre;
    apellido = per.apellido;
    edad = per.edad;
    dni = per.dni;
    sexo = per.sexo;

    return *this;
}

Persona& Persona::operator++() // Preincremento
{
    edad++;

    return *this;
}

Persona Persona::operator++(int) // Posincremento
{
    Persona nP(*this);

    nP.edad++;

    return nP;
}


/// Friends
ostream& operator<<(ostream& sal, const Persona& per)
{
    sal << "NOMBRE: " << per.nombre << endl;
    sal << "APELLIDO: " << per.apellido << endl;
    sal << "DNI: " << per.dni << endl;
    sal << "EDAD: " << per.edad << endl;
    sal << "SEXO: " << per.sexo;

    return sal;
}

istream& operator>>(istream& in, Persona& per)
{
    cout << "NOMBRE:" << endl;
    cout << "> ";
    in >> per.nombre;
    cout << endl;

    cout << "APELLIDO:" << endl;
    cout << "> ";
    in >> per.apellido;
    cout << endl;

    cout << "DNI: " << endl;
    cout << "> ";
    in >> per.dni;
    cout << endl;

    cout << "EDAD: " << endl;
    cout << "> ";
    in >> per.edad;
    cout << endl;

    cout << "SEXO: " << endl;
    cout << "> ";
    in >> per.sexo;




    return in;
}
