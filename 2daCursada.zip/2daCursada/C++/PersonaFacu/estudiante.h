#ifndef ESTUDIANTE_H_INCLUDED
#define ESTUDIANTE_H_INCLUDED

#include "persona.h"

using namespace std;

class Estudiante : public Persona
{
private:
   string nombre_carrera;
   unsigned int cant_materias_aprobadas;
   unsigned int materias_totales_carrera;
   unsigned int cod_carrera;
public:
   /// Constructores
   Estudiante();
   Estudiante(const Estudiante& est);
   Estudiante(const Persona& per);
   /// Destructor
   ~Estudiante();
   /// Metodos
   float porcentaje_de_carrera_hecha();
   unsigned int cantidad_materias_restantes();
   /// Operadores
   Estudiante& operator=(const Estudiante& est);
   Estudiante& operator=(const Persona& per);
   Estudiante& operator++(); /// Preincremento
   Estudiante operator++(int i); /// Posincremento
   /// Friends
   friend ostream& operator<<(ostream& sal, const Estudiante& est);
   friend istream& operator>>(istream& in, Estudiante& est);
};

#endif // ESTUDIANTE_H_INCLUDED
