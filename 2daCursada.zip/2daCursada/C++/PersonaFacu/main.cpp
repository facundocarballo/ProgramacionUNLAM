#include <iostream>
#include "persona.h"

using namespace std;

int main()
{
    Persona p1;
    Persona p2("Facundo", "Carballo");
    Persona p3;
    Persona p4;

    cout << "Personas..." << endl;

    cout << p1 << endl;
    cout << "------------------" << endl;
    cout << p2 << endl;

    cout << "------------------" << endl;
    cout << "------------------" << endl;

    cin >> p1;

    cout << "------------------" << endl;


    cout << "Personas..." << endl;

    cout << "------------------" << endl;

    p2 = p1;

    cout << p1 << endl;
    cout << "------------------" << endl;
    cout << p2 << endl;

    cout << "PRE-INCREMENTO" << endl;
    p3 = ++p1;
    cout << p1 << endl;
    cout << p3 << endl;

    cout << "POS-INCREMENTO" << endl;
    p4 = p2++;
    cout << p2 << endl;
    cout << p4 << endl;



    return 0;
}
