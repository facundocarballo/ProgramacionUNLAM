#include "cadena.h"

int main()
{
    Cadena c1;
    Cadena c2("Hola esta es una cadena inicializada por puntero a char");
    Cadena c3(c1);
    Cadena c4(c2);

    cout << "CADENAS" << endl;

    cout << "Cadena 1: " << c1 << endl;
    cout << "Longitud de c1: " << c1.longitud() << endl;

    cout << "Cadena 2: " << c2 << endl;
    cout << "Longitud de c2: " << c2.longitud() << endl;

    cout << "Cadena 3: " << c3 << endl;
    cout << "Longitud de c3: " << c3.longitud() << endl;

    cout << "Cadena 4: " << c4 << endl;
    cout << "Longitud de c4: " << c4.longitud() << endl;

    cout << "Modificacion de las cadenas" << endl;

    c1 = "Hola, esta es una cadena nueva que se sobreescribio en c1";
    c2 = "Otro reemplazo de una cadena que ya se habia creado mediante puntero a char";


    cout << "CADENAS" << endl;

    cout << "Cadena 1: " << c1 << endl;
    cout << "Longitud de c1: " << c1.longitud() << endl;

    cout << "Cadena 2: " << c2 << endl;
    cout << "Longitud de c2: " << c2.longitud() << endl;

    cout << "Cadena 3: " << c3 << endl;
    cout << "Longitud de c3: " << c3.longitud() << endl;

    cout << "Cadena 4: " << c4 << endl;
    cout << "Longitud de c4: " << c4.longitud() << endl;


    return 0;
}
