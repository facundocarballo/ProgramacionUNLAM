#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

#include <iostream>

using namespace std;

class Cadena
{
private:
    char* pCadena;
public:
    /// Constructores
    Cadena();
    Cadena(const char* cad);
    Cadena(const Cadena& cad);
    /// Destructores
    ~Cadena();
    /// Funciones
    unsigned int longitud();
    /// Operadores
    Cadena& operator=(const char* cad);
    Cadena& operator=(const Cadena& cad);
    Cadena& operator+=(const char* cad);
    Cadena& operator+=(const Cadena& cad);
    Cadena operator+(const char* cad);
    Cadena operator+(const Cadena& cad);
    /// Friends
    friend ostream& operator<<(ostream& izq, const Cadena& der);

};


#endif // CADENA_H_INCLUDED
