#include "cadena.h"
#include "string.h"

/// Constructores
Cadena::Cadena()
{
    /// Inicializacion de una cadena que no se le pasa nada como parametro
    pCadena = new char[0];
    *pCadena = '\0';
}

Cadena::Cadena(const char* cad)
{
    /// Inicializacion de una cadena que se le pasa por parametro un puntero a cadena
    pCadena = new char[strlen(cad) + 1];
    strcpy(pCadena, cad);
}

Cadena::Cadena(const Cadena& cad)
{
    /// Inicializacion de una cadena que se le pasa por parametro una referencia de otra Cadena
    pCadena = new char[strlen(cad.pCadena) + 1];
    strcpy(pCadena, cad.pCadena);
}

/// Destructor
Cadena::~Cadena()
{
    /// Destructor de una cadena
    cout << "Destruyendo la cadena: " << *this << endl;

    delete []pCadena;
}

/// Funciones
unsigned int Cadena::longitud()
{
    return strlen(pCadena);
}

/// Operadores
Cadena& Cadena::operator=(const char* cad)
{
    /// Funcion para asignar un nuevo valor (puntero a char) a una cadena ya existente
    delete []pCadena;

    pCadena = new char[strlen(cad) + 1];
    strcpy(pCadena, cad);

    return *this;
}

Cadena& Cadena::operator=(const Cadena& cad)
{
    /// Funcion para asignar un nuevo valor (cadena existente) a una cadena ya existente
    delete []pCadena;

    pCadena = new char[strlen(cad.pCadena) + 1];
    strcpy(pCadena, cad.pCadena);

    return *this;
}

Cadena& Cadena::operator+=(const char* cad)
{
    /// Funcion que concatena una Cadena existente con otra cadena que nos llega por parametro como puntor a char
    delete []pCadena;

    /// aux tiene la cadena concatenada
    char* aux = pCadena;
    strcat(aux, cad);

    /// asignamos memoria dinamica al puntero cadena de la clase y copiamos la cadena concatenada
    pCadena = new char[strlen(aux) + 1];
    strcpy(pCadena, aux);

    return *this;
}

Cadena& Cadena::operator+=(const Cadena& cad)
{
    /// Funcion que concatena una Cadena existente con otra cadena que nos llega por parametro como puntor a char
    delete []pCadena;

    /// aux tiene la cadena concatenada
    char* aux = pCadena;
    strcat(aux, cad.pCadena);

    /// asignamos memoria dinamica al puntero cadena de la clase y copiamos la cadena concatenada
    pCadena = new char[strlen(aux)+1];
    strcpy(pCadena, aux);

    return *this;
}

 Cadena Cadena::operator+(const char* cad)
 {
    /// Creamos una nueva cadena
    Cadena nuevaCadena;

    /// Asignamos a esta cadena la memoria correspondiente
    nuevaCadena.pCadena = new char[strlen(pCadena)+strlen(cad)+1];

    /// Copiamos en la nueva cadena el contenido que tiene nuestra cadena original
    strcpy(nuevaCadena.pCadena, pCadena);

    /// Agregamos a esta nueva cadena el contenido que nos llega por parametro
    strcat(nuevaCadena.pCadena, cad);

    /// Retornamos esta nueva cadena
    return nuevaCadena;
 }

 Cadena Cadena::operator+(const Cadena& cad)
 {
    /// Creamos una nueva cadena
    Cadena nuevaCadena;

    /// Asignamos a esta cadena la memoria correspondiente
    nuevaCadena.pCadena = new char[strlen(pCadena)+strlen(cad.pCadena)];

    /// Copiamos en la nueva cadena el contenido que tiene nuestra cadena original
    strcpy(nuevaCadena.pCadena, pCadena);

    /// Agregamos a esta nueva cadena el contenido que nos llega por parametro
    strcat(nuevaCadena.pCadena, cad.pCadena);

    /// Retornamos esta nueva cadena
    return nuevaCadena;
 }

 /// Friends
 std::ostream& operator<<(std::ostream& izq, const Cadena& cad)
 {
     izq << cad.pCadena;

     return izq;
 }
