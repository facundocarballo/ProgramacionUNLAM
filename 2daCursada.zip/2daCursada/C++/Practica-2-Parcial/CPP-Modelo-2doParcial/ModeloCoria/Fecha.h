#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include <iostream>

using namespace std;

class Fecha
{
private:
    int dia, mes, anio;
public:
    // Constructor
    Fecha(int d, int m, int a);
    // Destructor
    ~Fecha();
    // Metodos
    // Operadores
    // Friends
    friend ostream& operator<<(ostream& sal, const Fecha& obj);
};

#endif // FECHA_H_INCLUDED
