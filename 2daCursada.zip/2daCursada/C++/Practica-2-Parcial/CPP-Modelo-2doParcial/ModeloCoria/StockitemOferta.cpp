#include "StockitemOferta.h"

// Constructores
StockitemOferta::StockitemOferta(const int _id = 0, const char* _nombre = NULL,
                const float _precio = 0.0, const int _nArticulos = 0,
                const Fecha _desde, const Fecha _hasta, const float _descuento)
                : Stockitem(_id, _nombre, _precio, _nArticulos), desde(_desde), hasta(_hasta),
                descuento(_descuento) {}

// Destructores
StockitemOferta::~StockitemOferta()
{
    cout << "Destruyendo StockItemOferta..." << endl;
}

// Metodos
void StockitemOferta::mostrar()const
{
    cout << "Producto ID: " << id << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Precio: $ " << precio << endl;
    cout << "Cant. Articulos: " << nArticulos << endl;
    cout << "Oferta Desde: " << desde << endl;
    cout << "Oferta Hasta: " << hasta << endl;
    cout << "Descuento: %" << descuento * 100 << endl;
}

void StockitemOferta::precioDescuento()const
{
    cout << "Producto ID: " << id << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Precio: $ " << precio << endl;
    cout << "Cant. Articulos: " << nArticulos << endl;
    cout << "Oferta Desde: " << desde << endl;
    cout << "Oferta Hasta: " << hasta << endl;
    cout << "Precio con Descuento: $ " << descuento * precio << endl;
}

StockitemOferta& StockitemOferta::operator++()
{
    nArticulos++;

    return *this;
}

// Friends
ostream& operator<<(ostream& sal, const Stockitem& obj)
{
    sal << "Producto ID: " << obj.id << endl;
    sal << "Nombre: " << obj.nombre << endl;
    sal << "Precio: $ " << obj.precio << endl;
    sal << "Cant. Articulos: " << obj.nArticulos << endl;
    sal << "Oferta Desde: " << obj.desde << endl;
    sal << "Oferta Hasta: " << obj.hasta << endl;
    sal << "Descuento: %" << obj.descuento * 100 << endl;

    return sal;
}



