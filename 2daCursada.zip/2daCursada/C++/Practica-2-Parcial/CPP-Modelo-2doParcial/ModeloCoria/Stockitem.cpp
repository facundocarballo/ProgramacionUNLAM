#include "StockItem.h"
#include <string.h>

// Constructor
Stockitem::Stockitem(const int _id = 0, const char* _nombre = NULL,
                const float _precio = 0.0, const int _nArticulos = 0)
{
    id = _id;
    precio = _precio;
    nArticulos = _nArticulos;

    nombre = new char [strlen(_nombre) + 1];
    strcpy(nombre, _nombre);
}

// Destructor
Stockitem::~Stockitem()
{
    delete nombre [];

    cout << "Destruyendo StockItem..." << endl;
}

// Metodos
void Stockitem::mostrar()
{
    cout << "Producto ID: " << id << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Precio: $ " << precio << endl;
    cout << "Cant. Articulos: " << nArticulos << endl;
}

// Operadores
Stockitem& Stockitem::operator++()
{
    nArticulos++;

    return *this;
}

// Friends
ostream& operator<<(ostream& sal, const Stockitem& obj)
{
    sal << "Producto ID: " << obj.id << endl;
    sal << "Nombre: " << obj.nombre << endl;
    sal << "Precio: $ " << obj.precio << endl;
    sal << "Cant. Articulos: " << obj.nArticulos << endl;

    return sal;
}

istream& operator>>(istream& ent, Stockitem& obj)
{
    char nuevoNombre[1000];

    cout << "Ingrese el Producto ID: ";
    ent >> obj.id;
    cout << endl:

    cout << "Ingrese el nombre del producto: ";
    ent.getline(nuevoNombre, 1000);

    if (strlen(nuevoNombre) != strlen(obj.nombre))
    {
        delete obj.nombre [];
        obj.nombre = new char[strlen(nuevoNombre)];
    }

    strcpy(obj.nombre, nuevoNombre);
    cout << endl;

    cout << "Ingrese el precio del producto: $ ";
    ent >> obj.precio;
    cout << endl;

    cout << "Ingrese el stock del producto: ";
    ent >> obj.nArticulos;
    cout << endl;

    return ent;
}
