#ifndef STOCKITEM_H_INCLUDED
#define STOCKITEM_H_INCLUDED

#include <iostream>

using namespace std;

class Stockitem
{
private:
    int id, nArticulos;
    char* nombre;
    float precio;
public:
    // Constructores
    Stockitem(const int _id = 0, const char* _nombre = NULL,
                const float _precio = 0.0, const int _nArticulos = 0);
    // Destructores
    ~Stockitem();
    // Metodos
    virtual void mostrar()const;
    // Operadores
    virtual Stockitem& operator++();
    // Friends
    friend ostream& operator<<(ostream& sal, const Stockitem& obj);
    friend istream& operator>>(istream& ent, Stockitem& obj);
};

#endif // STOCKITEM_H_INCLUDED
