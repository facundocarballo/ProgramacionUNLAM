#include "Fecha.h"

// Constructor
Fecha::Fecha(int d, int m, int a)
{
    dia = d;
    mes = m;
    anio = a;
}

// Destructor
Fecha::~Fecha()
{
    cout << "Destruyendo Fecha..." << endl;
}

// Friends
ostream& operator<<(ostream& sal, const Fecha& obj)
{
    sal << obj.dia << "/" << obj.mes << "/" << obj.anio << endl;

    return sal;
}
