#ifndef DIVIDIRPORCERO_H_INCLUDED
#define DIVIDIRPORCERO_H_INCLUDED

#include <string>

using namespace std;

class DividirPorCero
{
private:
    string mensaje;
public:
    /// Constructor
    DividirPorCero(const string& men);

    /// Metodos
    const string& getMensaje() const;
};

#endif // DIVIDIRPORCERO_H_INCLUDED
