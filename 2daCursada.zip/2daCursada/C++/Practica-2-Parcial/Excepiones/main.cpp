#include <iostream>
#include "DividirPorCero.h"
#include "Division.h"

using namespace std;

int main()
{
    try
    {
        Division d;
        Division f = Division(5,0);

         cout << "PRIMERA DIVISION" << endl;

        cout << "Numerador: " << d.getNumerador() << endl;
        cout << "Denominador: " << d.getDenominador() << endl;

        cout << "SEGUNDA DIVISION" << endl;

        cout << "Numerador: " << d.getNumerador() << endl;
        cout << "Denominador: " << d.getDenominador() << endl;

    }
    catch(const DividirPorCero& exp)
    {
        cout << exp.getMensaje() << endl;
    }




    return 0;
}
