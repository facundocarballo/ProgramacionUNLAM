#include "DividirPorCero.h"

using namespace std;

DividirPorCero::DividirPorCero(const string& men)
{
    mensaje = men;
}

const string& DividirPorCero::getMensaje()const
{
    return mensaje;
}
