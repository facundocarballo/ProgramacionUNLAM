#include "Division.h"
#include "DividirPorCero.h"
#include <iostream>

using namespace std;

Division::Division(int n, int d)
{
    if (d == 0) throw DividirPorCero("ERROR: No se puede dividir por cero.");
}

Division::~Division()
{
    cout << "Destruyendo DIVISION..." << endl;
}

int Division::getNumerador()const
{
    return numerador;
}

int Division::getDenominador()const
{
    return denominador;
}
