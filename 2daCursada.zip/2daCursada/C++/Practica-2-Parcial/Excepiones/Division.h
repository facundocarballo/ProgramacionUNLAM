#ifndef DIVISION_H_INCLUDED
#define DIVISION_H_INCLUDED

class Division
{
private:
    int numerador, denominador;
public:
    /// Constructores
    Division(int n = 0, int d = 1);
    /// Destructores
    ~Division();
    /// Metodos
    int getNumerador()const;
    int getDenominador()const;
    /// Operadores
    /// Friends
};

#endif // DIVISION_H_INCLUDED
