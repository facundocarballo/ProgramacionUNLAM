#include "StockitemOferta.h"

// Constructores
StockitemOferta::StockitemOferta(const int _id, const char* _nombre,
                const float _precio, const int _nArticulos,
                const Fecha _desde, const Fecha _hasta, const float _descuento)
                : Stockitem(_id, _nombre, _precio, _nArticulos), desde(_desde), hasta(_hasta),
                descuento(_descuento) {}

// Destructores
StockitemOferta::~StockitemOferta()
{
    cout << "Destruyendo StockItemOferta..." << endl;
}

// Metodos
void StockitemOferta::mostrar()const
{
    Stockitem::mostrar();
    cout << "Oferta Desde: " << desde << endl;
    cout << "Oferta Hasta: " << hasta << endl;
    cout << "Descuento: %" << descuento * 100 << endl;
}

float StockitemOferta::precioDescuento()const
{
    //Stockitem::mostrar();
    //cout << "Oferta Desde: " << desde << endl;
    //cout << "Oferta Hasta: " << hasta << endl;
    //cout << "Precio con Descuento: $ " << descuento * getPrecio() << endl;

    return descuento * getPrecio();
}

// Friends
ostream& operator<<(ostream& sal, const StockitemOferta& obj)
{
    sal << "Producto ID: " << obj.getId() << endl;
    sal << "Nombre: " << obj.getNombre() << endl;
    sal << "Precio: $ " << obj.getPrecio() << endl;
    sal << "Cant. Articulos: " << obj.getNumArt() << endl;
    sal << "Oferta Desde: " << obj.desde << endl;
    sal << "Oferta Hasta: " << obj.hasta << endl;
    sal << "Descuento: %" << obj.descuento * 100 << endl;

    return sal;
}



