#include <iostream>
#include "StockItem.h"
#include "StockitemOferta.h"

using namespace std;

void mostrarProducto(Stockitem& obj);

int main()
{
Stockitem s1;
s1.mostrar(); // va a mostrar el id = 0 , nombre = NULL, precio =0.0 y � nArticulos = 0;
cout << s1 << endl;
Stockitem s2(1231,"Lavarropas",5676,30);
cout<<s2<<endl;
char nom[500]="Aspiradora";
Fecha desde(5,10,2022);
Fecha hasta(15,10,2022);

StockitemOferta s3(1256,nom, 12315,10, desde,hasta, 0.5);
s3++; // suma 1 a la cantidad del stock
cout << s3.precioDescuento() << endl; // muestra todos los datos del producto, las fechas�
//durante las cuales est� en oferta y el precio con el descuento

cout<<endl<<" Mostrar Electrodomesticos en forma polimorfica "<<endl;
//colocar el c�digo de mostrar polimorfica aqu�


        mostrarProducto(s3);

     //
cin>>s1;
cout<<s1;
return 0;
}

void mostrarProducto(Stockitem& obj)
{
    obj.mostrar();
}
