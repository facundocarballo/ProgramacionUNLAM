#ifndef STOCKITEMOFERTA_H_INCLUDED
#define STOCKITEMOFERTA_H_INCLUDED

#include <iostream>
#include "StockItem.h"
#include "Fecha.h"

class StockitemOferta : public Stockitem
{
private:
    Fecha desde, hasta;
    float descuento;

public:
    // Constructor
    StockitemOferta(const int _id = 0, const char* _nombre = NULL,
                const float _precio = 0.0, const int _nArticulos = 0,
                const Fecha _desde = Fecha(1,1,2000), const Fecha _hasta = Fecha(1,1,2000), const float _descuento = 0);
    // Destructor
    ~StockitemOferta();
    // Metodos
    void mostrar()const;
    float precioDescuento()const;
    // Operadores
    // Friends
    friend ostream& operator<<(ostream& sal, const StockitemOferta& obj);
};


#endif // STOCKITEMOFERTA_H_INCLUDED
