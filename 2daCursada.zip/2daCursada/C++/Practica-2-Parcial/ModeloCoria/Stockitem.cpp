#include "StockItem.h"
#include <string.h>

// Constructor
Stockitem::Stockitem(const int _id, const char* _nombre,
                const float _precio, const int _nArticulos)
{
    id = _id;
    precio = _precio;
    nArticulos = _nArticulos;

    if (_nombre != NULL)
    {
        nombre = new char [strlen(_nombre) + 1];
        strcpy(nombre, _nombre);
    }
    else
    {
        nombre = NULL;
    }

}

// Destructor
Stockitem::~Stockitem()
{
    delete [] nombre;

    cout << "Destruyendo StockItem..." << endl;
}

// Metodos
void Stockitem::mostrar()const
{
    cout << "Producto ID: " << id << endl;
    if (nombre == NULL)
    {
        cout << "Nombre: NULL" << endl;
    }
    else
    {
        cout << "Nombre: " << nombre << endl;
    }

    cout << "Precio: $ " << precio << endl;
    cout << "Cant. Articulos: " << nArticulos << endl;
}

int Stockitem::getId()const
{
    return id;
}
int Stockitem::getNumArt()const
{
    return nArticulos;
}
char* Stockitem::getNombre()const
{
    return nombre;
}
float Stockitem::getPrecio()const
{
    return precio;
}

// Operadores
Stockitem Stockitem::operator++(int)
{
    Stockitem n(id, nombre, precio, nArticulos);

    nArticulos++;

    return n;
}

// Friends
ostream& operator<<(ostream& sal, const Stockitem& obj)
{
    sal << "Producto ID: " << obj.id << endl;
    if (obj.nombre == NULL)
    {
        sal << "Nombre: NULL" << endl;
    }
    else
    {
        sal << "Nombre: " << obj.nombre << endl;
    }

    sal << "Precio: $ " << obj.precio << endl;
    sal << "Cant. Articulos: " << obj.nArticulos << endl;

    return sal;
}

istream& operator>>(istream& ent, Stockitem& obj)
{
    char nuevoNombre[1000];

    cout << "Ingrese el Producto ID: ";
    ent >> obj.id;

    fflush(stdin);
    cout << "Ingrese el nombre del producto: ";
    ent.getline(nuevoNombre, 1000);

    if (obj.nombre == NULL)
    {
        obj.nombre = new char[strlen(nuevoNombre) + 1];
    }
    else if (strlen(nuevoNombre) != strlen(obj.nombre))
    {
        delete [] obj.nombre ;
        obj.nombre = new char[strlen(nuevoNombre) + 1];
    }

    strcpy(obj.nombre, nuevoNombre);

    cout << "Ingrese el precio del producto: $ ";
    ent >> obj.precio;

    cout << "Ingrese el stock del producto: ";
    ent >> obj.nArticulos;

    return ent;
}
