#ifndef FIGURA_H_INCLUDED
#define FIGURA_H_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class Figura
{
private:
    string nombre;
public:
    /// Constructores
    Figura(const string& n);
    /// Destructores
    virtual ~Figura();
    /// Metodos
    virtual float area()const = 0;
    virtual float perimetro()const = 0;
    const string& getNombre()const;
    /// Operadores
    /// Friends
};

#endif // FIGURA_H_INCLUDED
