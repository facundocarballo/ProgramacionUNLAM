#include <iostream>
#include "Figura.h"
#include "Cuadrado.h"

using namespace std;

void recibir_figura(const Figura& fig);

int main()
{
    Cuadrado c("Cuadrado 1", 3);

    recibir_figura(c);

    return 0;
}


void recibir_figura(const Figura& fig)
{
    cout << "OBTENEMOS DATOS DE LA FIGURA" << endl;

    cout << "Nombre: " << fig.getNombre() << endl;

    cout << "Area: " << fig.area() << endl;

    cout << "Perimetros: " << fig.perimetro() << endl;

}
