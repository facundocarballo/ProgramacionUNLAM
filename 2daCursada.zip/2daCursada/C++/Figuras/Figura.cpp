#include "Figura.h"

using namespace std;

/// Constructores
Figura::Figura(const string& n)
{
    nombre = n;
}

/// Destructores
Figura::~Figura()
{
    cout << "Destruyendo Figura: " << nombre << endl;
}

const string& Figura::getNombre()const
{
    return nombre;
}
