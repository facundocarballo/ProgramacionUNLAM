#include "Cuadrado.h"

/// Constructores
Cuadrado::Cuadrado(const string& n, const float l)
: Figura(n), lado(l) {}

/// Destructores
Cuadrado::~Cuadrado()
{
    cout << "Destruyendo Cuadrado" << endl;
}

/// Metodos
float Cuadrado::area()const
{
    return lado*lado;
}

float Cuadrado::perimetro()const
{
    return lado*4;
}
