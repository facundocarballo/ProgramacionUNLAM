#ifndef CUADRADO_H_INCLUDED
#define CUADRADO_H_INCLUDED

#include "Figura.h"

class Cuadrado : public Figura
{
private:
    float lado;
public:
    /// Constructores
    Cuadrado(const string& n, const float l);
    /// Destructores
    ~Cuadrado();
    /// Metodos
    float area()const;
    float perimetro()const;
    /// Operadores
    /// Friends
};

#endif // CUADRADO_H_INCLUDED
