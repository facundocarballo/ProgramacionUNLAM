#include "VideoJuego.h"

VideoJuego::VideoJuego()
{
    //ctor
}

VideoJuego::~VideoJuego()
{
    //dtor
}
