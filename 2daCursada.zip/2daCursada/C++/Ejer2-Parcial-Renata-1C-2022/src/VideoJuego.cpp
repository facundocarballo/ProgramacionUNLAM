///Coria_Lautaro_41691904
#include "VideoJuego.h"
#include <queue>
#include <fstream>
VideoJuego::VideoJuego()
{
    this->Titulo = new char[1];
    this->Titulo[0] = '\0';

    strcpy(this->Genero,"Sin Genero");
    this->Fabricante = new char[1];
    this->Fabricante[0] = '\0';
    this->Entregado = false;
    this->DiasDePrestamo = 0;
}

VideoJuego::VideoJuego(const char *Titulo,const char *Genero,const char *Fabricante, bool Entregado, int DiasDePrestamo)
{
    this->Entregado = Entregado;
    this->DiasDePrestamo = DiasDePrestamo;
    strcpy(this->Genero, Genero);
    if(Titulo == NULL && Fabricante == NULL)
    {
        this->Titulo = new char[1];
        this->Titulo[0] = '\0';
        this->Fabricante = new char[1];
        this->Fabricante[0] = '\0';
    }
    else
    {
        this->Titulo = new char[strlen(Titulo)+1];
        strcpy(this->Titulo, Titulo);
        this->Fabricante = new char[strlen(Fabricante)+1];
        strcpy(this->Fabricante, Fabricante);
    }
}

VideoJuego::VideoJuego(const VideoJuego& juego)
{
    this->Titulo = new char[strlen(juego.Titulo)+1];
    strcpy(this->Titulo, juego.Titulo);
    strcpy(this->Genero, juego.Genero);
    this->Fabricante = new char[strlen(juego.Fabricante)+1];
    strcpy(this->Fabricante, juego.Fabricante);
    this->Entregado = juego.Entregado;
    this->DiasDePrestamo = juego.DiasDePrestamo;
}

void  VideoJuego::mostrar()const
{
    cout<<((this->Titulo[0])?this->Titulo: "NULL")<<" - "<<this->Genero<<" - "<<((this->Fabricante[0])?this->Fabricante: "NULL")<<" - "<<this->Entregado<<" - "<<this->DiasDePrestamo<<endl;
}

VideoJuego& VideoJuego::prestar()
{
    this->Entregado = true;
    this->DiasDePrestamo = 1;
    return *this;
}

VideoJuego& VideoJuego::operator ++()
{
    this->DiasDePrestamo++;
    return *this;
}

VideoJuego& VideoJuego::operator =(const VideoJuego& juego)
{
    delete []Titulo;
    delete []Fabricante;

    Titulo = new char[strlen(juego.Genero) + 1];
    strcpy(Titulo, juego.Genero);

    strcpy(Genero, juego.Genero);

    Fabricante = new char[strlen(juego.Fabricante) + 1];
    strcpy(Fabricante, juego.Fabricante);

    Entregado = juego.Entregado;

    DiasDePrestamo = juego.DiasDePrestamo;


    return *this;
}

VideoJuego& VideoJuego::devolver()
{
    this->Entregado = false;
    this->DiasDePrestamo = 0;
    return *this;
}

ostream& operator <<(ostream& sal, VideoJuego& juego)
{
    sal<<((juego.Titulo[0])?juego.Titulo:"NULL")<<" - "<<juego.Genero<<" - "<<((juego.Fabricante[0])?juego.Fabricante:"NULL")<<" - "<<juego.Entregado<<" - "<<juego.DiasDePrestamo<<endl;
    return sal;
}

istream& operator >>(istream& is, VideoJuego& juego)
{
    queue<char>cola;
    char c;

    cout<<"Ingrese Titulo del Video juego"<<endl;
    while((c = is.get()) != EOF && c != '\n')
        cola.push(c);
    if(strlen(juego.Titulo) != cola.size())
    {
        delete [] juego.Titulo;
        juego.Titulo = new char[cola.size()];
    }
    int i = 0;
    while(!cola.empty())
    {
        juego.Titulo[i] = cola.front();
        cola.pop();
        i++;
    }
    fflush(stdin);

    cout<<"Ingrese Genero del Video juego"<<endl;
//    while(strlen(juego.Genero) > cola.size())
//   {
        while((c = is.get()) != EOF && c != '\n' && strlen(juego.Genero) > cola.size())
            cola.push(c);
//   }
   if(strlen(juego.Genero) != cola.size()) i = 0;

    while(!cola.empty())
    {
        juego.Genero[i] = cola.front();
        cola.pop();
        i++;
    }
    juego.Genero[i] = '\0';
    fflush(stdin);

    cout<<"Ingrese Fabricante del Video juego"<<endl;
   while((c = is.get()) != EOF && c != '\n')
        cola.push(c);
    if(strlen(juego.Fabricante) != cola.size())
    {
        delete [] juego.Fabricante;
        juego.Fabricante = new char[cola.size()];
    }
    i = 0;
    while(!cola.empty())
    {
        juego.Fabricante[i] = cola.front();
        cola.pop();
        i++;
    }
    fflush(stdin);

    cout<<"Ingrese si Entrego el Video juego, true/false"<<endl;
    cin>>juego.Entregado;
    fflush(stdin);

    cout<<"Ingrese Dias de prestamo del Video juego"<<endl;
    cin>>juego.DiasDePrestamo;
    return is;
}

VideoJuego::~VideoJuego()
{
    delete [] this->Titulo;
    delete [] this->Fabricante;
}
