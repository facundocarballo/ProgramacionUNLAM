///Coria_Lautaro_41691904
#include <iostream>
#include "VideoJuego.h"
using namespace std;

int main()
{
    VideoJuego v1;
    v1.mostrar();
    cout << v1 << endl;
    VideoJuego v2("Tetris", "Estrategia", "Aleskei Pazhitnov", false, 0);
    cout << v2<< endl;
    char nom[500] = "Virtual Tennis";
    VideoJuego v3(nom, "Sega", "Deportes", false, 0);
    v3.prestar();//Modifica el atributo Entregado a true y DiasDePrestamo a 1;
    cout << endl << "Video Juego 3"<<endl;
    v3.mostrar();
    v2 = ++v3;
    v3.devolver();//Modifica el atribuo Entregado a false y DiasDePrestamo a 0.
    cin >> v1;
    cout <<"--- Mostrando VideoJuegos ---"<<endl;
    cout<<v1 <<v2 << v3;
    return 0;
}
