///Coria_Lautaro_41691904
#ifndef VIDEOJUEGO_H
#define VIDEOJUEGO_H

#include <iostream>
#include <string.h>
using namespace std;

class VideoJuego
{
    private:
        char *Titulo;
        char Genero[100];
        char *Fabricante;
        bool Entregado;
        int DiasDePrestamo;

    public:
        VideoJuego();
        VideoJuego(const char *Titulo,const char *Genero, const char *Fabricante, bool Entregado, int DiasDePrestamo);
        VideoJuego(const VideoJuego& juego);
        VideoJuego& operator ++();
        VideoJuego& operator =(const VideoJuego& juego);
        void  mostrar()const;
        VideoJuego& prestar();
        VideoJuego& devolver();

        friend ostream& operator <<(ostream& sal, VideoJuego& juego);
        friend istream& operator >>(istream& is, VideoJuego& juego);

        virtual ~VideoJuego();

};

#endif // VIDEOJUEGO_H
