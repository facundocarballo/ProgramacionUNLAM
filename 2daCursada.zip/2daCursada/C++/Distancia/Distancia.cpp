#include "Distancia.h"

using namespace std;

/// Constructor
Distancia::Distancia(float d, float u)
{
    /// d = 100 | u = kilometros (0.001)
    /// Resultado -> 100000 metros (1)

    d_metros = d / u;
    unidad_medida = u;

}

/// Metodos
void Distancia::convertir(float u)
{
    unidad_medida = u;
}

bool Distancia::operator>=(const Distancia& obj)const
{
    return d_metros >= obj.d_metros;
}

Distancia& Distancia::operator+=(const Distancia& obj)
{
    d_metros += obj.d_metros;

    return *this;
}

/// Operadores
Distancia Distancia::operator+(const Distancia& obj)const
{
    return Distancia(d_metros+obj.d_metros, 1);
}


/// Friend
ostream& operator<<(ostream& sal, const Distancia& obj)
{
    sal << (obj.d_metros * obj.unidad_medida);

    if (obj.unidad_medida == 1)
    {
        sal << " Metros" << endl;
    }

    if (obj.unidad_medida == Distancia::kilometros)
    {
        sal << " Kilometros" << endl;
    }

    if (obj.unidad_medida == Distancia::pulgadas)
    {
        sal << " Pulgadas" << endl;
    }

    if (obj.unidad_medida == Distancia::yardas)
    {
        sal << " Yardas" << endl;
    }

    return sal;
}

Distancia operator+(const float& d, const Distancia& obj)
{
   return Distancia(d + obj.d_metros, 1);
}
