#ifndef DISTANCIA_H_INCLUDED
#define DISTANCIA_H_INCLUDED

#include <iostream>

using namespace std;

class Distancia
{
private:
    float d_metros;
    float unidad_medida;
public:
    static constexpr float kilometros = 0.001;
    static constexpr float yardas = 1.09361;
    static constexpr float pulgadas = 39.3701;
    /// Constructor
    Distancia(float d = 0, float u = 1);
    /// Destructor

    /// Metodos
    void convertir(float u);
    /// Operadores
    Distancia operator+(const Distancia& obj)const;
    bool operator >=(const Distancia& obj)const;
    Distancia& operator+=(const Distancia& obj);
    /// Friends
    friend ostream& operator<<(ostream& sal, const Distancia& obj);
    friend Distancia operator+(const float& d, const Distancia& obj);

};

#endif // DISTANCIA_H_INCLUDED
