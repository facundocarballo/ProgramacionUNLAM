#include "cadena.h"

using namespace std;

int main()
{
    char cadena[] = {"Hola esta es mi cadena"};
    Cadena cad;
    Cadena cad1;
    Cadena cad2(cadena);
    bool igualdad = false;
    bool desigualdad = false;

    cin >> cad1;

    cout << "Cadena 1: " << cad << endl;
    cout << "Lenght: " << cad.getLenght() << endl;

    cout << "====================" << endl;

    cout << "Cadena 2: " << cad2 << endl;
    cout << "Lenght: " << cad2.getLenght() << endl;

    cout << "====================" << endl;

    igualdad = (cad2 == cad);
    desigualdad = (cad2 != cad);
    cout << "Comparacion (==): ";
    if (igualdad) cout << "true" << endl;
        else cout << "false" << endl;
    cout << "Comparacion (!=): ";
    if (desigualdad) cout << "true" << endl;
        else cout << "false" << endl;

    cad = cad2;

    cout << "\n" << endl;
    cout << "\n" << endl;

    cout << "Cadena 1: " << cad << endl;
    cout << "Lenght: " << cad.getLenght() << endl;

    cout << "====================" << endl;

    cout << "Cadena 2: " << cad2 << endl;
    cout << "Lenght: " << cad2.getLenght() << endl;

    cout << "====================" << endl;

    igualdad = (cad2 == cad);
    desigualdad = (cad2 != cad);
    cout << "Comparacion (==): ";
    if (igualdad) cout << "true" << endl;
        else cout << "false" << endl;
    cout << "Comparacion (!=): ";
    if (desigualdad) cout << "true" << endl;
        else cout << "false" << endl;



    return 0;
}
