#include "cadena.h"

int strlen_alu(const char* cad)
{
    int i = 0;
    while(*(cad + i) != '\0') i++;
    return i;
}

int strcpy_alu(char* dest, const char* orig)
{
    int i = 0;
    int cantElem = strlen_alu(orig);
    char* aux = dest;
    while(i < cantElem)
    {
        *(dest) = *(orig + i);
        i++;
        dest++;
    }
    dest = aux;

    return 1;
}

int strcmp_alu(const char* cad1, const char* cad2)
{
    /// return 0 (IGUALES)
    /// return >0 (cad1 > cad2)
    /// return <0 (cad1 < cad2)

    int i = 0;

    // Tienen la misma cantidad de elemento...
    while( *(cad1 + i) == *(cad2 + i) && ( *(cad1 + i) != '\0' || *(cad2 + i) != '\0' ) )
        i++;

    // Si ambas llegaron a fin de linea, son iguales
    if (*(cad1 + i) == '\0' && *(cad2 + i) == '\0') return 0;

    // Si son diferentes, retornar la diferencia
    return *(cad1 + i) - *(cad2 + i);
}


Cadena::Cadena()
{
    lenght = 0;
    pChar = new char[0];
    *pChar = '\0';
}

// Constructor de Cadena
Cadena::Cadena(char* cad)
{
    // Obtenemos la longitud de la cadena
    int cantElem = strlen_alu(cad);

    // Reservamos memoria dinamica
    pChar = new char[cantElem];

    // Copiamos la cadena al puntero a char de la clase
    strcpy_alu(pChar, cad);

    // Seteamos la longitud de la cadena
    lenght = cantElem;
}

// Imprimir Cadena por pantalla
ostream& operator<<(ostream &izq, const Cadena &der)
{
    for(int i=0; i < der.lenght; i++)
        izq<< *(der.pChar + i);

    return izq;
}

// Escribir Cadena
istream& operator>>(istream& izq, Cadena& der)
{
    char nuevaCadena[1000];
    izq.getline(nuevaCadena, 1000);

    if (strlen_alu(nuevaCadena) != strlen_alu(der.pChar))
    {
        delete [] der.pChar;
        der.pChar = new char[strlen_alu(nuevaCadena) + 1];
    }

    strcpy_alu(der.pChar, nuevaCadena);

    return izq;
}

// Asignar Cadena por igualacion
Cadena& Cadena::operator=(const Cadena& cIzq)
{
    // Liberamos memoria de la cadena de la derecha
    delete []pChar;

    // Seteamos los nuevos valores de la cadena de la derecha
    lenght = cIzq.lenght;
    pChar = new char[lenght];

    // Copiamos los valores de la cadena de la izq en la cadena de la derecha
    strcpy_alu(pChar, cIzq.pChar);

    return *this;

}

bool Cadena::operator==(const Cadena& cDer)const
{
    cout << pChar << endl;
    return (strcmp_alu(pChar, cDer.pChar) == 0);
}

bool Cadena::operator!=(const Cadena& cDer)const
{
    return (strcmp_alu(pChar, cDer.pChar) != 0);
}

// Destructor de Cadena
Cadena::~Cadena()
{
    delete []pChar;
}

