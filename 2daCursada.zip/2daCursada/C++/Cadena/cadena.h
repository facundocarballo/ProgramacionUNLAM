#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

#include <iostream>
using namespace std;

class Cadena
{
    private:
        char* pChar;
        int lenght;
    public:
       // Cadena(){}; // Constructor por omision
        Cadena();
        Cadena(char* cad); // Constructor que crea una cadena con una cadena que le llega por parametro.

        int getLenght() { return lenght; }

        Cadena& operator=(const Cadena&); // Asigna una Cadena a una variable de tipo Cadena

        bool operator==(const Cadena&)const; // Compara dos cadenas si son iguales
        bool operator!=(const Cadena&)const; // Compara dos cadenas si son diferentes

        friend ostream& operator<<(ostream&, const Cadena&);
        friend istream& operator>>(istream&, Cadena&);

        ~Cadena(); // Destructor...
};

#endif // CADENA_H_INCLUDED
