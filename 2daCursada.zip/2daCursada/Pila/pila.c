#include "pila.h"

void crear_pila(t_pila* pp)
{
    *pp = NULL;
}

void vaciar_pila(t_pila* pp)
{
    t_nodo* aux;
    while(*pp) /// mientras el la pila apunte a un nodo distinto de NULL
    {
        /// Obtenemos el nodo
        aux = *pp;

        /// Liberar Memoria
        free(aux->info);
        free(aux);

        /// Pasar al siguiente dato
        *pp = aux->sig;
    }
}

int pila_llena(const t_pila* pp, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    void* nueInfo = malloc(tamInfo);

    free(nueNodo);
    free(nueInfo);

    return !nueNodo || !nueInfo;
}

int pila_vacia(const t_pila* pp)
{
    return *pp == NULL;
}

int poner_en_pila(t_pila* pp, const void* info, unsigned tamInfo)
{
    t_nodo* nueNodo = (t_nodo*)malloc(sizeof(t_nodo));
    if (!nueNodo)
    {
        puts("PILA LLENA");
        return 0;
    }

    nueNodo->info = malloc(tamInfo);
    if (!nueNodo->info)
    {
        puts("PILA LLENA");
        free(nueNodo);
        return 0;
    }

    /// Armamos el nodo
    memcpy(nueNodo->info, info, tamInfo);
    nueNodo->sig = *pp; /// Poner el nodo en la pila
    nueNodo->tamInfo = tamInfo;

    /// La pila apunte a este nodo
    *pp = nueNodo;

    return 1;
}

int sacar_de_pila(t_pila* pp, void* info, unsigned tamInfo)
{
    if (!*pp)
    {
        puts("PILA VACIA");
        return 0;
    }

    /// Obtenemos el primer elemento de la pila
    t_nodo* aux = *pp;

    /// Enviamos la informacion al puntero que nos llega por parametro
    memcpy(info, aux->info, MIN(aux->tamInfo, tamInfo));

    /// Liberamos memoria
    free(aux->info);
    free(aux);

    /// Pila ahora apunta al siguiente del que sacamos
    *pp = aux->sig;

    return 1;
}

int ver_tope(const t_pila* pp, void* info, unsigned tamInfo)
{
    if (!*pp)
    {
        puts("PILA VACIA");
        return 0;
    }

    /// Obtenemos el primer elemento de la pila
    t_nodo* aux = *pp;

    /// Enviamos la informacion al puntero que nos llega por parametro
    memcpy(info, aux->info, MIN(aux->tamInfo, tamInfo));

    return 1;
}
